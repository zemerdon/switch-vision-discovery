#!/usr/bin/env python3
"""Validate and atomically publish Switch Vision generated SNMP2MQTT YAML."""
from __future__ import annotations

import argparse
import os
import re
from pathlib import Path
from typing import Any

import yaml

HEADER = "# Switch Vision generated SNMP2MQTT YAML"
SOURCE_HEADER = "# Source: Switch Vision Discovery"
UPTIME_OID = "1.3.6.1.2.1.1.3.0"


def _sensor_oid(sensor: object) -> str:
    if not isinstance(sensor, dict):
        return ""
    return str(sensor.get("oid") or "").strip().lstrip(".")


def validate(path: Path) -> tuple[bool, str]:
    if not path.is_file():
        return False, f"candidate not found: {path}"
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        return False, f"candidate could not be read: {exc}"
    if not text.startswith(HEADER):
        return False, "Switch Vision generated YAML header missing"
    if SOURCE_HEADER not in text:
        return False, "Switch Vision Discovery source header missing"
    if "CHANGE_ME" in text:
        return False, "CHANGE_ME placeholder found"
    # Each source section carries its detected model as a comment and repeats
    # that model in every emitted polling target. Keep those two views locked
    # together so post-generation metadata repair cannot silently corrupt one.
    for section_index, section in enumerate(text.split("# Device source: ")[1:], start=1):
        detected = re.search(r"(?m)^# Detected model:\s*(.+?)\s*$", section)
        if not detected:
            continue
        expected_model = detected.group(1).strip()
        emitted_models = [
            match.group(1).strip()
            for match in re.finditer(r"(?m)^\s*device_model:\s*(.+?)\s*$", section)
        ]
        if emitted_models and any(model != expected_model for model in emitted_models):
            return False, f"source section {section_index} has inconsistent detected/device model metadata"

    try:
        document: Any = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        return False, f"YAML parse failed: {exc}"
    if not isinstance(document, dict):
        return False, "generated YAML root is not a mapping"
    targets = document.get("targets")
    if not isinstance(targets, list) or not targets:
        return False, "generated YAML does not contain a non-empty targets list"

    host_evidence: dict[str, dict[str, int]] = {}
    for index, target in enumerate(targets, start=1):
        if not isinstance(target, dict):
            return False, f"target {index} is not a mapping"
        host = str(target.get("host") or target.get("target") or "").strip()
        if not host:
            return False, f"target {index} has no host"
        sensors = target.get("sensors")
        if sensors is not None and not isinstance(sensors, list):
            return False, f"target {index} sensors is not a list"

        sensor_oids = {
            oid
            for oid in (_sensor_oid(sensor) for sensor in (sensors or []))
            if oid
        }
        model = str(target.get("device_model") or "").strip().casefold()
        uptime_only = sensor_oids == {UPTIME_OID}
        if uptime_only and model == "unknown":
            return (
                False,
                f"target {index} has unknown model with only uptime; failed/insufficient walk suspected",
            )

        evidence = host_evidence.setdefault(host, {"uptime_only_groups": 0})
        if uptime_only:
            evidence["uptime_only_groups"] += 1

    # A valid generated device normally has one slow-system group containing
    # sysUpTime. More than one uptime-only group for the same host indicates
    # duplicate/stale stored-walk input and must not be published atomically.
    for host, evidence in host_evidence.items():
        if evidence["uptime_only_groups"] > 1:
            return (
                False,
                f"host {host} has duplicate uptime-only groups; stale/duplicate walk source suspected",
            )

    return True, "valid"


def publish(candidate: Path, destination: Path) -> tuple[bool, str]:
    valid, reason = validate(candidate)
    if not valid:
        return False, reason
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.replace(candidate, destination)
    except OSError as exc:
        return False, f"atomic replace failed: {exc}"
    return True, "published"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--validate", metavar="PATH", type=Path)
    parser.add_argument("--publish", nargs=2, metavar=("CANDIDATE", "DESTINATION"), type=Path)
    args = parser.parse_args()
    if bool(args.validate) == bool(args.publish):
        parser.error("choose exactly one of --validate or --publish")
    if args.validate:
        ok, reason = validate(args.validate)
    else:
        candidate, destination = args.publish
        ok, reason = publish(candidate, destination)
    if ok:
        print(f"Switch Vision generated YAML guard: PASS ({reason})")
        return 0
    print(f"Switch Vision generated YAML guard: REFUSED ({reason})")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
