#!/usr/bin/env sh
set -eu

SWITCH_VISION_DISCOVERY_VERSION="2.1.7"
export SWITCH_VISION_DISCOVERY_VERSION

migrate_removed_options() {
  options_file="/data/options.json"
  [ -f "$options_file" ] || return 0
  command -v jq >/dev/null 2>&1 || return 0
  if jq -e 'has("show_card_header")' "$options_file" >/dev/null 2>&1; then
    tmp_file=$(mktemp /data/options.switch-vision.XXXXXX)
    if jq 'del(.show_card_header)' "$options_file" > "$tmp_file"; then
      chmod --reference="$options_file" "$tmp_file" 2>/dev/null || true
      mv -f "$tmp_file" "$options_file"
      echo "Switch Vision Discovery migrated removed option: show_card_header"
    else
      rm -f "$tmp_file"
      echo "Switch Vision Discovery warning: could not migrate removed show_card_header option" >&2
    fi
  fi
}

migrate_removed_options

mkdir -p /share/switch_vision /share/switch_vision/contributions
touch /share/switch_vision/discovery-web.log

echo "Switch Vision Discovery service starting in idle/ready mode."
echo "Support My Switch Web UI: listening on Home Assistant Ingress (port 8099)."
exec python3 /support_web.py \
  --port 8099 \
  --version "$SWITCH_VISION_DISCOVERY_VERSION" \
  --discovery-script /discovery_job.sh
