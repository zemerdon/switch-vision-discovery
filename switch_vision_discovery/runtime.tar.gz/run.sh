#!/usr/bin/env sh
set -eu

SWITCH_VISION_DISCOVERY_VERSION="2.1.11"
export SWITCH_VISION_DISCOVERY_VERSION

migrate_removed_options() {
  options_file="/data/options.json"
  [ -f "$options_file" ] || return 0
  command -v jq >/dev/null 2>&1 || return 0
  if jq -e 'has("show_card_header")' "$options_file" >/dev/null 2>&1; then
    tmp_file=$(mktemp /data/options.switch-vision.XXXXXX)
    if jq 'del(.show_card_header)' "$options_file" > "$tmp_file"; then
      chmod --reference="$options_file" "$tmp_file" 2>/dev/null || true
      mv -f "$tmp_file" "$options_file"
      echo "Switch Vision Discovery migrated removed option: show_card_header"
    else
      rm -f "$tmp_file"
      echo "Switch Vision Discovery warning: could not migrate removed show_card_header option" >&2
    fi
  fi
}

migrate_switch_enabled_state() {
  # Canonicalize pre-v2.1.8 switch rows after Supervisor has accepted the
  # backward-compatible optional schema. This makes the editor/export state
  # explicit without requiring users to re-add existing switches.
  options_file="/data/options.json"
  [ -f "$options_file" ] || return 0
  command -v jq >/dev/null 2>&1 || return 0
  if ! jq -e '
    ((.switches? | type) == "array" and any(.switches[]?; type == "object" and (has("enabled") | not))) or
    ((.multi_switch_walks? | type) == "array" and any(.multi_switch_walks[]?; type == "object" and (has("enabled") | not)))
  ' "$options_file" >/dev/null 2>&1; then
    return 0
  fi
  tmp_file=$(mktemp /data/options.switch-vision.XXXXXX)
  if jq '
    def add_state:
      if type == "array" then
        map(if type == "object" and (has("enabled") | not) then . + {enabled: "enabled"} else . end)
      else . end;
    if has("switches") then .switches |= add_state else . end |
    if has("multi_switch_walks") then .multi_switch_walks |= add_state else . end
  ' "$options_file" > "$tmp_file"; then
    chmod --reference="$options_file" "$tmp_file" 2>/dev/null || true
    mv -f "$tmp_file" "$options_file"
    echo "Switch Vision Discovery migrated existing switch rows to explicit enabled state"
  else
    rm -f "$tmp_file"
    echo "Switch Vision Discovery warning: could not migrate switch enabled state" >&2
  fi
}

migrate_removed_options
migrate_switch_enabled_state

mkdir -p /share/switch_vision /share/switch_vision/contributions
touch /share/switch_vision/discovery-web.log

echo "Switch Vision Discovery service starting in idle/ready mode."
echo "Support My Switch Web UI: listening on Home Assistant Ingress (port 8099)."
exec python3 /support_web.py \
  --port 8099 \
  --version "$SWITCH_VISION_DISCOVERY_VERSION" \
  --discovery-script /discovery_job.sh
