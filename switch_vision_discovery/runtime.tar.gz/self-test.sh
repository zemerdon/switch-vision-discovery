#!/usr/bin/env sh
set -eu
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -d "$BASE_DIR/mib_database" ]; then
  RUNTIME_DATA_DIR="$BASE_DIR"
elif [ -d "$BASE_DIR/opt/switch-vision/mib_database" ]; then
  RUNTIME_DATA_DIR="$BASE_DIR/opt/switch-vision"
elif [ -d /opt/switch-vision/mib_database ]; then
  RUNTIME_DATA_DIR=/opt/switch-vision
else
  echo "ERROR: Switch Vision runtime data directory is missing." >&2
  exit 1
fi
export CV_MIB_DATABASE_DIR="$RUNTIME_DATA_DIR/mib_database"
export CV_VENDOR_DIR="$RUNTIME_DATA_DIR/vendors"
RUNTIME_REGISTRY="$RUNTIME_DATA_DIR/devices/supported_devices.json"
[ -f "$RUNTIME_REGISTRY" ]
. "$CV_VENDOR_DIR/base.sh"
. "$CV_VENDOR_DIR/generic.sh"
. "$CV_VENDOR_DIR/cisco.sh"
. "$CV_VENDOR_DIR/known_vendor.sh"
. "$CV_VENDOR_DIR/interface.sh"
. "$CV_VENDOR_DIR/loader.sh"
cv_vendor_database_self_test

tmp_dir=$(mktemp -d)
trap 'rm -rf "$tmp_dir"' EXIT
walk="$tmp_dir/test-walk.txt"
cat > "$walk" <<'WALK'
.1.3.6.1.2.1.1.1.0 = STRING: "Cisco IOS Software, C3650 Software"
.1.3.6.1.2.1.1.2.0 = OID: .1.3.6.1.4.1.9.1.2066
.1.3.6.1.2.1.1.5.0 = STRING: "SW5"
.1.3.6.1.2.1.31.1.1.1.1.1 = STRING: "GigabitEthernet1/0/1"
.1.3.6.1.2.1.31.1.1.1.1.49 = STRING: "TenGigabitEthernet1/1/1"
.1.3.6.1.2.1.31.1.1.1.1.10101 = STRING: "Vlan1"
WALK
cv_detect_vendor_identity "$walk"
[ "$CV_ID_VENDOR" = "cisco" ]
[ "$CV_ID_FAMILY" = "Catalyst 3650" ]
[ "$CV_ID_PRODUCT_MATCH" = "exact" ]
cv_write_capabilities_json "$walk" "$tmp_dir/capabilities.json" "$tmp_dir/latest.json"
jq -e '(.device.vendor == "cisco") and (.summary.interface_count == 3) and (.summary.physical_count == 2) and (.summary.rj45_count == 1) and (.summary.sfp_plus_count == 1)' "$tmp_dir/capabilities.json" >/dev/null

cat >> "$walk" <<'WALK'
.1.3.6.1.2.1.47.1.1.1.1.7.1001 = STRING: "Chassis inlet temperature"
.1.3.6.1.2.1.99.1.1.1.1.1001 = INTEGER: 8
.1.3.6.1.2.1.99.1.1.1.2.1001 = INTEGER: 9
.1.3.6.1.2.1.99.1.1.1.3.1001 = INTEGER: 0
.1.3.6.1.2.1.99.1.1.1.4.1001 = INTEGER: 42
.1.3.6.1.2.1.99.1.1.1.5.1001 = INTEGER: 1
.1.3.6.1.2.1.105.1.3.1.1.2.1 = Gauge32: 740
.1.3.6.1.2.1.105.1.3.1.1.4.1 = Gauge32: 120
WALK
python3 "$BASE_DIR/standard_sensor_scan.py" --walk "$walk" --enrich "$tmp_dir/capabilities.json"
jq -e '(.standard_sensor_discovery.candidate_count == 3) and (.capabilities.environment == true) and (.capabilities.poe == true)' "$tmp_dir/capabilities.json" >/dev/null


juniper_walk="$tmp_dir/juniper-walk.txt"
cat > "$juniper_walk" <<'WALK'
.1.3.6.1.2.1.1.1.0 = STRING: "Juniper Networks, Inc. ex4300-48p"
.1.3.6.1.2.1.1.2.0 = OID: .1.3.6.1.4.1.2636.1.1.1.2.63
.1.3.6.1.2.1.1.5.0 = STRING: "edge-juniper"
JUNIPER-MIB::jnxOperatingTemp.1 = INTEGER: 42
JUNIPER-MIB::jnxOperatingCPU.1 = INTEGER: 17
WALK
cv_detect_vendor_identity "$juniper_walk"
[ "$CV_ID_VENDOR" = "juniper" ]
cv_write_capabilities_json "$juniper_walk" "$tmp_dir/juniper-capabilities.json" ""
python3 "$BASE_DIR/vendor_sensor_scan.py" --walk "$juniper_walk" --database "$CV_MIB_DATABASE_DIR" --enrich "$tmp_dir/juniper-capabilities.json"
jq -e '(.device.vendor == "juniper") and (.vendor_sensor_discovery.pack_loaded == true) and (.vendor_sensor_discovery.counts_by_category.temperature == 1) and (.vendor_sensor_discovery.counts_by_category.cpu == 1)' "$tmp_dir/juniper-capabilities.json" >/dev/null

huawei_walk="$tmp_dir/huawei-walk.txt"
cat > "$huawei_walk" <<'WALK'
.1.3.6.1.2.1.1.1.0 = STRING: "Huawei S5735-L8P4X-A1"
.1.3.6.1.2.1.1.2.0 = OID: .1.3.6.1.4.1.2011.2.23.849
.1.3.6.1.2.1.1.5.0 = STRING: "huawei-test"
.1.3.6.1.2.1.31.1.1.1.1.6 = STRING: "GigabitEthernet0/0/1"
.1.3.6.1.2.1.31.1.1.1.1.14 = STRING: "XGigabitEthernet0/0/1"
.1.3.6.1.2.1.31.1.1.1.1.15 = STRING: "XGigabitEthernet0/0/2"
.1.3.6.1.2.1.31.1.1.1.1.16 = STRING: "XGigabitEthernet0/0/3"
.1.3.6.1.2.1.31.1.1.1.1.17 = STRING: "XGigabitEthernet0/0/4"
WALK
cv_detect_vendor_identity "$huawei_walk"
[ "$CV_ID_VENDOR" = "huawei" ]
cv_write_capabilities_json "$huawei_walk" "$tmp_dir/huawei-capabilities.json" ""
jq -e '(.device.vendor == "huawei") and (.summary.physical_count == 5) and (.summary.rj45_count == 1) and (.summary.sfp_plus_count == 4)' "$tmp_dir/huawei-capabilities.json" >/dev/null

s5720_walk="$tmp_dir/s5720-walk.txt"
cat > "$s5720_walk" <<'WALK'
.1.3.6.1.2.1.1.1.0 = STRING: "Huawei S5720-12TP-LI-AC "
.1.3.6.1.2.1.1.2.0 = OID: .1.3.6.1.4.1.2011.2.23.394
.1.3.6.1.2.1.1.5.0 = STRING: "huawei-s5720-test"
.1.3.6.1.2.1.2.2.1.2.1 = STRING: "InLoopBack0"
.1.3.6.1.2.1.2.2.1.2.2 = STRING: "NULL0"
.1.3.6.1.2.1.2.2.1.2.5 = STRING: "GigabitEthernet0/0/1"
.1.3.6.1.2.1.2.2.1.2.6 = STRING: "GigabitEthernet0/0/2"
.1.3.6.1.2.1.2.2.1.2.7 = STRING: "GigabitEthernet0/0/3"
.1.3.6.1.2.1.2.2.1.2.8 = STRING: "GigabitEthernet0/0/4"
.1.3.6.1.2.1.2.2.1.2.9 = STRING: "GigabitEthernet0/0/5"
.1.3.6.1.2.1.2.2.1.2.10 = STRING: "GigabitEthernet0/0/6"
.1.3.6.1.2.1.2.2.1.2.11 = STRING: "GigabitEthernet0/0/7"
.1.3.6.1.2.1.2.2.1.2.12 = STRING: "GigabitEthernet0/0/8"
.1.3.6.1.2.1.2.2.1.2.13 = STRING: "GigabitEthernet0/0/9"
.1.3.6.1.2.1.2.2.1.2.14 = STRING: "GigabitEthernet0/0/10"
.1.3.6.1.2.1.2.2.1.2.15 = STRING: "GigabitEthernet0/0/11"
.1.3.6.1.2.1.2.2.1.2.16 = STRING: "GigabitEthernet0/0/12"
WALK
cv_detect_vendor_identity "$s5720_walk"
[ "$CV_ID_VENDOR" = "huawei" ]
cv_write_capabilities_json "$s5720_walk" "$tmp_dir/s5720-capabilities.json" ""
jq -e '
  (.device.model_text == "S5720-12TP-LI-AC")
  and (.summary.physical_count == 12)
  and (.summary.rj45_count == 8)
  and (.summary.sfp_count == 4)
  and (.summary.sfp_plus_count == 0)
  and (.summary.uplink_count == 4)
  and ([.interfaces[] | select(.physical) | .name] | length == 12)
' "$tmp_dir/s5720-capabilities.json" >/dev/null

sg500_walk="$tmp_dir/sg500-walk.txt"
cat > "$sg500_walk" <<'WALK'
.1.3.6.1.2.1.1.1.0 = STRING: "SG500X-24 24-Port Gigabit with 4-Port 10-Gigabit Stackable Managed Switch"
.1.3.6.1.2.1.1.2.0 = OID: .1.3.6.1.4.1.9.6.1.85.24.1
.1.3.6.1.2.1.1.5.0 = STRING: "sg500-test"
.1.3.6.1.2.1.31.1.1.1.1.49 = STRING: "gi1/1"
.1.3.6.1.2.1.31.1.1.1.1.72 = STRING: "gi1/24"
.1.3.6.1.2.1.31.1.1.1.1.107 = STRING: "te1/1"
.1.3.6.1.2.1.31.1.1.1.1.110 = STRING: "te1/4"
WALK
cv_detect_vendor_identity "$sg500_walk"
[ "$CV_ID_VENDOR" = "cisco" ]
cv_write_capabilities_json "$sg500_walk" "$tmp_dir/sg500-capabilities.json" ""
jq -e '(.device.model_text == "SG500X-24") and (.summary.physical_count == 4) and (.summary.rj45_count == 2) and (.summary.sfp_plus_count == 2)' "$tmp_dir/sg500-capabilities.json" >/dev/null

registry_report="$tmp_dir/registry-report.txt"
python3 "$BASE_DIR/registry_lookup.py" --registry "$RUNTIME_REGISTRY" --model "WS-C3650-48PD-E" --report > "$registry_report"
grep -q -- '- Registry match: yes' "$registry_report"
grep -q -- '- Registry status: confirmed' "$registry_report"
grep -q -- '- Mapping profile: cisco-3650-48p-2x10g' "$registry_report"

unifi_snapshot="$tmp_dir/unifi-devices.json"
unifi_registry="$tmp_dir/unifi-registry.json"
python3 - "$unifi_snapshot" "$unifi_registry" <<'PYTEST'
import json, sys
snapshot, registry = sys.argv[1:3]
pro_ports = [{"idx": i, "state": "UP", "connector": "RJ45", "speed_mbps": 1000} for i in range(1, 25)]
pro_ports += [{"idx": 25, "state": "UP", "connector": "SFPPLUS", "speed_mbps": 10000}, {"idx": 26, "state": "UP", "connector": "SFPPLUS", "speed_mbps": 10000}]
lite_ports = [{"idx": i, "state": "UP", "connector": "RJ45", "speed_mbps": 1000} for i in range(1, 17)]
json.dump({"schema_version": 1, "devices": [
    {"id": "api-pro24", "name": "Core", "model": "USW Pro 24 PoE", "ports": pro_ports},
    {"id": "api-lite16", "name": "Garage", "model": "USW Lite 16 PoE", "ports": lite_ports},
]}, open(snapshot, "w"))
json.dump({"devices": [
    {"model": "USW-Pro-24-PoE", "status": "experimental", "calibration_profile": "cisco_2960x_24p", "default_faceplate": "faceplates/24rj45-2sfp.png"},
    {"model": "USW Lite 16 PoE", "status": "experimental", "calibration_profile": "cisco_2960x_24p", "default_faceplate": "faceplates/24rj45-4sfp.png"},
]}, open(registry, "w"))
PYTEST
python3 "$BASE_DIR/unifi_dashboard_cards.py" --snapshot "$unifi_snapshot" --registry "$unifi_registry" --indent 0 > "$tmp_dir/unifi-cards.yaml"
grep -q 'data_source: unifi_api' "$tmp_dir/unifi-cards.yaml"
grep -q 'switch_model: USW Pro 24 PoE' "$tmp_dir/unifi-cards.yaml"
grep -q 'switch_model: USW Lite 16 PoE' "$tmp_dir/unifi-cards.yaml"
grep -q 'faceplate_file: 48rj45-4sfp.png' "$tmp_dir/unifi-cards.yaml"
grep -q 'port_count: 16' "$tmp_dir/unifi-cards.yaml"
! grep -q 'waiting for a matching generic faceplate/calibration profile' "$tmp_dir/unifi-cards.yaml"

privacy_root="$tmp_dir/privacy"
mkdir -p "$privacy_root/unifi"
cat > "$privacy_root/unifi/devices.json" <<'JSON'
{"devices":[{"id":"device-uuid-123","name":"Private Core","model":"USW Pro 24 PoE","ports":[]}]}
JSON
cat > "$privacy_root/generated-dashboard-card.yaml" <<'YAML'
views:
  - title: Switch Vision
    cards:
      - type: custom:switch-vision-3650
        title: Private Core
        member: unifi_deviceuuid123
        selected_switch: unifi_deviceuuid123
        switch_model: USW Pro 24 PoE
        data_source: unifi_api
        unifi_device_id: device-uuid-123
      # UniFi "Private Garage" (USW Lite 16 PoE) detected; waiting for visuals.
YAML
python3 "$BASE_DIR/sanitize_support_bundle.py" "$privacy_root" "$privacy_root/report.json" --mask-hostnames true >/dev/null
jq -e '(.devices[0].id | startswith("masked-device-")) and (.devices[0].name == "masked-switch") and (.devices[0].model == "USW Pro 24 PoE")' "$privacy_root/unifi/devices.json" >/dev/null
grep -q '^        title: masked-switch$' "$privacy_root/generated-dashboard-card.yaml"
grep -q '^        unifi_device_id: masked-device-' "$privacy_root/generated-dashboard-card.yaml"
grep -q '^        member: unifi_masked_' "$privacy_root/generated-dashboard-card.yaml"
grep -q '^        selected_switch: unifi_masked_' "$privacy_root/generated-dashboard-card.yaml"
grep -q '# UniFi "masked-switch" (USW Lite 16 PoE)' "$privacy_root/generated-dashboard-card.yaml"
! grep -q 'Private Core\|Private Garage\|device-uuid-123\|unifi_deviceuuid123' "$privacy_root/generated-dashboard-card.yaml"
jq -e '(.sanitization_version >= 11) and (.residual_audit.unifi_device_ids_remaining == 0) and (.residual_audit.unifi_device_names_remaining == 0) and (.residual_audit.unifi_dashboard_ids_remaining == 0) and (.residual_audit.unifi_dashboard_names_remaining == 0) and (.enabled_category_leaks_found == false)' "$privacy_root/report.json" >/dev/null

python3 - "$BASE_DIR" <<'PYTEST'
import sys, tempfile
from pathlib import Path
sys.path.insert(0, sys.argv[1])
import support_web

with tempfile.TemporaryDirectory() as tmp:
    generated = Path(tmp) / "generated-snmp2mqtt.yaml"
    generated.write_text("""targets:\n- host: 192.0.2.10\n  name: SW1\n  sensors:\n  - oid: 1.3.6.1.2.1.1.3.0\n    name: SW1 Uptime\n  - oid: 1.3.6.1.2.1.2.2.1.8.1\n    name: SW1 Port 1 Status\n    binary_sensor: true\n  - oid: 1.3.6.1.2.1.2.2.1.10.1\n    name: ignored-name\n    object_id: sw1_port_1_rx_bytes\n""", encoding="utf-8")
    topics = support_web._snmp2mqtt_discovery_topics(generated, "homeassistant")
    assert topics == [
        "homeassistant/binary_sensor/snmp2mqtt/sw1_port_1_status/config",
        "homeassistant/sensor/snmp2mqtt/sw1_port_1_rx_bytes/config",
        "homeassistant/sensor/snmp2mqtt/sw1_uptime/config",
    ], topics
    assert support_web._snmp2mqtt_slug("SW1 SFP 10G 1 RX Bytes") == "sw1_sfp_10g_1_rx_bytes"

print("Switch Vision SNMP2MQTT retirement topic self-test: PASS")
PYTEST

printf '%s\n' "Switch Vision vendor/interface/privacy self-test: PASS"

# Hub UniFi visibility/status UX regression checks.
grep -q 'id="openUnifi2mqttSettingsButton"' "$BASE_DIR/support_web.py"
grep -q 'unifi-unavailable' "$BASE_DIR/support_web.py"
grep -q 'UniFi2MQTT is not installed. Install it from Switch Vision Installer first.' "$BASE_DIR/support_web.py"
grep -q 'UniFi2MQTT is installed but not configured. Open settings to complete setup.' "$BASE_DIR/support_web.py"
grep -q 'show_unifi_integration' "$BASE_DIR/support_web.py"
grep -q "openResolvedApp('discovery')" "$BASE_DIR/support_web.py"
! grep -q '/config/app/local_switch_vision_discovery/config' "$BASE_DIR/support_web.py"
! grep -q 'Install/copy the bundled local app' "$BASE_DIR/support_web.py"
grep -q '_configured_switch_count' "$BASE_DIR/support_web.py"


# Blank/default switch-row regression.
# A fresh Home Assistant install contains one visual placeholder row, but that
# row must not count as a configured SNMP target. Empty fields must also remain
# in their original positions when switch rows are decoded.
sh -n "$BASE_DIR/discovery_job.sh"
grep -q 'SWITCH_VISION_DISCOVERY_VERSION="2.1.3"' "$BASE_DIR/discovery_job.sh"

blank_switch_cfg="$tmp_dir/blank-switch-row.json"
real_switch_cfg="$tmp_dir/real-switch-row.json"

printf "%s\n" \
'{"switches":[{"switch_name":"","switch_host":"","sensor_prefix":"","snmp_community":"readonly","walk_mode":"targeted","switch_model":"auto"}]}' \
> "$blank_switch_cfg"

printf "%s\n" \
'{"switches":[{"switch_name":"SW10","switch_host":"192.168.1.108","sensor_prefix":"sw10","snmp_community":"readonly","walk_mode":"targeted","switch_model":"EX3300-48P"}]}' \
> "$real_switch_cfg"

if jq -e '
  (.switches // .multi_switch_walks // []) as $rows |
  ($rows | type == "array") and
  any($rows[]?;
    ((.switch_name // .switch // .selected_switch // .name // "")
     | tostring | length) > 0
  )
' "$blank_switch_cfg" >/dev/null; then
  echo "ERROR: blank starter switch row counted as configured" >&2
  exit 1
fi

jq -e '
  (.switches // .multi_switch_walks // []) as $rows |
  ($rows | type == "array") and
  any($rows[]?;
    ((.switch_name // .switch // .selected_switch // .name // "")
     | tostring | length) > 0
  )
' "$real_switch_cfg" >/dev/null

sv_row_separator="$(printf "\\034")"

blank_parsed=$(
  jq -r '
    (.switches // .multi_switch_walks // [])[]? | [
      (.switch_name // .switch // .selected_switch // .name // ""),
      (.switch_host // .host // .manual_switch_host // ""),
      (.switch_name // .switch // .selected_switch // .name // ""),
      (.sensor_prefix // .entity_prefix // .prefix // ""),
      (.snmp_community // .community // ""),
      (.walk_mode // .mode // "targeted"),
      (.output_dir // ""),
      (.display_name // .card_title // ""),
      (.switch_model // .model_override // "auto")
    ] | map(tostring) | join("\u001c")
  ' "$blank_switch_cfg" |
  while IFS="$sv_row_separator" read -r sw host label prefix community mode out display model; do
    printf "%s|%s|%s|%s|%s|%s" \
      "$sw" "$host" "$prefix" "$community" "$mode" "$model"
  done
)

[ "$blank_parsed" = "|||readonly|targeted|auto" ]

real_parsed=$(
  jq -r '
    (.switches // .multi_switch_walks // [])[]? | [
      (.switch_name // .switch // .selected_switch // .name // ""),
      (.switch_host // .host // .manual_switch_host // ""),
      (.switch_name // .switch // .selected_switch // .name // ""),
      (.sensor_prefix // .entity_prefix // .prefix // ""),
      (.snmp_community // .community // ""),
      (.walk_mode // .mode // "targeted"),
      (.output_dir // ""),
      (.display_name // .card_title // ""),
      (.switch_model // .model_override // "auto")
    ] | map(tostring) | join("\u001c")
  ' "$real_switch_cfg" |
  while IFS="$sv_row_separator" read -r sw host label prefix community mode out display model; do
    printf "%s|%s|%s|%s|%s|%s" \
      "$sw" "$host" "$prefix" "$community" "$mode" "$model"
  done
)

[ "$real_parsed" = "SW10|192.168.1.108|sw10|readonly|targeted|EX3300-48P" ]

printf "%s\n" "Switch Vision blank switch-row regression: PASS"
