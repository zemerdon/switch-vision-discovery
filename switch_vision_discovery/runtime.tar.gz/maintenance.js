(() => {
  let lastPlan = null;
  let lastInstallerBackupStatus = null;
  let installerPollTimer = null;
  let activeMaintenanceTab = "backups";
  const loadedMaintenanceTabs = new Set();

  const el = (id) => document.getElementById(id);

  function installMaintenanceStyles() {
    if (el("switchVisionMaintenanceStyles")) return;
    const style = document.createElement("style");
    style.id = "switchVisionMaintenanceStyles";
    style.textContent = `
      .maintenance-tabs{
        display:flex;
        gap:8px;
        align-items:center;
        overflow-x:auto;
        padding:2px 2px 8px;
        margin:0 0 12px;
        border-bottom:1px solid var(--line-soft)
      }
      .maintenance-tab{
        flex:0 0 auto;
        font-weight:750;
        color:var(--muted);
        background:var(--surface-button)!important;
        border-color:var(--line-soft)!important
      }
      .maintenance-tab.is-active{
        color:var(--heading-strong)!important;
        border-color:var(--accent-strong)!important;
        background:var(--accent-soft)!important;
        box-shadow:inset 0 -2px 0 var(--accent)
      }
      .maintenance-tab:focus-visible{
        outline:none;
        box-shadow:0 0 0 3px var(--accent-soft),inset 0 -2px 0 var(--accent)
      }
      .maintenance-pane[hidden]{display:none!important}
      .maintenance-pane{
        min-width:0
      }
    `;
    document.head.appendChild(style);
  }

  function setConfigurationExportLinks() {
    const complete = el("exportConfigurationButton");
    const switches = el("exportSwitchesButton");
    if (complete) complete.href = endpoint("download/switch-vision-backup.json");
    if (switches) switches.href = endpoint("download/switch-vision-switch-configuration.json");
  }

  function maintenanceTabKeydown(event) {
    const ids = ["backups", "snmp", "configuration", "calibrations", "reset"];
    const current = Math.max(0, ids.indexOf(activeMaintenanceTab));
    let next = null;
    if (event.key === "ArrowRight") next = ids[(current + 1) % ids.length];
    else if (event.key === "ArrowLeft") next = ids[(current - 1 + ids.length) % ids.length];
    else if (event.key === "Home") next = ids[0];
    else if (event.key === "End") next = ids[ids.length - 1];
    if (!next) return;
    event.preventDefault();
    selectMaintenanceTab(next, true);
  }

  function selectMaintenanceTab(which = "backups", focus = false) {
    const ids = ["backups", "snmp", "configuration", "calibrations", "reset"];
    const selected = ids.includes(which) ? which : "backups";
    activeMaintenanceTab = selected;

    for (const id of ids) {
      const active = id === selected;
      const tab = el(`maintenanceTabButton-${id}`);
      const panel = el(`maintenancePanel-${id}`);
      if (tab) {
        tab.classList.toggle("is-active", active);
        tab.setAttribute("aria-selected", String(active));
        tab.tabIndex = active ? 0 : -1;
      }
      if (panel) panel.hidden = !active;
    }

    if (focus) el(`maintenanceTabButton-${selected}`)?.focus();

    if (selected === "backups" && !loadedMaintenanceTabs.has("backups")) {
      loadedMaintenanceTabs.add("backups");
      loadInstallerBackups();
      window.SwitchVisionHubSettings?.loadMaintenanceBackupSettings?.();
    } else if (selected === "snmp" && !loadedMaintenanceTabs.has("snmp")) {
      loadedMaintenanceTabs.add("snmp");
      scan();
    } else if (selected === "configuration") {
      setConfigurationExportLinks();
    } else if (selected === "calibrations") {
      window.SwitchVisionCalibrationProfiles?.load?.();
    }
  }

  function openMaintenance(which = "backups") {
    setView("maintenance");
    selectMaintenanceTab(which);
  }

  function installerOperationMessage(operation) {
    if (!operation || typeof operation !== "object") return "";
    if (operation.active) {
      return `${operation.message || "Installer backup operation in progress…"} ${
        Number(operation.percent || 0)
      }%`.trim();
    }
    if (operation.error) return `Installer backup operation failed: ${operation.error}`;
    const result = operation.result;
    if (!result || typeof result !== "object") return "";
    if (Array.isArray(result.required_actions) && result.required_actions.length) {
      return `Backup operation completed. Required next steps: ${result.required_actions.join(
        "; "
      )}.`;
    }
    if (result.backup_created) return `Backup ${result.backup || ""} created and verified.`.trim();
    if (result.backup_validated) return `Backup ${result.backup || ""} validation passed.`.trim();
    if (Array.isArray(result.restored)) return `Backup ${result.backup || ""} restored.`.trim();
    return "Installer backup operation completed.";
  }

  function setInstallerControlsDisabled(disabled) {
    for (const id of [
      "installerBackupAutomaticRetention",
      "createInstallerBackupButton",
      "refreshInstallerBackupsButton",
    ]) {
      const node = el(id);
      if (node) node.disabled = disabled;
    }
  }

  function renderInstallerBackups(data) {
    lastInstallerBackupStatus =
      data && typeof data === "object" ? data : null;
    const summary = el("installerBackupSummary");
    const list = el("installerBackupList");
    const automatic = el("installerBackupAutomaticRetention");
    if (!summary || !list || !automatic) return;

    summary.replaceChildren();
    list.replaceChildren();

    if (!lastInstallerBackupStatus) {
      setInstallerControlsDisabled(true);
      automatic.setAttribute("aria-pressed", "false");
      automatic.classList.remove("primary");
      automatic.textContent = "Automatic retention: Unavailable";
      summary.textContent = "Backup status unavailable";
      return;
    }

    const retentionEnabled = Boolean(lastInstallerBackupStatus.automatic_retention);
    automatic.setAttribute("aria-pressed", String(retentionEnabled));
    automatic.classList.toggle("primary", retentionEnabled);
    automatic.textContent = `Automatic retention: ${retentionEnabled ? "On" : "Off"}`;
    setInstallerControlsDisabled(false);

    const backups = Array.isArray(lastInstallerBackupStatus.backups)
      ? lastInstallerBackupStatus.backups
      : [];
    summary.textContent = `${backups.length} retained backup${backups.length === 1 ? "" : "s"}`;

    if (!backups.length) {
      const empty = document.createElement("div");
      empty.className = "muted";
      empty.textContent = "No Installer recovery backups.";
      list.appendChild(empty);
    } else {
      for (const backup of backups) {
        const row = document.createElement("div");
        row.className = "device-card installer-backup-row";
        const line = document.createElement("div");
        line.className = "installer-backup-line";
        const title = document.createElement("strong");
        title.textContent = backup.name || "Installer recovery backup";
        const created = document.createElement("span");
        created.className = "muted";
        created.textContent = backup.created_at || "Unknown time";
        const version = document.createElement("span");
        version.className = "muted";
        version.textContent = backup.version ? `Switch Vision v${backup.version}` : "Version unknown";
        line.append(title, created, version);

        const actions = document.createElement("div");
        actions.className = "actions";
        const validate = document.createElement("button");
        validate.type = "button";
        validate.textContent = "Validate";
        validate.addEventListener("click", () =>
          runInstallerBackupAction("validate_backup", { name: backup.name }, validate)
        );
        const restore = document.createElement("button");
        restore.type = "button";
        restore.className = "danger";
        restore.textContent = "Restore";
        restore.addEventListener("click", () => {
          if (
            confirm(
              `Restore ${backup.name}? This will replace the Switch Vision components contained in that private recovery backup.`
            )
          ) {
            runInstallerBackupAction("restore_backup", { name: backup.name }, restore);
          }
        });
        const remove = document.createElement("button");
        remove.type = "button";
        remove.textContent = "Delete";
        remove.addEventListener("click", () => {
          if (
            confirm(
              `Delete Installer recovery backup ${backup.name}? This cannot be undone.`
            )
          ) {
            runInstallerBackupAction("delete_backup", { name: backup.name }, remove);
          }
        });
        actions.append(validate, restore, remove);
        row.append(line, actions);
        list.appendChild(row);
      }
    }

    const operation = lastInstallerBackupStatus.operation;
    if (operation && operation.active) {
      scheduleInstallerBackupPoll();
    }
  }

  function scheduleInstallerBackupPoll() {
    if (installerPollTimer) clearTimeout(installerPollTimer);
    installerPollTimer = setTimeout(() => {
      installerPollTimer = null;
      loadInstallerBackups({ quiet: true });
    }, 800);
  }

  async function loadInstallerBackups({ quiet = false } = {}) {
    const status = el("installerBackupStatus");
    const refresh = el("refreshInstallerBackupsButton");
    if (refresh) refresh.disabled = true;
    if (status && !quiet) status.textContent = "Loading Installer recovery backups…";
    try {
      const response = await fetch(endpoint("api/maintenance/installer-backups"), {
        cache: "no-store",
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Installer backup status failed");
      }
      renderInstallerBackups(data);
      if (status) {
        const operationMessage = installerOperationMessage(data.operation);
        status.textContent =
          operationMessage ||
          (data.automatic_retention
            ? "Automatic retention is on."
            : "Automatic retention is off. Existing Installer recovery backups are kept until you delete them manually.");
      }
    } catch (error) {
      renderInstallerBackups(null);
      if (status) {
        status.textContent = `Could not load Installer recovery backups: ${
          error.message || error
        }`;
      }
    } finally {
      if (refresh && lastInstallerBackupStatus) refresh.disabled = false;
    }
  }

  async function runInstallerBackupAction(action, payload = {}, button = null) {
    const status = el("installerBackupStatus");
    if (button) button.disabled = true;
    if (status) status.textContent = "Sending Installer backup request…";
    try {
      const response = await fetch(endpoint("api/maintenance/installer-backups"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, ...payload }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Installer backup request failed");
      }
      renderInstallerBackups(data);
      if (status) {
        status.textContent =
          installerOperationMessage(data.operation) ||
          "Installer backup settings updated.";
      }
      if (data.operation && data.operation.active) scheduleInstallerBackupPoll();
    } catch (error) {
      if (status) {
        status.textContent = `Installer backup request failed: ${
          error.message || error
        }`;
      }
      if (button) button.disabled = false;
    }
  }

  async function toggleInstallerBackupRetention() {
    const button = el("installerBackupAutomaticRetention");
    if (!button || !lastInstallerBackupStatus) return;

    const retention = Number(lastInstallerBackupStatus.retention_count ?? 5);
    if (!Number.isInteger(retention) || retention < 1 || retention > 10) {
      el("installerBackupStatus").textContent =
        "Stored Installer retention policy is invalid.";
      return;
    }

    const currentlyEnabled = Boolean(lastInstallerBackupStatus.automatic_retention);
    const current = Array.isArray(lastInstallerBackupStatus.backups)
      ? lastInstallerBackupStatus.backups.length
      : 0;
    const removeCount = Math.max(0, current - retention);

    if (
      !currentlyEnabled &&
      removeCount &&
      !confirm(
        `Enable automatic retention? Installer will immediately apply its existing retention policy and delete ${removeCount} older backup${
          removeCount === 1 ? "" : "s"
        }.`
      )
    ) {
      return;
    }

    await runInstallerBackupAction(
      "set_policy",
      {
        automatic_retention: !currentlyEnabled,
        retention_count: retention,
      },
      button
    );
  }

  function safeExportPlan(plan) {
    if (!plan || typeof plan !== "object") return null;
    const stale = Array.isArray(plan.stale_entries)
      ? plan.stale_entries.map((entry) => ({
          component: entry.component || null,
          object_id: entry.object_id || null,
          entity_id: entry.entity_id || null,
        }))
      : [];
    return {
      format: "switch-vision-mqtt-maintenance-scan-v1",
      exported_at: new Date().toISOString(),
      current_expected_count: Number(plan.current_expected_count || 0),
      current_retained_count: Number(plan.current_retained_count || 0),
      current_missing_retained_count: Number(
        plan.current_missing_retained_count || 0
      ),
      owned_retained_count: Number(plan.owned_retained_count || 0),
      stale_count: Number(plan.stale_count || 0),
      snmp2mqtt_state: plan.snmp2mqtt_state || "unknown",
      generated_yaml_found: Boolean(plan.generated_yaml_found),
      stale_entries: stale,
      privacy: {
        raw_mqtt_payloads_included: false,
        credentials_included: false,
      },
    };
  }

  function renderPlan(data) {
    lastPlan = data && typeof data === "object" ? data : null;
    const summary = el("mqttRepairSummary");
    const list = el("mqttRepairEntities");
    const repair = el("repairMqttEntitiesButton");
    const exportButton = el("exportMqttResultsButton");
    if (!summary || !list || !repair) return;

    summary.replaceChildren();
    list.replaceChildren();

    if (!lastPlan) {
      repair.disabled = true;
      if (exportButton) exportButton.disabled = true;
      return;
    }

    const fields = [
      ["Current expected", lastPlan.current_expected_count ?? 0],
      ["Current retained", lastPlan.current_retained_count ?? 0],
      ["Switch Vision retained", lastPlan.owned_retained_count ?? 0],
      ["Stale found", lastPlan.stale_count ?? 0],
    ];
    for (const [label, value] of fields) {
      const tile = document.createElement("div");
      tile.className = "diag-tile";
      const name = document.createElement("div");
      name.className = "muted";
      name.textContent = label;
      const count = document.createElement("div");
      count.className = "diag-value";
      count.textContent = String(value);
      tile.append(name, count);
      summary.appendChild(tile);
    }

    const stale = Array.isArray(lastPlan.stale_entries)
      ? lastPlan.stale_entries
      : [];
    if (stale.length) {
      const details = document.createElement("details");
      details.className = "device-card";
      const title = document.createElement("summary");
      title.textContent = `Stale Switch Vision MQTT entities (${stale.length})`;
      details.appendChild(title);
      const ul = document.createElement("ul");
      for (const entry of stale) {
        const li = document.createElement("li");
        li.textContent =
          entry.entity_id ||
          `${entry.component || "sensor"}.${entry.object_id || "unknown"}`;
        ul.appendChild(li);
      }
      details.appendChild(ul);
      list.appendChild(details);
    } else {
      const clean = document.createElement("div");
      clean.className = "success";
      clean.textContent =
        "No stale Switch Vision MQTT discovery entities were found.";
      list.appendChild(clean);
    }

    repair.disabled = !(
      Number(lastPlan.stale_count) > 0 && lastPlan.plan_token
    );
    if (exportButton) exportButton.disabled = false;
  }

  function exportResults() {
    const status = el("mqttRepairStatus");
    const safe = safeExportPlan(lastPlan);
    if (!safe) {
      if (status) status.textContent = "Scan MQTT entities before exporting results.";
      return;
    }
    const blob = new Blob([JSON.stringify(safe, null, 2) + "\n"], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    anchor.href = url;
    anchor.download = `Switch_Vision_MQTT_Maintenance_${stamp}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    if (status) status.textContent = "Maintenance scan results exported.";
  }

  async function scan() {
    const button = el("scanMqttEntitiesButton");
    const repair = el("repairMqttEntitiesButton");
    const exportButton = el("exportMqttResultsButton");
    const status = el("mqttRepairStatus");
    if (!button || !repair || !status) return;

    button.disabled = true;
    repair.disabled = true;
    if (exportButton) exportButton.disabled = true;
    status.textContent =
      "Scanning retained Switch Vision MQTT discovery entries…";
    try {
      const response = await fetch(endpoint("api/maintenance/mqtt/scan"), {
        cache: "no-store",
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "MQTT maintenance scan failed");
      }
      renderPlan(data);
      status.textContent = data.stale_count
        ? `Scan complete: ${data.stale_count} stale Switch Vision MQTT ${
            data.stale_count === 1 ? "entity" : "entities"
          } found.`
        : "Scan complete: no stale Switch Vision MQTT entities found.";
    } catch (error) {
      renderPlan(null);
      status.textContent = `Could not scan MQTT entities: ${
        error.message || error
      }`;
    } finally {
      button.disabled = false;
    }
  }

  async function repair() {
    const button = el("repairMqttEntitiesButton");
    const status = el("mqttRepairStatus");
    if (!button || !status) return;

    const plan = lastPlan;
    if (
      !plan ||
      !plan.plan_token ||
      !(Number(plan.stale_count) > 0)
    ) {
      status.textContent = "Scan MQTT entities before repairing.";
      return;
    }

    const noun = plan.stale_count === 1 ? "entity" : "entities";
    if (
      !confirm(
        `Repair ${plan.stale_count} stale Switch Vision MQTT ${noun}? ` +
          "Only retained discovery entries proven to be owned by Switch Vision " +
          "SNMP2MQTT will be removed. Current generated entities and unrelated " +
          "MQTT integrations are preserved."
      )
    ) {
      return;
    }

    button.disabled = true;
    status.textContent = "Repairing stale Switch Vision MQTT entities…";
    try {
      const response = await fetch(endpoint("api/maintenance/mqtt/repair"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          plan_token: plan.plan_token,
          confirmation: "REPAIR STALE MQTT ENTITIES",
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "MQTT entity repair failed");
      }
      renderPlan(data);
      const warning =
        Array.isArray(data.warnings) && data.warnings.length
          ? ` Warnings: ${data.warnings.join(" | ")}`
          : "";
      const restarted = data.snmp2mqtt_restarted
        ? " SNMP2MQTT was restarted to republish the current configuration."
        : "";
      status.textContent =
        `Repair complete. Retained entries cleared: ${
          data.topics_cleared || 0
        }. Stale remaining: ${
          data.remaining_stale_count ?? data.stale_count ?? 0
        }.${restarted}${warning}`;
    } catch (error) {
      status.textContent = `Could not repair MQTT entities: ${
        error.message || error
      }`;
    } finally {
      if (lastPlan) {
        button.disabled = !(Number(lastPlan.stale_count) > 0);
      }
    }
  }

  async function resetEverything() {
    const button = el("resetEverythingButton");
    const status = el("resetEverythingStatus");
    if (!button || !status) return;

    const confirmation = window.prompt(
      "Reset all mutable Switch Vision settings and generated runtime state?\n\n" +
        "Installed apps, recovery/configuration backups, Support My Switch archives, " +
        "custom faceplates/logos, and protected originals are preserved.\n\n" +
        "Type RESET EVERYTHING exactly to continue."
    );

    if (confirmation === null) {
      status.textContent = "Reset Everything cancelled.";
      return;
    }
    if (confirmation !== "RESET EVERYTHING") {
      status.textContent = 'Reset Everything was not run. Type "RESET EVERYTHING" exactly.';
      return;
    }

    button.disabled = true;
    status.textContent = "Resetting Switch Vision mutable state…";
    try {
      const response = await fetch(endpoint("api/maintenance/reset-everything"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ confirmation }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Reset Everything failed");
      }
      const warnings =
        Array.isArray(data.warnings) && data.warnings.length
          ? " Warnings: " + data.warnings.join(" | ")
          : "";
      const preserved =
        Array.isArray(data.preserved) && data.preserved.length
          ? " Preserved: " + data.preserved.join(", ") + "."
          : "";
      status.textContent =
        (data.message || "Switch Vision reset complete.") +
        preserved + warnings;
      lastPlan = null;
      renderPlan(null);
      await loadInstallerBackups({ quiet: true });
      await window.SwitchVisionHubSettings?.loadMaintenanceBackupSettings?.();
    } catch (error) {
      status.textContent = "Reset Everything failed: " + (error.message || error);
    } finally {
      button.disabled = false;
    }
  }

  installMaintenanceStyles();

  document.querySelectorAll("[data-maintenance-tab]").forEach((tab) => {
    tab.addEventListener("click", () =>
      selectMaintenanceTab(tab.dataset.maintenanceTab || "backups")
    );
    tab.addEventListener("keydown", maintenanceTabKeydown);
  });

  const open = el("openMaintenanceButton");
  if (open) {
    open.addEventListener("click", () => openMaintenance("backups"));
  }
  el("refreshInstallerBackupsButton")?.addEventListener("click", () => loadInstallerBackups());
  el("installerBackupAutomaticRetention")?.addEventListener("click", toggleInstallerBackupRetention);
  el("createInstallerBackupButton")?.addEventListener("click", () =>
    runInstallerBackupAction("create_backup", {}, el("createInstallerBackupButton"))
  );
  el("scanMqttEntitiesButton")?.addEventListener("click", scan);
  el("repairMqttEntitiesButton")?.addEventListener("click", repair);
  el("exportMqttResultsButton")?.addEventListener("click", exportResults);
  el("resetEverythingButton")?.addEventListener("click", resetEverything);

  const query = new URLSearchParams(window.location.search);
  const requestedView = query.get("view");
  if (requestedView === "maintenance") {
    openMaintenance(query.get("tab") || "backups");
  } else if (requestedView === "configuration") {
    openMaintenance("configuration");
  } else if (requestedView === "profiles") {
    openMaintenance("calibrations");
    document.addEventListener(
      "DOMContentLoaded",
      () => window.SwitchVisionCalibrationProfiles?.load?.(),
      { once: true }
    );
  }

  window.SwitchVisionMaintenance = {
    open: openMaintenance,
    selectTab: selectMaintenanceTab,
    loadInstallerBackups,
    runInstallerBackupAction,
    toggleInstallerBackupRetention,
    scan,
    repair,
    exportResults,
    resetEverything,
  };
})();
