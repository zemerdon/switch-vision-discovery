#!/usr/bin/env python3
"""Local Home Assistant Ingress UI for Support My Switch.

The UI creates privacy-processed contribution bundles by invoking the existing
support_my_switch.sh backend. It never sends email or stores mail credentials.
"""
from __future__ import annotations

import argparse
import base64
import binascii
import copy
from contextlib import contextmanager
import html
import ipaddress
import json
import mimetypes
import os
import subprocess
import threading
import signal
import time
import traceback
import zipfile
import hashlib
import re
import shutil
import ssl
import unicodedata

import yaml
from websockets.sync.client import connect as websocket_connect
from email.message import EmailMessage
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import quote, unquote, urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from registry_lookup import lookup as registry_lookup
from mqtt_maintenance_runtime import (
    generated_yaml_generation_id,
    repair_mqtt_entities,
    scan_mqtt_entities,
    verify_generated_yaml_loaded,
)
from discovery_backups import (
    create_pre_mutation_backup,
    discovery_backup_status,
    enforce_retention,
    remove_discovery_backup,
)
from discovery_history import (
    DEFAULT_HISTORY_PATH as DEFAULT_DISCOVERY_HISTORY,
    append_discovery_history,
    discovery_history_snapshot,
    sanitize_debug_text,
)
import device_control as device_control_state
import dashboard_device_order

SUPPORT_ADDRESS = "switch-vision@zemerdon.com"
SUPERVISOR_INGRESS_IP = "172.30.32.2"
GITHUB_SPONSORS_URL = "https://github.com/sponsors/zemerdon"
HUB_MOTD_ENV_VAR = "SWITCH_VISION_HUB_MOTD"
HUB_MOTD_DEFAULT = (
    "Thank you for your continued support. Please use Support My Switch and submit your "
    "contribution package to switch-vision@zemerdon.com. Even if nothing is wrong, a "
    "contribution package validates correctness. Also feel free to express any feedback, "
    "ideas, or bugs. If any faceplate geometry is not correct, can you please click Reset "
    "Faceplate in the Calibration tool, and if that doesn't work, let me know please."
)
HUB_MOTD_MAX_CHARS = 500
DEFAULT_CONTRIBUTIONS_DIR = Path("/share/switch_vision/contributions")
DEFAULT_OPTIONS_FILE = Path("/data/options.json")
DEFAULT_SUPPORT_SCRIPT = Path("/support_my_switch.sh")
DEFAULT_DISCOVERY_SCRIPT = Path("/discovery_job.sh")
DEFAULT_SHARE_DIR = Path("/share/switch_vision")
DEFAULT_INSTALLER_MAINTENANCE_RESPONSE = DEFAULT_SHARE_DIR / "installer-maintenance-response.json"
DEFAULT_REGISTRY_FILE = Path("/opt/switch-vision/devices/supported_devices.json")
DEFAULT_GENERATED_SNMP2MQTT = Path("/share/switch_vision/generated-snmp2mqtt.yaml")
DEFAULT_GENERATED_CARD = Path("/share/switch_vision/generated-dashboard-card.yaml")
DEFAULT_GENERATED_CARD_FULL = Path(
    os.environ.get(
        "SWITCH_VISION_GENERATED_CARD_FULL_PATH",
        str(dashboard_device_order.full_dashboard_path(DEFAULT_GENERATED_CARD)),
    )
)
DEFAULT_UNIFI_SNAPSHOT = Path("/share/switch_vision/unifi/devices.json")
DEFAULT_UNIFI_DIAGNOSTICS = Path("/share/switch_vision/unifi/diagnostics.json")
DEFAULT_DEVICE_CONTROL = Path(
    os.environ.get("SV_DEVICE_CONTROL_PATH", str(DEFAULT_SHARE_DIR / "device-control.json"))
)
DEFAULT_CONFIGURATION_RESTORE_PENDING = DEFAULT_SHARE_DIR / "configuration-restore-pending.json"
COMPLETE_BACKUP_FORMAT = "switch-vision-complete-backup-v1"
COMPLETE_BACKUP_SCHEMA_VERSION = 1
MAX_COMPLETE_BACKUP_BYTES = 128 * 1024 * 1024
MAX_COMPLETE_BACKUP_ASSET_BYTES = 16 * 1024 * 1024
DEFAULT_DISCOVERY_LOG = DEFAULT_SHARE_DIR / "discovery-web.log"
_current_debug_override = os.environ.get("SV_CURRENT_DISCOVERY_DEBUG_PATH", "").strip()
if _current_debug_override:
    DEFAULT_CURRENT_DISCOVERY_DEBUG = Path(_current_debug_override)
elif Path("/data").is_dir() and os.access("/data", os.W_OK):
    DEFAULT_CURRENT_DISCOVERY_DEBUG = Path("/data/current-discovery-debug.log")
else:
    DEFAULT_CURRENT_DISCOVERY_DEBUG = Path("/tmp/switch-vision-current-discovery-debug.log")
DEFAULT_SNMPWALKS_DIR = DEFAULT_SHARE_DIR / "snmpwalks"
DEFAULT_CAPABILITIES_DIR = DEFAULT_SHARE_DIR / "capabilities"
DEFAULT_SNMP_RETIREMENT_STATE = Path("/data/snmp2mqtt-retirement-topics.json")
SNMP_RESET_FILES = (
    DEFAULT_SHARE_DIR / "snmpwalk.txt",
    DEFAULT_SHARE_DIR / "generated-snmp2mqtt.yaml",
    DEFAULT_SHARE_DIR / "generated-dashboard-card.yaml",
    DEFAULT_GENERATED_CARD_FULL,
    DEFAULT_SHARE_DIR / "discovery-report.txt",
    DEFAULT_SHARE_DIR / "last-discovery-run.txt",
    DEFAULT_SHARE_DIR / "snmpwalk.log",
    DEFAULT_SHARE_DIR / "live-snmpwalk.log",
)

UNIFI2MQTT_DEFAULT_OPTIONS = {
    # Legacy single-transport fields remain readable for migration compatibility.
    "transport": "local",
    "controller_url": "https://192.168.1.1",
    "host_id": "auto",
    "site_id": "auto",
    "api_key": "",
    "verify_ssl": "false",
    "allow_insecure_http": "false",
    # Preferred single-controller connection model.
    "priority_transport": "local",
    "fallback_transport": "remote",
    "local_controller_url": "https://192.168.1.1:11443",
    "local_site_id": "auto",
    "local_api_key": "",
    "local_verify_ssl": "false",
    "local_allow_insecure_http": "false",
    "remote_host_id": "auto",
    "remote_site_id": "auto",
    "remote_api_key": "",
    # Optional first-class multi-controller configuration.
    "controllers": [],
    "poll_interval": "10",
    "mqtt_host": "",
    "mqtt_port": "1883",
    "mqtt_username": "",
    "mqtt_password": "",
    "mqtt_tls": "false",
    "mqtt_verify_ssl": "true",
    "mqtt_ca": "",
    "mqtt_topic_prefix": "switch_vision/unifi",
    "mqtt_discovery_prefix": "homeassistant",
}
UNIFI2MQTT_SECRET_FIELDS = {
    "api_key",
    "local_api_key",
    "remote_api_key",
    "mqtt_password",
}

DISCOVERY_RESET_OPTIONS = {
    "input_path": "/share/switch_vision/snmpwalk.txt",
    "snmpwalks_dir": "/share/switch_vision/snmpwalks",
    "report_path": "/share/switch_vision/discovery-report.txt",
    "run_snmp_walks": "true",
    "enable_switch_list": "true",
    "switches": [{
        "switch_name": "",
        "switch_host": "",
        "sensor_prefix": "",
        "snmp_community": "readonly",
        "enabled": "enabled",
        "walk_mode": "targeted",
        "switch_model": "auto",
        "card_header_title": "",
    }],
    "stack_member_prefixes": [],
    "parse_all_walks": "false",
    "generate_snmp2mqtt": "true",
    "clean_output_before_walk": "false",
    "targets_csv": "/share/switch_vision/discovery-targets.csv",
    "last_run_summary_path": "/share/switch_vision/last-discovery-run.txt",
    "generated_yaml_path": "/share/switch_vision/generated-snmp2mqtt.yaml",
    "generated_card_path": "/share/switch_vision/generated-dashboard-card.yaml",
    "snmp_timeout": "3",
    "snmp_retries": "1",
    "snmp_log_path": "/share/switch_vision/snmpwalk.log",
    "minimum_valid_walk_lines": "100",
    "backup_retention_enabled": "true",
    "backup_retention_count": 5,
    "generate_support_my_switch_bundle": "true",
    "support_mask_management_ips": "true",
    "support_mask_mac_addresses": "true",
    "support_mask_hostnames": "true",
    "support_mask_vlan_names": "true",
    "support_mask_interface_descriptions": "true",
    "support_contributor_type": "anonymous",
    "support_contributor_value": "",
}

SNMP2MQTT_RESET_OPTIONS = {
    "mqtt": {"host": "", "port": 1883, "username": "", "password": ""},
    "targets_path": "/config/app_configs/switch_vision_snmp2mqtt/targets.yaml",
    "use_switch_vision_generated_yaml": True,
    "switch_vision_generated_yaml_path": "/share/switch_vision/generated-snmp2mqtt.yaml",
    "imported_targets_path": "/config/app_configs/switch_vision_snmp2mqtt/imported/generated-snmp2mqtt.yaml",
    "backup_existing_config": False,
    "homeassistant": {"discovery": True, "prefix": "homeassistant"},
}

INSTALLER_RESET_SETTINGS = {
    "release_api_url": "https://api.github.com/repos/zemerdon/switch-vision-releases/releases/latest",
    "allow_custom_release_source": False,
    "release_asset_pattern": "switch-vision-*.zip",
    "preserve_custom_assets": True,
    "create_backup": True,
    "allow_prerelease": False,
    "backup_retention": 5,
}

RESET_EVERYTHING_CONFIRMATION = "RESET EVERYTHING"

UI_PREFERENCES_PATH = Path("/share/switch_vision/ui-preferences.json")
UI_TEXT_SIZE_MIN_PX = 10
UI_TEXT_SIZE_MAX_PX = 20
UI_TEXT_SIZE_DEFAULT_PX = 16
UI_TEXT_SIZE_LEGACY = {"normal": 16, "small": 14}
_UI_DEFAULTS = {
    "density": "comfortable",
    "text_size": UI_TEXT_SIZE_DEFAULT_PX,
    "content_width": "standard",
    "show_unifi_integration": True,
}
_UI_ALLOWED = {
    "density": {"spacious", "comfortable", "compact", "dense", "ultra_dense"},
    "content_width": {
        "standard", "standard_plus", "wide", "wide_plus", "extra_wide",
        "extra_wide_plus", "ultra_wide", "ultra_wide_plus", "max_wide", "full",
    },
}


def _normalise_ui_text_size(value: Any) -> int:
    """Resolve legacy labels and explicit values to a safe 10-20 px size."""
    if isinstance(value, bool):
        return UI_TEXT_SIZE_DEFAULT_PX
    if isinstance(value, str):
        text = value.strip().lower()
        if text in UI_TEXT_SIZE_LEGACY:
            return UI_TEXT_SIZE_LEGACY[text]
        if text.endswith("px"):
            text = text[:-2].strip()
        if not text.isdigit():
            return UI_TEXT_SIZE_DEFAULT_PX
        pixels = int(text)
    elif isinstance(value, int):
        pixels = value
    else:
        return UI_TEXT_SIZE_DEFAULT_PX
    if UI_TEXT_SIZE_MIN_PX <= pixels <= UI_TEXT_SIZE_MAX_PX:
        return pixels
    return UI_TEXT_SIZE_DEFAULT_PX


def _discovery_ui_preferences() -> dict[str, Any]:
    """Read and validate shared Switch Vision Discovery UI preferences."""
    values = dict(_UI_DEFAULTS)
    try:
        document = json.loads(UI_PREFERENCES_PATH.read_text(encoding="utf-8"))
        discovery = document.get("discovery", {}) if isinstance(document, dict) else {}
        if isinstance(discovery, dict):
            for key, allowed in _UI_ALLOWED.items():
                candidate = str(discovery.get(key, values[key])).strip().lower()
                if candidate in allowed:
                    values[key] = candidate
            values["text_size"] = _normalise_ui_text_size(
                discovery.get("text_size", values["text_size"])
            )
            values["show_unifi_integration"] = bool(
                discovery.get("show_unifi_integration", values["show_unifi_integration"])
            )
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        pass
    return values


def _hub_motd_text() -> str:
    """Return the bounded operator notice rendered in the Hub home view."""
    raw = os.environ.get(HUB_MOTD_ENV_VAR, "")
    value = " ".join(str(raw).split())
    if not value:
        return HUB_MOTD_DEFAULT
    return value[:HUB_MOTD_MAX_CHARS]


def _page_with_ui_preferences(version: str | None = None) -> str:
    """Apply current UI preferences and inject bounded runtime metadata."""
    preferences = _discovery_ui_preferences()
    classes = " ".join(
        (
            f"density-{preferences['density']}",
            f"width-{preferences['content_width']}",
        )
    )
    document_version = str(
        version
        or os.environ.get("SWITCH_VISION_DISCOVERY_VERSION", "unknown")
        or "unknown"
    ).strip()
    page = _PAGE.replace(
        "<body><main>",
        (
            f'<body class="{classes}" '
            f'data-sv-discovery-version="{html.escape(document_version, quote=True)}" '
            f'style="--sv-font-body:{preferences["text_size"]}px"><main>'
        ),
        1,
    )
    return page.replace("__SV_HUB_MOTD__", html.escape(_hub_motd_text()), 1)

DISCOVERY_EXPORT_FORMAT = "switch-vision-discovery-config-v2"
DISCOVERY_IMPORT_FORMATS = {
    "switch-vision-discovery-config-v1",
    DISCOVERY_EXPORT_FORMAT,
}
DISCOVERY_CONFIG_KEYS = {
    "input_path", "snmpwalks_dir", "report_path", "run_snmp_walks",
    "enable_switch_list", "switches", "stack_member_prefixes",
    "parse_all_walks", "generate_snmp2mqtt", "clean_output_before_walk",
    "targets_csv", "last_run_summary_path", "generated_yaml_path",
    "generated_card_path", "snmp_timeout", "snmp_retries",
    "snmp_log_path", "minimum_valid_walk_lines",
    "backup_retention_enabled", "backup_retention_count",
}


def _discovery_export(options_file: Path, version: str) -> dict[str, Any]:
    # Supervisor is the authoritative persistent configuration source. The
    # options_file argument is retained for call-site compatibility only.
    del options_file
    options = _self_addon_options()
    exported = {key: options[key] for key in DISCOVERY_CONFIG_KEYS if key in options}
    # v2 exports make the persistent switch state explicit even when the live
    # options came from a pre-v2.1.8 installation where the field was absent.
    switches = exported.get("switches")
    if isinstance(switches, list):
        normalized_switches: list[Any] = []
        for index, item in enumerate(switches, start=1):
            if isinstance(item, dict):
                row = dict(item)
                row["enabled"] = _switch_enabled_state(
                    row.get("enabled", "enabled"),
                    f"Switch entry {index} enabled",
                )
                normalized_switches.append(row)
            else:
                normalized_switches.append(item)
        exported["switches"] = normalized_switches
    return {
        "format": DISCOVERY_EXPORT_FORMAT,
        "switch_vision_version": version,
        "exported_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "configuration": exported,
    }


SWITCHES_EXPORT_FORMAT = "switch-vision-switch-configuration-v1"
_SWITCH_EXPORT_FIELDS = {
    "switch_name", "display_name", "switch_host", "sensor_prefix", "enabled",
    "walk_mode", "switch_model", "card_header_title", "output_dir",
}
_STACK_EXPORT_FIELDS = {
    "switch_name", "member", "display_name", "sensor_prefix", "card_header_title",
}


def _switches_export(version: str) -> dict[str, Any]:
    """Return only portable, non-secret switch and stack configuration."""
    settings = _discovery_settings_status().get("settings", {})
    exported_switches: list[dict[str, Any]] = []
    for raw in settings.get("switches", []) if isinstance(settings, dict) else []:
        if not isinstance(raw, dict):
            continue
        if not (
            str(raw.get("switch_name") or "").strip()
            or str(raw.get("switch_host") or "").strip()
        ):
            continue
        exported_switches.append({
            key: copy.deepcopy(value)
            for key, value in raw.items()
            if key in _SWITCH_EXPORT_FIELDS
        })
    exported_stack = [
        {
            key: copy.deepcopy(value)
            for key, value in raw.items()
            if key in _STACK_EXPORT_FIELDS
        }
        for raw in settings.get("stack_member_prefixes", [])
        if isinstance(raw, dict)
    ] if isinstance(settings, dict) and isinstance(settings.get("stack_member_prefixes"), list) else []
    return {
        "format": SWITCHES_EXPORT_FORMAT,
        "switch_vision_version": version,
        "exported_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "secrets_included": False,
        "switches": exported_switches,
        "stack_member_prefixes": exported_stack,
    }


def _validate_switches_import(data: Any) -> dict[str, list[dict[str, Any]]]:
    if not isinstance(data, dict) or data.get("format") != SWITCHES_EXPORT_FORMAT:
        raise ValueError("This is not a supported Switch Vision switch configuration export.")
    if data.get("secrets_included") is not False:
        raise ValueError("Switch configuration exports must not contain secrets.")

    raw_switches = data.get("switches")
    raw_stack = data.get("stack_member_prefixes")
    if not isinstance(raw_switches, list) or len(raw_switches) > 256:
        raise ValueError("Switch configuration switch list is invalid.")
    if not isinstance(raw_stack, list) or len(raw_stack) > 512:
        raise ValueError("Switch configuration stack member list is invalid.")

    switches: list[dict[str, Any]] = []
    validation_switches: list[dict[str, Any]] = []
    for index, raw in enumerate(raw_switches, start=1):
        if not isinstance(raw, dict):
            raise ValueError(f"Switch entry {index} must be an object.")
        unknown = sorted(set(raw) - _SWITCH_EXPORT_FIELDS)
        if unknown:
            raise ValueError(f"Switch entry {index} contains unsupported field '{unknown[0]}'.")
        candidate = dict(raw)
        candidate["snmp_community"] = "__switch_vision_import_pending__"
        validated = _validate_switch_row(candidate, index)
        portable = {
            key: copy.deepcopy(value)
            for key, value in validated.items()
            if key in _SWITCH_EXPORT_FIELDS
        }
        switches.append(portable)
        validation_switches.append(dict(validated))

    stack: list[dict[str, Any]] = []
    for index, raw in enumerate(raw_stack, start=1):
        if not isinstance(raw, dict):
            raise ValueError(f"Stack member entry {index} must be an object.")
        unknown = sorted(set(raw) - _STACK_EXPORT_FIELDS)
        if unknown:
            raise ValueError(f"Stack member entry {index} contains unsupported field '{unknown[0]}'.")
        stack.append(_validate_stack_row(dict(raw), index))

    _validate_inventory_identities({
        "switches": validation_switches,
        "stack_member_prefixes": stack,
    })
    return {"switches": switches, "stack_member_prefixes": stack}


def _import_switches_only(data: Any) -> dict[str, Any]:
    imported = _validate_switches_import(data)
    pending = _load_configuration_restore_pending()
    pending["discovery_switches"] = [
        dict(row)
        | {
            "snmp_community": "",
            "snmp_community_configured": False,
            "restore_pending": True,
        }
        for row in imported["switches"]
    ]
    pending["discovery_stack_member_prefixes"] = [
        dict(row) for row in imported["stack_member_prefixes"]
    ]
    _save_configuration_restore_pending(pending)
    return {
        "imported": True,
        "format": SWITCHES_EXPORT_FORMAT,
        "switch_count": len(imported["switches"]),
        "stack_member_count": len(imported["stack_member_prefixes"]),
        "credentials_included": False,
        "restart_required": False,
    }


def _plain_text(value: Any, field: str, *, max_length: int, allow_empty: bool = True) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be text.")
    if len(value) > max_length:
        raise ValueError(f"{field} is too long.")
    if any(ord(char) < 32 for char in value):
        raise ValueError(f"{field} contains control characters.")
    if not allow_empty and not value.strip():
        raise ValueError(f"{field} cannot be empty.")
    return value


def _share_path(value: Any, field: str) -> str:
    text = _plain_text(value, field, max_length=512, allow_empty=False).strip()
    path = PurePosixPath(text)
    if not path.is_absolute() or ".." in path.parts:
        raise ValueError(f"{field} must be an absolute path under /share/switch_vision.")
    try:
        path.relative_to(PurePosixPath("/share/switch_vision"))
    except ValueError as exc:
        raise ValueError(f"{field} must stay under /share/switch_vision.") from exc
    return str(path)


def _bool_string(value: Any, field: str) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str) and value.strip().lower() in {"true", "false"}:
        return value.strip().lower()
    raise ValueError(f"{field} must be true or false.")


def _switch_enabled_state(value: Any, field: str) -> str:
    """Normalize a persistent switch generation state."""
    if isinstance(value, bool):
        return "enabled" if value else "disabled"
    if isinstance(value, str):
        text = value.strip().lower()
        if text in {"enabled", "enable", "true", "on", "yes", "1", ""}:
            return "enabled"
        if text in {"disabled", "disable", "false", "off", "no", "0"}:
            return "disabled"
    raise ValueError(f"{field} must be enabled or disabled.")


def _bounded_int_string(value: Any, field: str, minimum: int, maximum: int) -> str:
    if isinstance(value, bool):
        raise ValueError(f"{field} must be a number.")
    text = str(value).strip()
    if not re.fullmatch(r"\d+", text):
        raise ValueError(f"{field} must be a whole number.")
    number = int(text)
    if number < minimum or number > maximum:
        raise ValueError(f"{field} must be between {minimum} and {maximum}.")
    return text


def _manual_snmp_override_models() -> set[str]:
    """Return exact SNMP model overrides from the authoritative registry."""
    registry = _read_json(DEFAULT_REGISTRY_FILE)
    devices = registry.get("devices", []) if isinstance(registry, dict) else []
    models: set[str] = set()
    for device in devices if isinstance(devices, list) else []:
        if not isinstance(device, dict):
            continue
        vendor = str(device.get("vendor") or "").strip().casefold()
        model = str(device.get("model") or "").strip()
        if (
            model
            and vendor != "ubiquiti"
            and bool(device.get("discovery_support"))
            and str(device.get("mapping_profile") or "").strip()
        ):
            models.add(model)
    # Keep configuration import usable if the registry is temporarily unreadable.
    return models or {
        "WS-C3650-48PD-E", "WS-C3650-48PD-L", "WS-C2960X-48FPD-L",
        "WS-C2960X-24PS-L", "WS-C2960X-24TS-L", "WS-C2960XR-48LPS-I", "WS-C2960S-48FPD-L",
        "WS-C3560CG-8PC-S", "WS-C3750-48P", "WS-C3750X-48P",
        "EX3300-48P", "SG500X-24", "S5720-12TP-LI-AC",
        "S5735-L8P4X-A1", "CRS328-24P-4S+RM", "XS1930-10",
        "N2128PX-ON", "PowerConnect 5548P",
    }


def _validate_switch_row(item: Any, index: int) -> dict[str, Any]:
    if not isinstance(item, dict):
        raise ValueError(f"Switch entry {index} must be an object.")
    required = {"switch_name", "switch_host", "sensor_prefix", "snmp_community"}
    missing = [key for key in required if key not in item]
    if missing:
        raise ValueError(f"Switch entry {index} is missing {missing[0]}.")
    row = dict(item)
    switch_name = _plain_text(row.get("switch_name"), f"Switch entry {index} switch_name", max_length=64).strip()
    switch_host = _plain_text(row.get("switch_host"), f"Switch entry {index} switch_host", max_length=255).strip()
    sensor_prefix = _plain_text(row.get("sensor_prefix"), f"Switch entry {index} sensor_prefix", max_length=64).strip()
    community = _plain_text(row.get("snmp_community"), f"Switch entry {index} snmp_community", max_length=256, allow_empty=False)

    # A row with no name and no host is the Home Assistant UI placeholder.
    # Older/stale Supervisor state may leave a generated sensor_prefix behind;
    # that must not turn the placeholder into a real switch identity.
    if not switch_name and not switch_host:
        sensor_prefix = ""
    if switch_name and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", switch_name):
        raise ValueError(f"Switch entry {index} switch_name contains unsupported characters.")
    if switch_host and (any(ch.isspace() for ch in switch_host) or "/" in switch_host):
        raise ValueError(f"Switch entry {index} switch_host is not a valid host value.")
    if sensor_prefix and not re.fullmatch(r"[A-Za-z0-9_-]+", sensor_prefix):
        raise ValueError(f"Switch entry {index} sensor_prefix contains unsupported characters.")
    if (switch_name or switch_host or sensor_prefix) and (not switch_name or not switch_host):
        raise ValueError(f"Switch entry {index} requires both switch_name and switch_host.")
    row["switch_name"] = switch_name
    row["switch_host"] = switch_host
    row["sensor_prefix"] = sensor_prefix
    row["snmp_community"] = community
    # v2.1.8: switch rows are persistent. Missing enabled state is treated as
    # enabled for backward compatibility with every pre-v2.1.8 configuration.
    row["enabled"] = _switch_enabled_state(row.get("enabled", "enabled"), f"Switch entry {index} enabled")
    walk_mode = str(row.get("walk_mode", "targeted")).strip().lower()
    if walk_mode not in {"targeted", "full"}:
        raise ValueError(f"Switch entry {index} walk_mode must be targeted or full.")
    row["walk_mode"] = walk_mode
    allowed_models = {"auto"} | _manual_snmp_override_models()
    model = str(row.get("switch_model", "auto")).strip() or "auto"
    if model not in allowed_models:
        raise ValueError(f"Switch entry {index} switch_model is not supported by this build.")
    row["switch_model"] = model
    for key in ("display_name", "card_header_title"):
        if key in row:
            row[key] = _plain_text(row[key], f"Switch entry {index} {key}", max_length=120)
    if "output_dir" in row and str(row.get("output_dir") or "").strip():
        output = _share_path(row["output_dir"], f"Switch entry {index} output_dir")
        if not (output == "/share/switch_vision/snmpwalks" or output.startswith("/share/switch_vision/snmpwalks/")):
            raise ValueError(f"Switch entry {index} output_dir must stay under /share/switch_vision/snmpwalks.")
        row["output_dir"] = output
    return row


def _validate_stack_row(item: Any, index: int) -> dict[str, Any]:
    if not isinstance(item, dict):
        raise ValueError(f"Stack member entry {index} must be an object.")
    row = dict(item)
    switch_name = _plain_text(row.get("switch_name", ""), f"Stack member entry {index} switch_name", max_length=64).strip()
    member = _plain_text(row.get("member", ""), f"Stack member entry {index} member", max_length=8).strip()
    if not switch_name or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", switch_name):
        raise ValueError(f"Stack member entry {index} has an invalid switch_name.")
    if not re.fullmatch(r"\d+", member) or not (1 <= int(member) <= 64):
        raise ValueError(f"Stack member entry {index} member must be between 1 and 64.")
    row["switch_name"] = switch_name
    row["member"] = member
    for key, limit in (("display_name", 120), ("sensor_prefix", 64), ("card_header_title", 120)):
        if key in row:
            row[key] = _plain_text(row[key], f"Stack member entry {index} {key}", max_length=limit)
    if row.get("sensor_prefix") and not re.fullmatch(r"[A-Za-z0-9_-]+", str(row["sensor_prefix"])):
        raise ValueError(f"Stack member entry {index} sensor_prefix contains unsupported characters.")
    return row



def _ha_prefix_identity(value: str) -> str:
    """Return the Home Assistant/SNMP2MQTT identity key for a sensor prefix."""
    text = value.strip().casefold().replace("-", "_")
    text = re.sub(r"[^a-z0-9_]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    return text


def _validate_inventory_identities(configuration: dict[str, Any]) -> None:
    """Reject switch/folder and generated entity identity collisions.

    Disabled rows are intentionally included: a saved disabled row can be
    re-enabled later and must not reserve an identity already used elsewhere.
    """
    switches = configuration.get("switches")
    if not isinstance(switches, list):
        switches = []
    stack_rows = configuration.get("stack_member_prefixes")
    if not isinstance(stack_rows, list):
        stack_rows = []

    switch_names: dict[str, str] = {}
    prefix_owners: dict[str, tuple[str, str, str]] = {}
    parent_prefixes: dict[str, str] = {}

    for index, raw in enumerate(switches, start=1):
        if not isinstance(raw, dict):
            continue
        name = str(raw.get("switch_name") or "").strip()
        host = str(raw.get("switch_host") or "").strip()
        configured_prefix = str(raw.get("sensor_prefix") or "").strip()
        if not (name or host):
            continue
        if not name:
            raise ValueError(f"Switch entry {index} requires switch_name for a stable identity.")
        name_key = name.casefold()
        previous = switch_names.get(name_key)
        if previous is not None:
            raise ValueError(
                f"Switch entry {index} switch_name '{name}' duplicates {previous}. "
                "Every saved switch_name must be unique, including disabled rows."
            )
        switch_names[name_key] = f"Switch entry {index}"

        effective_prefix = configured_prefix or name
        prefix_key = _ha_prefix_identity(effective_prefix)
        if not prefix_key:
            raise ValueError(f"Switch entry {index} does not produce a usable sensor_prefix identity.")
        previous_prefix = prefix_owners.get(prefix_key)
        if previous_prefix is not None:
            raise ValueError(
                f"Switch entry {index} sensor_prefix '{effective_prefix}' collides with "
                f"{previous_prefix[0]} prefix '{previous_prefix[1]}'."
            )
        owner = f"Switch entry {index}"
        prefix_owners[prefix_key] = (owner, effective_prefix, name_key)
        parent_prefixes[name_key] = prefix_key

    member_keys: dict[tuple[str, str], str] = {}
    for index, raw in enumerate(stack_rows, start=1):
        if not isinstance(raw, dict):
            continue
        name = str(raw.get("switch_name") or "").strip()
        member = str(raw.get("member") or raw.get("member_number") or "").strip()
        prefix = str(raw.get("sensor_prefix") or "").strip()
        if not (name or member or prefix):
            continue
        name_key = name.casefold()
        if name_key not in switch_names:
            raise ValueError(
                f"Stack member entry {index} references unknown switch_name '{name}'."
            )
        member_key = (name_key, member)
        previous_member = member_keys.get(member_key)
        if previous_member is not None:
            raise ValueError(
                f"Stack member entry {index} duplicates member {member} for switch '{name}' "
                f"already used by {previous_member}."
            )
        member_keys[member_key] = f"Stack member entry {index}"

        if not prefix:
            continue
        prefix_key = _ha_prefix_identity(prefix)
        if not prefix_key:
            raise ValueError(f"Stack member entry {index} does not produce a usable sensor_prefix identity.")
        previous_prefix = prefix_owners.get(prefix_key)
        if previous_prefix is None:
            prefix_owners[prefix_key] = (f"Stack member entry {index}", prefix, name_key)
            continue

        # Member 1 may deliberately reuse its own parent switch prefix. The
        # parent row is a management target/base identity, not a second set of
        # entities when stack-member prefixes are configured.
        own_parent_alias = (
            member == "1"
            and previous_prefix[2] == name_key
            and parent_prefixes.get(name_key) == prefix_key
        )
        if not own_parent_alias:
            raise ValueError(
                f"Stack member entry {index} sensor_prefix '{prefix}' collides with "
                f"{previous_prefix[0]} prefix '{previous_prefix[1]}'."
            )


def _saved_switch_text(
    row: dict[str, Any],
    primary: str,
    *legacy_aliases: str,
    default: str = "",
) -> str:
    """Resolve one saved switch field without allowing stale aliases to override it."""
    values = [
        str(row.get(key) or "").strip()
        for key in (primary, *legacy_aliases)
        if key in row and str(row.get(key) or "").strip()
    ]
    if not values:
        return default
    selected = values[0]
    if any(value != selected for value in values[1:]):
        raise ValueError(f"{primary} has conflicting saved aliases.")
    return selected


def _effective_discovery_switch_row(raw: Any, index: int) -> dict[str, Any]:
    """Canonicalize one saved row from the current Supervisor options snapshot."""
    if not isinstance(raw, dict):
        raise ValueError(f"Switch entry {index} must be an object.")

    row: dict[str, Any] = {
        "switch_name": _saved_switch_text(
            raw, "switch_name", "switch", "selected_switch", "name"
        ),
        "switch_host": _saved_switch_text(
            raw, "switch_host", "host", "manual_switch_host"
        ),
        "sensor_prefix": _saved_switch_text(
            raw, "sensor_prefix", "entity_prefix", "prefix"
        ),
        "snmp_community": _saved_switch_text(
            raw, "snmp_community", "community"
        ),
        "enabled": raw.get("enabled", "enabled"),
        "walk_mode": _saved_switch_text(
            raw, "walk_mode", "mode", default="targeted"
        ) or "targeted",
        "switch_model": _saved_switch_text(
            raw, "switch_model", "model_override", default="auto"
        ) or "auto",
    }
    if "card_header_title" in raw:
        row["card_header_title"] = _saved_switch_text(raw, "card_header_title")
    if "display_name" in raw or "card_title" in raw:
        row["display_name"] = _saved_switch_text(
            raw, "display_name", "card_title"
        )
    if "output_dir" in raw:
        row["output_dir"] = raw.get("output_dir")
    return _validate_switch_row(row, index)


def _effective_discovery_options(options: dict[str, Any]) -> dict[str, Any]:
    """Return the deterministic effective config consumed by every Discovery run."""
    if not isinstance(options, dict):
        raise RuntimeError("Discovery options must be an object.")
    effective = dict(options)
    rows = options.get("switches")
    if not isinstance(rows, list):
        rows = []
    effective["switches"] = [
        _effective_discovery_switch_row(raw, index)
        for index, raw in enumerate(rows, start=1)
    ]
    _validate_inventory_identities(effective)
    return effective


def _discovery_effective_config_provenance(
    options: dict[str, Any],
    *,
    source: str = "supervisor",
) -> dict[str, Any]:
    """Expose credential-safe proof of the exact switch values used for a run."""
    effective = _effective_discovery_options(options)
    safe_switches: list[dict[str, Any]] = []
    for index, row in enumerate(effective.get("switches", []), start=1):
        if not isinstance(row, dict):
            continue
        community = str(row.get("snmp_community") or "")
        safe_switches.append({
            "index": index,
            "switch_name": str(row.get("switch_name") or ""),
            "switch_host": str(row.get("switch_host") or ""),
            "sensor_prefix": str(row.get("sensor_prefix") or ""),
            "switch_model": str(row.get("switch_model") or "auto"),
            "enabled": str(row.get("enabled") or "enabled"),
            "walk_mode": str(row.get("walk_mode") or "targeted"),
            "credential_configured": bool(community),
        })
    material = {
        "enable_switch_list": str(effective.get("enable_switch_list") or ""),
        "snmp_timeout": str(effective.get("snmp_timeout") or ""),
        "snmp_retries": str(effective.get("snmp_retries") or ""),
        "switches": safe_switches,
    }
    revision = hashlib.sha256(
        json.dumps(material, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return {
        "source": source,
        "revision": revision,
        "revision_scope": "non_secret_effective_config",
        "credential_evidence": "configured_state_only",
        "switches": safe_switches,
    }


def _validate_discovery_import(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("Configuration file must contain a JSON object.")
    if data.get("format") not in DISCOVERY_IMPORT_FORMATS:
        raise ValueError("This is not a supported Switch Vision Discovery export.")
    configuration = data.get("configuration")
    if not isinstance(configuration, dict):
        raise ValueError("The export does not contain a configuration object.")
    unknown = sorted(set(configuration) - DISCOVERY_CONFIG_KEYS)
    if unknown:
        raise ValueError(f"Unsupported configuration field: {unknown[0]}")

    validated = dict(configuration)
    path_fields = {
        "input_path", "snmpwalks_dir", "report_path", "targets_csv", "last_run_summary_path",
        "generated_yaml_path", "generated_card_path", "snmp_log_path",
    }
    for key in path_fields:
        if key in validated:
            validated[key] = _share_path(validated[key], key)
    if "snmpwalks_dir" in validated:
        walk_root = validated["snmpwalks_dir"]
        if not (walk_root == "/share/switch_vision/snmpwalks" or walk_root.startswith("/share/switch_vision/snmpwalks/")):
            raise ValueError("snmpwalks_dir must stay under /share/switch_vision/snmpwalks.")

    for key in {"run_snmp_walks", "enable_switch_list", "parse_all_walks", "generate_snmp2mqtt", "clean_output_before_walk", "backup_retention_enabled"}:
        if key in validated:
            validated[key] = _bool_string(validated[key], key)
    if "snmp_timeout" in validated:
        validated["snmp_timeout"] = _bounded_int_string(validated["snmp_timeout"], "snmp_timeout", 1, 30)
    if "snmp_retries" in validated:
        validated["snmp_retries"] = _bounded_int_string(validated["snmp_retries"], "snmp_retries", 0, 10)
    if "minimum_valid_walk_lines" in validated:
        validated["minimum_valid_walk_lines"] = _bounded_int_string(validated["minimum_valid_walk_lines"], "minimum_valid_walk_lines", 1, 1000000)
    if "backup_retention_count" in validated:
        validated["backup_retention_count"] = int(
            _bounded_int_string(validated["backup_retention_count"], "backup_retention_count", 1, 10)
        )

    switches = validated.get("switches", [])
    if not isinstance(switches, list):
        raise ValueError("switches must be a list.")
    if len(switches) > 256:
        raise ValueError("The configuration contains too many switches.")
    validated["switches"] = [_validate_switch_row(item, index) for index, item in enumerate(switches, start=1)]

    stack = validated.get("stack_member_prefixes", [])
    if not isinstance(stack, list):
        raise ValueError("stack_member_prefixes must be a list.")
    if len(stack) > 512:
        raise ValueError("The configuration contains too many stack members.")
    validated["stack_member_prefixes"] = [_validate_stack_row(item, index) for index, item in enumerate(stack, start=1)]
    _validate_inventory_identities(validated)
    return validated


def _configured_switch_count(rows: Any) -> int:
    """Count real configured switch rows, excluding the blank UI placeholder."""
    if not isinstance(rows, list):
        return 0
    count = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        if any(
            str(row.get(key) or "").strip()
            for key in ("switch_name", "switch_host")
        ):
            count += 1
    return count


def _import_discovery_options(imported: dict[str, Any]) -> None:
    """Persist imported Discovery configuration through Supervisor only."""
    with _OPTIONS_UPDATE_LOCK:
        current = _self_addon_options()
        merged = dict(current)
        merged.update(imported)
        _validate_inventory_identities(merged)
        create_pre_mutation_backup(current, reason="configuration_import")
        _supervisor_json(
            "/addons/self/options",
            method="POST",
            timeout=20.0,
            payload={"options": merged},
        )
        confirmed = _self_addon_options()
        for key, expected in imported.items():
            if confirmed.get(key) != expected:
                raise RuntimeError(
                    f"Home Assistant did not confirm imported Discovery option '{key}'."
                )
        if "switches" in imported:
            _reconcile_device_added_at(confirmed)
        enforce_retention(confirmed)


_STATE_LOCK = threading.Lock()
_STATE: dict[str, Any] = {
    "running": False,
    "started_at": None,
    "finished_at": None,
    "success": None,
    "message": "Ready",
    "log_tail": [],
}

_DISCOVERY_STATE_LOCK = threading.Lock()
_OPTIONS_UPDATE_LOCK = threading.Lock()
_DISCOVERY_PROCESS_LOCK = threading.Lock()
_OPERATION_LOCK = threading.Lock()
_DEVICE_MUTATION_LOCK = threading.Lock()
_DEVICE_STATE_RECONCILE_LOCK = threading.Lock()
_OPERATION_ACTIVE: dict[str, Any] = {"name": None, "started_at": None}
_DISCOVERY_PROCESS: subprocess.Popen[str] | None = None
_DISCOVERY_STOP_REQUESTED = threading.Event()
_DEVICE_STATE_RECONCILE_REQUESTED = 0
_DEVICE_STATE_RECONCILE_RUNNING = False
_DEVICE_STATE_RECONCILE_DEBOUNCE_SECONDS = 0.35
_DEVICE_STATE_RECONCILE_RETRY_SECONDS = 0.20

_DISCOVERY_STATE: dict[str, Any] = {
    "running": False,
    "started_at": None,
    "finished_at": None,
    "success": None,
    "message": "Idle / Ready",
    "log_tail": [],
    "stage": "Ready",
    "switch": "",
    "target": "",
    "command": "",
    "activity": "",
    "phase": "idle",
    "snmp2mqtt": {"status": "Not checked", "action": "none", "slug": None, "state": None, "message": "Waiting for Discovery"},
}



class OperationConflict(RuntimeError):
    """Raised when a conflicting Discovery/Support mutation is active."""


def _claim_operation(name: str) -> None:
    with _OPERATION_LOCK:
        active = _OPERATION_ACTIVE.get("name")
        if active:
            raise OperationConflict(
                f"{active} is already running. Wait for it to finish before starting {name}."
            )
        _OPERATION_ACTIVE["name"] = name
        _OPERATION_ACTIVE["started_at"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _release_operation(name: str) -> None:
    with _OPERATION_LOCK:
        if _OPERATION_ACTIVE.get("name") == name:
            _OPERATION_ACTIVE["name"] = None
            _OPERATION_ACTIVE["started_at"] = None


@contextmanager
def _exclusive_operation(name: str):
    _claim_operation(name)
    try:
        yield
    finally:
        _release_operation(name)


@contextmanager
def _device_configuration_update(name: str):
    """Serialize short device mutations while a background state apply runs.

    Full Discovery/regeneration operations still block device mutation. A device
    state application is different: it consumes a snapshot of saved state, so
    later device mutations are safe as long as they are serialized and a fresh
    reconciliation pass is queued afterward.
    """
    short_claimed = False
    with _DEVICE_MUTATION_LOCK:
        with _OPERATION_LOCK:
            active = _OPERATION_ACTIVE.get("name")
            if active and active != "Device state application":
                raise OperationConflict(
                    f"{active} is already running. Wait for it to finish before starting {name}."
                )
            if not active:
                _OPERATION_ACTIVE["name"] = name
                _OPERATION_ACTIVE["started_at"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
                short_claimed = True
        try:
            yield
        finally:
            if short_claimed:
                _release_operation(name)


def _safe_bool(value: Any, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
    return default


def _load_options(path: Path) -> dict[str, Any]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _support_settings_from_options(options: dict[str, Any]) -> dict[str, Any]:
    """Return Support My Switch settings without exposing unrelated options."""
    contributor_type = str(options.get("support_contributor_type") or "anonymous")
    if contributor_type not in {"anonymous", "first_name", "full_name", "github", "forum"}:
        contributor_type = "anonymous"
    contributor_value = (
        str(options.get("support_contributor_value") or "")
        .replace("\n", " ")
        .replace("\r", " ")
        .strip()[:120]
    )
    return {
        "mask_management_ips": _safe_bool(options.get("support_mask_management_ips"), True),
        "mask_mac_addresses": _safe_bool(options.get("support_mask_mac_addresses"), True),
        "mask_hostnames": _safe_bool(options.get("support_mask_hostnames"), True),
        "mask_vlan_names": _safe_bool(options.get("support_mask_vlan_names"), False),
        "mask_interface_descriptions": _safe_bool(options.get("support_mask_interface_descriptions"), False),
        "contributor_type": contributor_type,
        "contributor_value": contributor_value,
    }


def _defaults(options_file: Path) -> dict[str, Any]:
    return _support_settings_from_options(_load_options(options_file))


def _zip_member_json(archive: Path, suffix: str) -> Any:
    try:
        with zipfile.ZipFile(archive) as zf:
            candidates = [name for name in zf.namelist() if name.endswith(suffix)]
            if not candidates:
                return None
            return json.loads(zf.read(candidates[0]).decode("utf-8"))
    except (OSError, zipfile.BadZipFile, UnicodeDecodeError, json.JSONDecodeError):
        return None


def _latest_contribution(contributions_dir: Path) -> dict[str, Any] | None:
    archives = sorted(
        contributions_dir.glob("Switch_Vision_Contribution_SV-*.zip"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    ) if contributions_dir.is_dir() else []
    if not archives:
        return None
    archive = archives[0]
    stem = archive.stem
    email_path = archive.with_suffix(".eml")
    actions_path = archive.with_name(f"{stem}_Actions.html")
    manifest = _zip_member_json(archive, "/MANIFEST.json") or {}
    devices = _zip_member_json(archive, "/DEVICE_SUMMARY.json") or []
    privacy = manifest.get("privacy_options") or {}
    processing = manifest.get("sanitization_processing") or {}
    evidence = manifest.get("evidence") or {}
    return {
        "contribution_id": manifest.get("contribution_id") or "Unknown",
        "version": manifest.get("switch_vision_version") or "Unknown",
        "quality": manifest.get("bundle_quality") or "Unknown",
        "ready_to_send": bool(manifest.get("ready_to_send")),
        "created_at": manifest.get("created_at") or "",
        "archive": archive.name,
        "archive_size": archive.stat().st_size,
        "email": email_path.name if email_path.is_file() else None,
        "actions": actions_path.name if actions_path.is_file() else None,
        "devices": devices if isinstance(devices, list) else [],
        "privacy": privacy if isinstance(privacy, dict) else {},
        "processing": processing if isinstance(processing, dict) else {},
        "evidence": evidence if isinstance(evidence, dict) else {},
    }


def _state_snapshot() -> dict[str, Any]:
    with _STATE_LOCK:
        return json.loads(json.dumps(_STATE))


def _set_state(**updates: Any) -> None:
    with _STATE_LOCK:
        _STATE.update(updates)



def _discovery_state_snapshot() -> dict[str, Any]:
    with _DISCOVERY_STATE_LOCK:
        return json.loads(json.dumps(_DISCOVERY_STATE))


def _set_discovery_state(**updates: Any) -> None:
    with _DISCOVERY_STATE_LOCK:
        _DISCOVERY_STATE.update(updates)


def _reset_current_discovery_debug() -> None:
    """Start a fresh credential-sanitized debug session for one operation."""
    DEFAULT_CURRENT_DISCOVERY_DEBUG.parent.mkdir(parents=True, exist_ok=True)
    DEFAULT_CURRENT_DISCOVERY_DEBUG.write_text("", encoding="utf-8")
    os.chmod(DEFAULT_CURRENT_DISCOVERY_DEBUG, 0o600)


def _append_current_discovery_debug(value: Any) -> str:
    """Append one sanitized line and return the browser-safe text."""
    safe = sanitize_debug_text(value).replace("\x00", "")
    DEFAULT_CURRENT_DISCOVERY_DEBUG.parent.mkdir(parents=True, exist_ok=True)
    with DEFAULT_CURRENT_DISCOVERY_DEBUG.open("a", encoding="utf-8") as handle:
        handle.write(safe + "\n")
    try:
        os.chmod(DEFAULT_CURRENT_DISCOVERY_DEBUG, 0o600)
    except OSError:
        pass
    return safe


def _current_discovery_debug_snapshot() -> dict[str, Any]:
    state = _discovery_state_snapshot()
    try:
        text = DEFAULT_CURRENT_DISCOVERY_DEBUG.read_text(encoding="utf-8", errors="replace")
    except OSError:
        text = ""
    # Sanitize again at the browser boundary as defence in depth.
    safe_text = sanitize_debug_text(text).replace("\x00", "")
    return {
        "mode": state.get("mode") or "discovery",
        "running": bool(state.get("running")),
        "started_at": state.get("started_at"),
        "finished_at": state.get("finished_at"),
        "text": safe_text,
        "line_count": len(safe_text.splitlines()),
    }


class _DiscoveryDebugLines(list[str]):
    """Operation-local lines that are mirrored into the full sanitized session."""

    def append(self, value: Any) -> None:
        super().append(_append_current_discovery_debug(value))


def _parse_status_marker(line: str) -> dict[str, str] | None:
    if not line.startswith("SV_STATUS|"):
        return None
    result: dict[str, str] = {}
    for part in line.split("|")[1:]:
        key, sep, value = part.partition("=")
        if sep and key:
            result[key] = value
    return result


def _ensure_runtime_paths() -> None:
    """Create writable runtime paths required by Discovery and support bundles."""
    DEFAULT_SHARE_DIR.mkdir(parents=True, exist_ok=True)
    DEFAULT_CONTRIBUTIONS_DIR.mkdir(parents=True, exist_ok=True)
    DEFAULT_DISCOVERY_LOG.touch(exist_ok=True)


def _request_discovery_stop() -> bool:
    """Request a stop of the active Discovery process group."""
    if not _discovery_state_snapshot().get("running"):
        return False

    _DISCOVERY_STOP_REQUESTED.set()
    _set_discovery_state(
        message="Stopping Discovery",
        stage="Stopping Discovery",
        activity="Waiting for the current Discovery command to stop",
        command="Stop requested",
        phase="stopping",
    )

    with _DISCOVERY_PROCESS_LOCK:
        process = _DISCOVERY_PROCESS

    if process is not None and process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        except OSError:
            process.terminate()
    return True


def _generate_automatic_support_bundle(
    settings: dict[str, Any],
    lines: list[str],
    *,
    evidence_quality: str = "complete",
    discovery_result: str = "success",
    snmp2mqtt_handoff: str = "verified",
) -> bool:
    """Capture an automatic contribution with the exact Discovery outcome."""
    if not DEFAULT_SUPPORT_SCRIPT.is_file():
        lines.append(
            "Automatic Support My Switch capture skipped because the support backend is unavailable."
        )
        return False
    DEFAULT_CONTRIBUTIONS_DIR.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update({
        "SWITCH_VISION_DISCOVERY_VERSION": os.environ.get(
            "SWITCH_VISION_DISCOVERY_VERSION",
            "unknown",
        ),
        "SUPPORT_MASK_MANAGEMENT_IPS": str(settings["mask_management_ips"]).lower(),
        "SUPPORT_MASK_MAC_ADDRESSES": str(settings["mask_mac_addresses"]).lower(),
        "SUPPORT_MASK_HOSTNAMES": str(settings["mask_hostnames"]).lower(),
        "SUPPORT_MASK_VLAN_NAMES": str(settings["mask_vlan_names"]).lower(),
        "SUPPORT_MASK_INTERFACE_DESCRIPTIONS": str(
            settings["mask_interface_descriptions"]
        ).lower(),
        "SUPPORT_CONTRIBUTOR_TYPE": str(settings["contributor_type"]),
        "SUPPORT_CONTRIBUTOR_VALUE": str(settings["contributor_value"]),
        "CONTRIBUTIONS_DIR": str(DEFAULT_CONTRIBUTIONS_DIR),
        "SUPPORT_EVIDENCE_QUALITY": evidence_quality,
        "SUPPORT_DISCOVERY_RESULT": discovery_result,
        "SUPPORT_SNMP2MQTT_HANDOFF": snmp2mqtt_handoff,
    })
    try:
        result = subprocess.run(
            [str(DEFAULT_SUPPORT_SCRIPT)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
            env=env,
            timeout=180,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        lines.append(
            "Automatic Support My Switch capture failed after the SNMP2MQTT "
            f"handoff check: {type(exc).__name__}."
        )
        return False
    if result.returncode != 0:
        lines.append(
            "Automatic Support My Switch capture failed after the SNMP2MQTT "
            f"handoff check with exit code {result.returncode}."
        )
        return False
    lines.append(
        "Automatic Support My Switch contribution captured after the "
        "SNMP2MQTT handoff check."
    )
    return True


def _run_discovery(discovery_script: Path, mode: str = "discovery") -> None:
    global _DISCOVERY_PROCESS
    log_path = DEFAULT_DISCOVERY_LOG
    lines: list[str] = _DiscoveryDebugLines()
    regenerate_yaml_only = mode == "regenerate_yaml"
    regenerate_card_only = mode == "regenerate_card"
    apply_device_state = mode == "apply_device_state"
    regenerate_only = regenerate_yaml_only or regenerate_card_only or apply_device_state
    if regenerate_card_only:
        # Card-only regeneration must not inspect or mutate SNMP2MQTT handoff
        # bookkeeping. The live YAML/service plane is intentionally untouched.
        generated_yaml_previous_mtime = None
        generated_yaml_previous_topics: list[str] = []
    else:
        generated_yaml_previous_mtime = DEFAULT_GENERATED_SNMP2MQTT.stat().st_mtime if DEFAULT_GENERATED_SNMP2MQTT.is_file() else None
        generated_yaml_previous_topics = _remember_current_snmp2mqtt_topics() if generated_yaml_previous_mtime is not None else _load_snmp2mqtt_retirement_topics()
    if regenerate_card_only:
        operation_name = "Dashboard Card YAML regeneration"
        preparing_message = "Preparing Dashboard Card YAML regeneration"
        preparing_activity = "Loading saved Discovery state and stored walks"
        waiting_message = "Waiting for Dashboard Card YAML regeneration to complete"
    elif regenerate_yaml_only:
        operation_name = "SNMP2MQTT YAML regeneration"
        preparing_message = "Preparing SNMP2MQTT YAML regeneration"
        preparing_activity = "Loading saved Discovery data and SNMP walks"
        waiting_message = "Waiting for YAML regeneration to complete"
    elif apply_device_state:
        operation_name = "Device state application"
        preparing_message = "Applying device state"
        preparing_activity = "Updating SNMP polling and dashboard from saved state"
        waiting_message = "Waiting for device state application to complete"
    else:
        operation_name = "Discovery"
        preparing_message = "Preparing Discovery"
        preparing_activity = "Validating configured switches"
        waiting_message = "Waiting for Discovery to complete"
    _reset_current_discovery_debug()
    _set_discovery_state(
        running=True,
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        finished_at=None,
        success=None,
        message=preparing_message,
        log_tail=[],
        stage=preparing_message,
        mode=mode,
        switch="",
        target="",
        command="",
        activity=preparing_activity,
        phase="preparing",
        snmp2mqtt=(
            {
                "status": "Not touched",
                "action": "none",
                "slug": None,
                "state": None,
                "message": "SNMP2MQTT is outside Dashboard Card YAML regeneration.",
            }
            if regenerate_card_only
            else {"status": "Waiting", "action": "none", "slug": None, "state": None, "message": waiting_message}
        ),
    )
    try:
        _ensure_runtime_paths()
        if regenerate_card_only:
            auto_bundle_settings = None
            options_snapshot = _write_dashboard_card_regeneration_options_snapshot()
        elif regenerate_yaml_only:
            auto_bundle_settings = None
            options_snapshot = _write_snmp2mqtt_regeneration_options_snapshot()
        elif apply_device_state:
            auto_bundle_settings = None
            options_snapshot = _write_device_state_application_options_snapshot()
        else:
            authoritative_options = _self_addon_options()
            auto_bundle_settings = (
                _support_settings_from_options(authoritative_options)
                if _safe_bool(
                    authoritative_options.get("generate_support_my_switch_bundle"),
                    True,
                )
                else None
            )
            options_snapshot = _write_authoritative_discovery_options_snapshot(
                options=authoritative_options,
            )
            _set_discovery_state(
                effective_config=_discovery_effective_config_provenance(
                    authoritative_options,
                    source="supervisor",
                )
            )
        discovery_env = os.environ.copy()
        discovery_env["SWITCH_VISION_OPTIONS_FILE"] = str(options_snapshot)
        if regenerate_card_only:
            discovery_env["SWITCH_VISION_CAPABILITIES_DIR"] = "/tmp/switch_vision_regenerate_card_capabilities"
        elif regenerate_yaml_only:
            discovery_env["SWITCH_VISION_CAPABILITIES_DIR"] = "/tmp/switch_vision_regenerate_capabilities"
        elif apply_device_state:
            discovery_env["SWITCH_VISION_CAPABILITIES_DIR"] = "/tmp/switch_vision_device_state_capabilities"
        with log_path.open("a", encoding="utf-8") as log_file:
            action_label = operation_name
            log_file.write(f"\n=== {action_label} started {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            log_file.write(
                "Discovery configuration: stored-state regeneration snapshot\n"
                if regenerate_only
                else "Discovery configuration: authoritative Supervisor snapshot\n"
            )
            process = subprocess.Popen(
                [str(discovery_script)],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=discovery_env,
                start_new_session=True,
            )
            with _DISCOVERY_PROCESS_LOCK:
                _DISCOVERY_PROCESS = process
            if _DISCOVERY_STOP_REQUESTED.is_set() and process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
            assert process.stdout is not None
            for line in process.stdout:
                clean = line.rstrip()
                log_file.write(line)
                log_file.flush()
                marker = _parse_status_marker(clean)
                if marker is not None:
                    if _DISCOVERY_STOP_REQUESTED.is_set():
                        _set_discovery_state(
                            message="Stopping Discovery",
                            stage="Stopping Discovery",
                            activity="Waiting for the current Discovery command to stop",
                            command="Stop requested",
                            phase="stopping",
                        )
                    else:
                        _set_discovery_state(
                            stage=marker.get("stage", "Discovery"),
                            switch=marker.get("switch", ""),
                            target=marker.get("target", ""),
                            command=marker.get("command", ""),
                            activity=marker.get("activity", ""),
                            message=marker.get("stage", "Discovery running"),
                            phase="running",
                        )
                    continue
                debug_line = clean.removeprefix("SV_DEBUG|")
                lines.append(debug_line)
                _set_discovery_state(log_tail=lines[-300:])
            return_code = process.wait()
        if _DISCOVERY_STOP_REQUESTED.is_set():
            stopped_label = (
                "Dashboard Card YAML regeneration"
                if regenerate_card_only
                else (
                    "SNMP2MQTT YAML regeneration"
                    if regenerate_yaml_only
                    else ("Device state application" if apply_device_state else "Discovery")
                )
            )
            lines.append(f"{stopped_label} stopped by user request.")
            _set_discovery_state(
                success=None,
                message=f"{stopped_label} stopped",
                stage="Stopped",
                activity=f"{stopped_label} stopped by user",
                command="",
                phase="stopped",
                log_tail=lines[-300:],
                snmp2mqtt={"status": "Not started", "action": "none", "slug": None, "state": None, "message": "Discovery was stopped before completion"},
            )
            return
        result_markers = [line for line in lines if line.startswith("SV_RESULT|")]
        soft_warning_result = any("warnings=true" in line for line in result_markers)
        soft_degraded_result = any("degraded=true" in line for line in result_markers)
        degraded_result = return_code == 10 or soft_degraded_result
        partial_result = return_code == 11 or soft_warning_result
        if return_code not in {0, 10, 11}:
            raise RuntimeError(f"{operation_name} exited with code {return_code}.")
        if regenerate_card_only:
            card_warning = degraded_result or partial_result
            card_message = (
                "Dashboard Card YAML regeneration completed with warnings from stored evidence."
                if card_warning
                else "Dashboard Card YAML regenerated from saved Discovery state and stored walks."
            )
            if card_warning:
                lines.append(card_message)
            snmp2mqtt_result = {
                "status": "Not touched",
                "action": "none",
                "slug": None,
                "state": None,
                "activation_verified": False,
                "handoff_failed": False,
                "degraded": card_warning,
                "message": "SNMP2MQTT was not started or restarted during Dashboard Card YAML regeneration.",
            }
            _set_discovery_state(
                stage="Complete with warnings" if card_warning else "Finalizing Dashboard Card YAML",
                activity=card_message,
                command="",
                phase="running",
                snmp2mqtt=snmp2mqtt_result,
            )
        elif degraded_result:
            warning_message = (
                f"{operation_name} completed with warnings; validated physical evidence was preserved "
                "and the SNMP2MQTT handoff was blocked."
            )
            lines.append(warning_message)
            snmp2mqtt_result = {
                "status": "Warning",
                "action": "blocked_degraded",
                "slug": None,
                "state": None,
                "activation_verified": False,
                "handoff_failed": False,
                "degraded": True,
                "message": warning_message,
            }
            _set_discovery_state(
                stage="Complete with warnings",
                activity=warning_message,
                command="SNMP2MQTT handoff blocked",
                phase="running",
                snmp2mqtt=snmp2mqtt_result,
            )
        else:
            _set_discovery_state(stage="Starting SNMP2MQTT", activity="Validating generated SNMP2MQTT YAML", command="Supervisor app action", phase="running")
            snmp2mqtt_result = _ensure_snmp2mqtt_running(lines, generated_yaml_previous_mtime, generated_yaml_previous_topics)
        if auto_bundle_settings is not None:
            _set_discovery_state(
                stage="Capturing Support My Switch",
                activity="Capturing diagnostics after the SNMP2MQTT handoff check",
                command="Support My Switch",
                phase="running",
            )
            bundle_captured = _generate_automatic_support_bundle(
                auto_bundle_settings,
                lines,
                evidence_quality="degraded" if (degraded_result or partial_result) else "complete",
                discovery_result="complete_with_warnings" if (degraded_result or partial_result) else "success",
                snmp2mqtt_handoff=(
                    "blocked_degraded"
                    if degraded_result
                    else ("failed" if snmp2mqtt_result.get("handoff_failed") else "verified")
                ),
            )
            snmp2mqtt_result["support_bundle_after_handoff"] = (
                "captured" if bundle_captured else "failed"
            )
        handoff_warning = bool(snmp2mqtt_result.get("handoff_failed"))
        if handoff_warning:
            warning_message = str(
                snmp2mqtt_result.get("message")
                or "SNMP2MQTT generated-configuration handoff could not be verified."
            )
            lines.append(
                "Discovery completed successfully; SNMP2MQTT handoff warning: " + warning_message
            )
        operation_warning = degraded_result or partial_result or handoff_warning
        if regenerate_card_only:
            auto_message = (
                "Dashboard Card YAML regeneration complete with warnings"
                if operation_warning
                else "Dashboard Card YAML regeneration complete"
            )
        elif regenerate_yaml_only:
            auto_message = (
                "SNMP2MQTT YAML regeneration complete with warnings"
                if operation_warning
                else "SNMP2MQTT YAML regeneration complete"
            )
        elif apply_device_state:
            auto_message = (
                "Device state applied with warnings"
                if operation_warning
                else "Device state applied"
            )
        else:
            auto_message = (
                "Discovery complete with warnings"
                if operation_warning
                else "Discovery complete"
            )
        _set_discovery_state(
            success=True,
            message=auto_message,
            stage="Complete with warnings" if operation_warning else "Complete",
            activity=auto_message if regenerate_card_only else (snmp2mqtt_result.get("message") or auto_message),
            command="",
            phase="complete",
            log_tail=lines[-300:],
            snmp2mqtt=snmp2mqtt_result,
        )
    except Exception as exc:
        lines.append(str(exc))
        _set_discovery_state(success=False, message=str(exc), log_tail=lines[-300:], phase="failed")
        try:
            with log_path.open("a", encoding="utf-8") as log_file:
                traceback.print_exc(file=log_file)
        except OSError:
            pass
    finally:
        with _DISCOVERY_PROCESS_LOCK:
            _DISCOVERY_PROCESS = None
        _DISCOVERY_STOP_REQUESTED.clear()
        _set_discovery_state(running=False, finished_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"))
        try:
            append_discovery_history(_discovery_state_snapshot())
        except Exception:  # History is non-authoritative and must not block operation cleanup.
            pass
        _release_operation(operation_name)





def _start_dashboard_card_regeneration(discovery_script: Path = DEFAULT_DISCOVERY_SCRIPT) -> dict[str, Any]:
    """Queue the existing stored-state card regeneration path exactly once."""
    operation_name = "Dashboard Card YAML regeneration"
    _claim_operation(operation_name)
    _DISCOVERY_STOP_REQUESTED.clear()
    _set_discovery_state(
        running=True,
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        finished_at=None,
        success=None,
        message="Preparing Dashboard Card YAML regeneration",
        log_tail=[],
        stage="Preparing Dashboard Card YAML regeneration",
        switch="",
        target="",
        command="",
        activity="Applying saved device state and order",
        phase="preparing",
        mode="regenerate_card",
        snmp2mqtt={
            "status": "Not touched",
            "action": "none",
            "slug": None,
            "state": None,
            "message": "SNMP2MQTT will not be started or restarted for Card YAML regeneration",
        },
    )
    thread = threading.Thread(
        target=_run_discovery,
        args=(discovery_script, "regenerate_card"),
        daemon=True,
    )
    try:
        thread.start()
    except Exception:
        _release_operation(operation_name)
        raise
    return {"started": True, "mode": "regenerate_card"}


def _device_state_application_worker(discovery_script: Path) -> None:
    """Converge SNMP polling to the newest saved state, coalescing rapid changes."""
    global _DEVICE_STATE_RECONCILE_RUNNING
    operation_name = "Device state application"
    quiesced = False
    try:
        while True:
            # A short debounce collapses a burst of UI changes into one expensive
            # stored-state regeneration. Changes made during a running pass bump
            # the generation and automatically trigger one more latest-state pass.
            time.sleep(_DEVICE_STATE_RECONCILE_DEBOUNCE_SECONDS)
            with _DEVICE_STATE_RECONCILE_LOCK:
                target_generation = _DEVICE_STATE_RECONCILE_REQUESTED

            while True:
                try:
                    _claim_operation(operation_name)
                    break
                except OperationConflict:
                    time.sleep(_DEVICE_STATE_RECONCILE_RETRY_SECONDS)

            _DISCOVERY_STOP_REQUESTED.clear()
            _run_discovery(discovery_script, "apply_device_state")

            # A pass may have rendered an older SNMP snapshot while newer UI
            # changes were being saved. Re-project the dashboard from the current
            # authoritative state immediately before deciding whether another pass
            # is required, so stale work cannot leave a stale visible card.
            try:
                _apply_saved_device_order_to_dashboard()
            except (OSError, RuntimeError, ValueError):
                pass

            with _DEVICE_STATE_RECONCILE_LOCK:
                if _DEVICE_STATE_RECONCILE_REQUESTED == target_generation:
                    # Publish quiescence atomically with the generation check. A
                    # new request after this point starts a new worker; this worker
                    # must not clear that newer worker's running flag or operation.
                    _DEVICE_STATE_RECONCILE_RUNNING = False
                    quiesced = True
                    return
    finally:
        if not quiesced:
            # Unexpected worker failure: no replacement worker can have started
            # while our running flag is still true, so cleanup is safe here.
            _release_operation(operation_name)
            with _DEVICE_STATE_RECONCILE_LOCK:
                _DEVICE_STATE_RECONCILE_RUNNING = False


def _start_device_state_application(discovery_script: Path = DEFAULT_DISCOVERY_SCRIPT) -> dict[str, Any]:
    """Queue/coalesce saved SNMP state application without blocking device controls."""
    global _DEVICE_STATE_RECONCILE_REQUESTED, _DEVICE_STATE_RECONCILE_RUNNING
    with _DEVICE_STATE_RECONCILE_LOCK:
        _DEVICE_STATE_RECONCILE_REQUESTED += 1
        generation = _DEVICE_STATE_RECONCILE_REQUESTED
        if _DEVICE_STATE_RECONCILE_RUNNING:
            return {
                "started": False,
                "queued": True,
                "coalesced": True,
                "generation": generation,
                "mode": "apply_device_state",
            }
        _DEVICE_STATE_RECONCILE_RUNNING = True
        thread = threading.Thread(
            target=_device_state_application_worker,
            args=(discovery_script,),
            daemon=True,
        )
        try:
            thread.start()
        except Exception:
            _DEVICE_STATE_RECONCILE_RUNNING = False
            raise
    return {
        "started": True,
        "queued": True,
        "coalesced": False,
        "generation": generation,
        "mode": "apply_device_state",
    }


def _read_supervisor_token() -> str:
    """Return the Supervisor bearer token supplied to the app container."""
    for name in ("SUPERVISOR_TOKEN", "HASSIO_TOKEN"):
        token = os.environ.get(name, "").strip()
        if token:
            return token

    # s6 exposes container environment values as files on some base-image versions.
    for path in (
        Path("/run/s6/container_environment/SUPERVISOR_TOKEN"),
        Path("/var/run/s6/container_environment/SUPERVISOR_TOKEN"),
        Path("/run/s6/container_environment/HASSIO_TOKEN"),
        Path("/var/run/s6/container_environment/HASSIO_TOKEN"),
    ):
        try:
            token = path.read_text(encoding="utf-8").strip().strip("\x00")
        except OSError:
            continue
        if token:
            return token
    return ""


def _supervisor_json(
    path: str, *, method: str = "GET", timeout: float = 12.0, payload: Any | None = None
) -> dict[str, Any]:
    token = _read_supervisor_token()
    if not token:
        raise RuntimeError(
            "Supervisor API token is unavailable. Rebuild/reinstall the Discovery app "
            "with hassio_api: true and hassio_role: manager."
        )
    body = None
    if method != "GET":
        body = json.dumps({} if payload is None else payload).encode("utf-8")
    request = Request(
        f"http://supervisor{path}",
        method=method,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        data=body,
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Supervisor API returned HTTP {exc.code}: {detail[:240]}") from exc
    except (URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Supervisor API request failed: {exc}") from exc
    if isinstance(payload, dict) and payload.get("result") == "error":
        raise RuntimeError(str(payload.get("message") or "Supervisor API reported an error."))
    return payload if isinstance(payload, dict) else {}


INSTALLER_MAINTENANCE_SCHEMA = "switch-vision-installer-maintenance-v1"
_INSTALLER_MAINTENANCE_LOCK = threading.Lock()


def _installer_maintenance_request(
    action: str,
    *,
    response_path: Path = DEFAULT_INSTALLER_MAINTENANCE_RESPONSE,
    timeout: float = 5.0,
    **fields: Any,
) -> dict[str, Any]:
    """Send one narrow Maintenance command to Installer through Supervisor STDIN."""
    if action not in {
        "status",
        "set_policy",
        "create_backup",
        "validate_backup",
        "restore_backup",
        "delete_backup",
        "apply_retention",
    }:
        raise ValueError("Unsupported Installer maintenance action.")

    with _INSTALLER_MAINTENANCE_LOCK:
        links = _installed_switch_vision_app_links()
        installer = links.get("installer") if isinstance(links, dict) else None
        if not isinstance(installer, dict) or not installer.get("found"):
            raise RuntimeError(
                "Switch Vision Installer is not installed. Install or update Installer "
                "before managing recovery backups from Maintenance."
            )
        slug = str(installer.get("slug") or "").strip()
        if not slug:
            raise RuntimeError("Switch Vision Installer slug could not be resolved.")

        info_path = f"/addons/{quote(slug, safe='')}/info"
        info_payload = _supervisor_json(info_path)
        info = (
            info_payload.get("data")
            if isinstance(info_payload.get("data"), dict)
            else info_payload
        )
        if not isinstance(info, dict) or info.get("stdin") is not True:
            raise RuntimeError(
                "Switch Vision Installer 2.1.31 or later is required for "
                "Maintenance backup controls."
            )

        state = str(info.get("state") or "").strip().lower()
        if state not in {"started", "running"}:
            _supervisor_json(
                f"/addons/{quote(slug, safe='')}/start",
                method="POST",
                timeout=30.0,
            )
            start_deadline = time.monotonic() + 20.0
            while time.monotonic() < start_deadline:
                refreshed_payload = _supervisor_json(info_path)
                refreshed = (
                    refreshed_payload.get("data")
                    if isinstance(refreshed_payload.get("data"), dict)
                    else refreshed_payload
                )
                state = (
                    str(refreshed.get("state") or "").strip().lower()
                    if isinstance(refreshed, dict)
                    else ""
                )
                if state in {"started", "running"}:
                    break
                time.sleep(0.1)
            else:
                raise RuntimeError(
                    "Switch Vision Installer did not reach a running state after "
                    "Maintenance requested its start."
                )

        request_id = f"maintenance-{time.monotonic_ns()}"
        command = {
            "schema": INSTALLER_MAINTENANCE_SCHEMA,
            "request_id": request_id,
            "action": action,
            **fields,
        }
        _supervisor_json(
            f"/addons/{quote(slug, safe='')}/stdin",
            method="POST",
            payload=command,
        )

        deadline = time.monotonic() + max(0.5, min(float(timeout), 15.0))
        while time.monotonic() < deadline:
            try:
                if response_path.is_symlink():
                    raise RuntimeError(
                        "Installer Maintenance response path must not be a symbolic link."
                    )
                if not response_path.is_file():
                    time.sleep(0.05)
                    continue
                if response_path.stat().st_size > 1024 * 1024:
                    raise RuntimeError("Installer Maintenance response is unexpectedly large.")
                document = json.loads(response_path.read_text(encoding="utf-8"))
            except FileNotFoundError:
                time.sleep(0.05)
                continue
            except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise RuntimeError(
                    f"Installer Maintenance response could not be read safely: {exc}"
                ) from exc

            if not isinstance(document, dict):
                raise RuntimeError("Installer Maintenance response is invalid.")
            if (
                document.get("schema") != INSTALLER_MAINTENANCE_SCHEMA
                or document.get("request_id") != request_id
            ):
                time.sleep(0.05)
                continue
            if document.get("ok") is not True:
                raise RuntimeError(
                    str(document.get("error") or "Installer Maintenance request failed.")
                )
            return document

        raise RuntimeError(
            "Timed out waiting for Switch Vision Installer Maintenance response."
        )


def _installer_maintenance_browser_request(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("Installer backup request must contain a JSON object.")
    action = str(data.get("action") or "").strip()
    if action == "set_policy":
        automatic = data.get("automatic_retention")
        count = data.get("retention_count")
        if not isinstance(automatic, bool):
            raise ValueError("Automatic retention must be true or false.")
        if isinstance(count, bool) or not isinstance(count, int) or not 1 <= count <= 10:
            raise ValueError("Retained backup count must be between 1 and 10.")
        return _installer_maintenance_request(
            action,
            automatic_retention=automatic,
            retention_count=count,
        )
    if action in {"validate_backup", "restore_backup", "delete_backup"}:
        name = data.get("name")
        if not isinstance(name, str) or not name or len(name) > 160 or Path(name).name != name:
            raise ValueError("Backup name is invalid.")
        return _installer_maintenance_request(action, name=name)
    if action in {"create_backup", "apply_retention"}:
        return _installer_maintenance_request(action)
    raise ValueError("Unsupported Installer backup request.")


def _self_addon_options() -> dict[str, Any]:
    """Return the authoritative Discovery options from Home Assistant Supervisor."""
    payload = _supervisor_json("/addons/self/info")
    data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    options = data.get("options") if isinstance(data, dict) else None
    if not isinstance(options, dict):
        raise RuntimeError("Home Assistant Supervisor did not expose the Discovery app options.")
    return dict(options)


def _write_authoritative_discovery_options_snapshot(
    destination: Path = Path("/tmp/switch_vision_discovery_options.json"),
    *,
    options: dict[str, Any] | None = None,
) -> Path:
    """Write one fail-closed Supervisor snapshot for the shell Discovery stage.

    Automatic Support My Switch capture is suppressed in this run-local copy.
    The Hub creates that bundle only after the SNMP2MQTT handoff has been checked.
    """
    source_options = dict(options) if isinstance(options, dict) else _self_addon_options()
    snapshot_options = _effective_discovery_options(source_options)
    snapshot_options["generate_support_my_switch_bundle"] = False
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    try:
        temporary.write_text(json.dumps(snapshot_options, indent=2) + "\n", encoding="utf-8")
        os.chmod(temporary, 0o600)
        temporary.replace(destination)
        os.chmod(destination, 0o600)
    except OSError as exc:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise RuntimeError(f"Could not prepare the authoritative Discovery configuration snapshot: {exc}") from exc
    return destination


def _write_snmp2mqtt_regeneration_options_snapshot(
    destination: Path = Path("/tmp/switch_vision_regenerate_options.json"),
) -> Path:
    """Prepare a safe stored-walk-only snapshot for SNMP2MQTT YAML regeneration."""
    options = _self_addon_options()
    _validate_inventory_identities(options)
    regenerated = dict(options)
    rows = regenerated.get("switches")
    has_inventory = isinstance(rows, list) and any(
        isinstance(row, dict)
        and (str(row.get("switch_name") or "").strip() or str(row.get("switch_host") or "").strip())
        for row in rows
    )
    if has_inventory:
        regenerated["enable_switch_list"] = True
    regenerated["run_snmp_walks"] = False
    regenerated["run_live_snmpwalk"] = False
    regenerated["clean_output_before_walk"] = False
    regenerated["parse_all_walks"] = True
    regenerated["generate_snmp2mqtt"] = True
    regenerated["generate_support_my_switch_bundle"] = False
    regenerated["report_path"] = "/tmp/switch_vision_regenerate_report.txt"
    regenerated["last_run_summary_path"] = "/tmp/switch_vision_regenerate_summary.txt"
    regenerated["generated_card_path"] = "/tmp/switch_vision_regenerate_dashboard.yaml"
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    try:
        temporary.write_text(json.dumps(regenerated, indent=2) + "\n", encoding="utf-8")
        os.chmod(temporary, 0o600)
        temporary.replace(destination)
        os.chmod(destination, 0o600)
    except OSError as exc:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise RuntimeError(f"Could not prepare SNMP2MQTT regeneration configuration: {exc}") from exc
    return destination


def _write_device_state_application_options_snapshot(
    destination: Path = Path("/tmp/switch_vision_apply_device_state_options.json"),
) -> Path:
    """Apply saved enable/disable state to SNMP polling and dashboard outputs without new walks."""
    options = _effective_discovery_options(_self_addon_options())
    _validate_inventory_identities(options)
    regenerated = dict(options)
    rows = regenerated.get("switches")
    has_inventory = isinstance(rows, list) and any(
        isinstance(row, dict)
        and (str(row.get("switch_name") or "").strip() or str(row.get("switch_host") or "").strip())
        for row in rows
    )
    if has_inventory:
        regenerated["enable_switch_list"] = True
    regenerated["run_snmp_walks"] = False
    regenerated["run_live_snmpwalk"] = False
    regenerated["clean_output_before_walk"] = False
    regenerated["parse_all_walks"] = True
    regenerated["generate_snmp2mqtt"] = True
    regenerated["generate_support_my_switch_bundle"] = False
    regenerated["report_path"] = "/tmp/switch_vision_apply_device_state_report.txt"
    regenerated["last_run_summary_path"] = "/tmp/switch_vision_apply_device_state_summary.txt"
    regenerated["generated_yaml_path"] = str(DEFAULT_GENERATED_SNMP2MQTT)
    regenerated["generated_card_path"] = str(DEFAULT_GENERATED_CARD)
    regenerated["snmp_log_path"] = "/tmp/switch_vision_apply_device_state_snmp.log"
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    try:
        temporary.write_text(json.dumps(regenerated, indent=2) + "\n", encoding="utf-8")
        os.chmod(temporary, 0o600)
        temporary.replace(destination)
        os.chmod(destination, 0o600)
    except OSError as exc:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise RuntimeError(f"Could not prepare device-state application configuration: {exc}") from exc
    return destination


def _write_dashboard_card_regeneration_options_snapshot(
    destination: Path = Path("/tmp/switch_vision_regenerate_card_options.json"),
) -> Path:
    """Prepare a stored-state-only snapshot for dashboard Card YAML regeneration."""
    options = _effective_discovery_options(_self_addon_options())
    _validate_inventory_identities(options)
    regenerated = dict(options)
    rows = regenerated.get("switches")
    has_inventory = isinstance(rows, list) and any(
        isinstance(row, dict)
        and (str(row.get("switch_name") or "").strip() or str(row.get("switch_host") or "").strip())
        for row in rows
    )
    if has_inventory:
        regenerated["enable_switch_list"] = True
    regenerated["run_snmp_walks"] = False
    regenerated["run_live_snmpwalk"] = False
    regenerated["clean_output_before_walk"] = False
    regenerated["parse_all_walks"] = True
    regenerated["generate_snmp2mqtt"] = False
    regenerated["generate_support_my_switch_bundle"] = False
    regenerated["report_path"] = "/tmp/switch_vision_regenerate_card_report.txt"
    regenerated["last_run_summary_path"] = "/tmp/switch_vision_regenerate_card_summary.txt"
    regenerated["generated_yaml_path"] = "/tmp/switch_vision_regenerate_card_snmp2mqtt.yaml"
    regenerated["generated_card_path"] = str(DEFAULT_GENERATED_CARD)
    regenerated["snmp_log_path"] = "/tmp/switch_vision_regenerate_card_snmp.log"
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    try:
        temporary.write_text(json.dumps(regenerated, indent=2) + "\n", encoding="utf-8")
        os.chmod(temporary, 0o600)
        temporary.replace(destination)
        os.chmod(destination, 0o600)
    except OSError as exc:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise RuntimeError(f"Could not prepare Dashboard Card regeneration configuration: {exc}") from exc
    return destination


def _current_unified_device_keys(options: dict[str, Any]) -> list[str]:
    keys: list[str] = []
    rows = options.get("switches") if isinstance(options.get("switches"), list) else []
    for raw in rows:
        if not isinstance(raw, dict):
            continue
        name = str(raw.get("switch_name") or "").strip()
        host = str(raw.get("switch_host") or "").strip()
        prefix = str(raw.get("sensor_prefix") or "").strip()
        if name and (name or host or prefix):
            keys.append(device_control_state.device_key("snmp", name))
    snapshot = _read_json(DEFAULT_UNIFI_SNAPSHOT)
    if isinstance(snapshot, dict) and isinstance(snapshot.get("devices"), list):
        for raw in snapshot["devices"]:
            if not isinstance(raw, dict):
                continue
            identity = str(raw.get("id") or "").strip()
            if identity:
                keys.append(device_control_state.device_key("unifi", identity))
    return keys


def _reconcile_device_added_at(options: dict[str, Any]) -> dict[str, Any]:
    """Persist immutable first-added timestamps for every currently known device."""
    current_keys = _current_unified_device_keys(options)
    control = device_control_state.load(DEFAULT_DEVICE_CONTROL)
    control, changed = device_control_state.reconcile_added_at(control, current_keys)
    if changed:
        control = device_control_state.save(control, DEFAULT_DEVICE_CONTROL)
    return control


def _configured_devices_snapshot(options_file: Path) -> dict[str, Any]:
    """Return browser-safe persistent switch inventory plus unified device control."""
    writable = True
    source = "supervisor"
    warning = ""
    try:
        options = _self_addon_options()
    except RuntimeError as exc:
        options = _load_options(options_file)
        writable = False
        source = "local_fallback"
        warning = str(exc)

    rows = options.get("switches")
    if not isinstance(rows, list):
        rows = []
    devices: list[dict[str, Any]] = []
    for index, raw in enumerate(rows):
        if not isinstance(raw, dict):
            continue
        switch_name = str(raw.get("switch_name") or "").strip()
        switch_host = str(raw.get("switch_host") or "").strip()
        sensor_prefix = str(raw.get("sensor_prefix") or "").strip()
        if not (switch_name or switch_host or sensor_prefix):
            continue
        if not switch_name:
            continue
        configured_management_target = ""
        configured_management_source = "unset"
        for management_key in ("switch_host", "host", "manual_switch_host"):
            management_value = str(raw.get(management_key) or "").strip()
            if management_value:
                configured_management_target = management_value[:255]
                configured_management_source = management_key
                break
        try:
            effective_row = _effective_discovery_switch_row(raw, index + 1)
        except ValueError:
            effective_management_target = ""
            effective_management_status = "invalid_saved_row"
        else:
            effective_management_target = str(
                effective_row.get("switch_host") or ""
            ).strip()[:255]
            effective_management_status = (
                "ready" if effective_management_target else "not_configured"
            )
        try:
            state = _switch_enabled_state(
                raw.get("enabled", "enabled"), f"Switch entry {index + 1} enabled"
            )
        except ValueError:
            state = "enabled"
        devices.append({
            "device_key": device_control_state.device_key("snmp", switch_name),
            "index": index,
            "switch_name": switch_name,
            "display_name": str(raw.get("display_name") or "").strip()[:120],
            "switch_host": switch_host[:255],
            "configured_management_target": configured_management_target,
            "configured_management_source": configured_management_source,
            "effective_management_target": effective_management_target,
            "effective_management_status": effective_management_status,
            "sensor_prefix": sensor_prefix[:64],
            "switch_model": str(raw.get("switch_model") or "auto").strip()[:120] or "auto",
            "enabled": state,
        })
    current_keys = _current_unified_device_keys(options)
    control = _reconcile_device_added_at(options)
    return {
        "devices": devices,
        "count": len(devices),
        "writable": writable,
        "source": source,
        "warning": warning,
        "switch_list_enabled": _safe_bool(options.get("enable_switch_list"), True),
        "device_order": device_control_state.ordered_keys(current_keys, control),
        "device_states": dict(control.get("states") or {}),
        "device_control_writable": os.access(DEFAULT_DEVICE_CONTROL.parent, os.W_OK),
    }


def _set_configured_device_state(options_file: Path, request_data: Any) -> dict[str, Any]:
    """Persist one SNMP or UniFi device state through its authoritative path."""
    if not isinstance(request_data, dict):
        raise ValueError("Device state request must contain a JSON object.")
    desired = _switch_enabled_state(request_data.get("enabled"), "enabled")
    key = _plain_text(
        request_data.get("device_key", ""), "device_key", max_length=320, allow_empty=False
    ).strip()

    if key.startswith("unifi:"):
        options = _self_addon_options()
        control = device_control_state.load(DEFAULT_DEVICE_CONTROL)
        current_keys = _current_unified_device_keys(options)
        if key not in current_keys:
            raise ValueError("The UniFi device list changed. Refresh Devices and try again.")
        updated = device_control_state.set_state(control, key, desired == "enabled")
        device_control_state.save(updated, DEFAULT_DEVICE_CONTROL)
        return _configured_devices_snapshot(options_file)

    if not key.startswith("snmp:"):
        raise ValueError("Device identity is invalid.")
    expected_name = key.split(":", 1)[1]

    with _OPTIONS_UPDATE_LOCK:
        options = _self_addon_options()
        rows = options.get("switches")
        if not isinstance(rows, list):
            raise ValueError("The saved device list changed. Refresh Devices and try again.")
        matches = [
            index for index, item in enumerate(rows)
            if isinstance(item, dict)
            and str(item.get("switch_name") or "").strip() == expected_name
        ]
        if len(matches) != 1:
            raise ValueError("The saved device list changed. Refresh Devices and try again.")
        raw_index = matches[0]
        current = rows[raw_index]
        if not isinstance(current, dict):
            raise ValueError("The saved device entry is invalid. Open Discovery Settings to review it.")

        updated_rows = list(rows)
        updated_row = dict(current)
        updated_row["enabled"] = desired
        updated_rows[raw_index] = updated_row
        updated_options = dict(options)
        updated_options["switches"] = updated_rows
        _validate_inventory_identities(updated_options)
        create_pre_mutation_backup(options, reason="device_state_update")
        _supervisor_json(
            "/addons/self/options",
            method="POST",
            timeout=12.0,
            payload={"options": updated_options},
        )
        confirmed = _self_addon_options()
        confirmed_rows = confirmed.get("switches")
        if not isinstance(confirmed_rows, list) or raw_index >= len(confirmed_rows):
            raise RuntimeError(
                "Home Assistant saved the request but the updated device state could not be confirmed."
            )
        confirmed_row = confirmed_rows[raw_index]
        if not isinstance(confirmed_row, dict):
            raise RuntimeError("Home Assistant returned an invalid device entry after saving.")
        confirmed_state = _switch_enabled_state(
            confirmed_row.get("enabled", "enabled"), "enabled"
        )
        if (
            str(confirmed_row.get("switch_name") or "").strip() != expected_name
            or confirmed_state != desired
        ):
            raise RuntimeError("Home Assistant did not confirm the requested device state.")

        control = device_control_state.load(DEFAULT_DEVICE_CONTROL)
        device_control_state.save(
            device_control_state.set_state(control, key, desired == "enabled"),
            DEFAULT_DEVICE_CONTROL,
        )

    return _configured_devices_snapshot(options_file)


def _move_configured_device(options_file: Path, request_data: Any) -> dict[str, Any]:
    """Persist one mixed SNMP/UniFi display/dashboard order move."""
    if not isinstance(request_data, dict):
        raise ValueError("Device order request must contain a JSON object.")
    source_key = _plain_text(
        request_data.get("device_key", ""), "device_key", max_length=320, allow_empty=False
    ).strip()
    destination_key = _plain_text(
        request_data.get("destination_device_key", ""),
        "destination_device_key",
        max_length=320,
        allow_empty=False,
    ).strip()
    if source_key == destination_key:
        raise ValueError("Device order did not change.")

    with _OPTIONS_UPDATE_LOCK:
        options = _self_addon_options()
        current_keys = _current_unified_device_keys(options)
        control = device_control_state.load(DEFAULT_DEVICE_CONTROL)
        updated_control = device_control_state.move(
            control, current_keys, source_key, destination_key
        )
        rows = options.get("switches")
        if not isinstance(rows, list):
            raise ValueError("The saved device list changed. Refresh Devices and try again.")

        if source_key.startswith("snmp:") and destination_key.startswith("snmp:"):
            source_name = source_key.split(":", 1)[1]
            destination_name = destination_key.split(":", 1)[1]
            indexes = {
                str(item.get("switch_name") or "").strip(): index
                for index, item in enumerate(rows)
                if isinstance(item, dict) and str(item.get("switch_name") or "").strip()
            }
            if source_name not in indexes or destination_name not in indexes:
                raise ValueError("The saved device list changed. Refresh Devices and try again.")
            updated_rows = list(rows)
            source_index = indexes[source_name]
            destination_index = indexes[destination_name]
            updated_rows[source_index], updated_rows[destination_index] = (
                updated_rows[destination_index], updated_rows[source_index]
            )
            updated_options = dict(options)
            updated_options["switches"] = updated_rows
            _validate_inventory_identities(updated_options)
            create_pre_mutation_backup(options, reason="device_order_update")
            _supervisor_json(
                "/addons/self/options",
                method="POST",
                timeout=12.0,
                payload={"options": updated_options},
            )
            confirmed = _self_addon_options()
            confirmed_rows = confirmed.get("switches")
            if not isinstance(confirmed_rows, list):
                raise RuntimeError("Home Assistant did not confirm the requested device order.")
            confirmed_names = [
                str(item.get("switch_name") or "").strip()
                for item in confirmed_rows if isinstance(item, dict)
            ]
            expected_names = [
                str(item.get("switch_name") or "").strip()
                for item in updated_rows if isinstance(item, dict)
            ]
            if confirmed_names != expected_names:
                raise RuntimeError("Home Assistant did not confirm the requested device order.")

        device_control_state.save(updated_control, DEFAULT_DEVICE_CONTROL)

    return _configured_devices_snapshot(options_file)


def _reset_configured_device_order(options_file: Path) -> dict[str, Any]:
    """Restore mixed SNMP/UniFi display order to immutable first-added order."""
    with _OPTIONS_UPDATE_LOCK:
        options = _self_addon_options()
        current_keys = _current_unified_device_keys(options)
        control = device_control_state.load(DEFAULT_DEVICE_CONTROL)
        updated_control = device_control_state.reset_order(control, current_keys)
        reset_keys = list(updated_control.get("order") or [])

        rows = options.get("switches")
        if not isinstance(rows, list):
            rows = []
        by_name = {
            str(row.get("switch_name") or "").strip(): row
            for row in rows
            if isinstance(row, dict) and str(row.get("switch_name") or "").strip()
        }
        snmp_names = [key.split(":", 1)[1] for key in reset_keys if key.startswith("snmp:")]
        snmp_name_set = set(snmp_names)
        updated_rows = [by_name[name] for name in snmp_names if name in by_name]
        updated_rows.extend(
            row for row in rows
            if not isinstance(row, dict)
            or not str(row.get("switch_name") or "").strip()
            or str(row.get("switch_name") or "").strip() not in snmp_name_set
        )
        if updated_rows != rows:
            updated_options = dict(options)
            updated_options["switches"] = updated_rows
            _validate_inventory_identities(updated_options)
            create_pre_mutation_backup(options, reason="device_order_reset")
            _supervisor_json(
                "/addons/self/options",
                method="POST",
                timeout=12.0,
                payload={"options": updated_options},
            )
            confirmed = _self_addon_options()
            confirmed_rows = confirmed.get("switches")
            confirmed_names = [
                str(item.get("switch_name") or "").strip()
                for item in confirmed_rows if isinstance(item, dict)
            ] if isinstance(confirmed_rows, list) else []
            expected_names = [
                str(item.get("switch_name") or "").strip()
                for item in updated_rows if isinstance(item, dict)
            ]
            if confirmed_names != expected_names:
                raise RuntimeError("Home Assistant did not confirm the reset device order.")

        device_control_state.save(updated_control, DEFAULT_DEVICE_CONTROL)

    return _configured_devices_snapshot(options_file)


def _ensure_full_dashboard_source() -> tuple[Path | None, bool]:
    """Ensure a non-destructive full-card source exists for dashboard projection."""
    if DEFAULT_GENERATED_CARD_FULL.is_file():
        return DEFAULT_GENERATED_CARD_FULL, False
    if not DEFAULT_GENERATED_CARD.is_file():
        return None, False
    try:
        DEFAULT_GENERATED_CARD_FULL.parent.mkdir(parents=True, exist_ok=True)
        temporary = DEFAULT_GENERATED_CARD_FULL.with_name(
            f".{DEFAULT_GENERATED_CARD_FULL.name}.{os.getpid()}.tmp"
        )
        shutil.copyfile(DEFAULT_GENERATED_CARD, temporary)
        os.chmod(temporary, 0o600)
        temporary.replace(DEFAULT_GENERATED_CARD_FULL)
        os.chmod(DEFAULT_GENERATED_CARD_FULL, 0o600)
    except OSError as exc:
        try:
            temporary.unlink(missing_ok=True)
        except (OSError, UnboundLocalError):
            pass
        raise RuntimeError(f"Could not preserve the full Native dashboard source: {exc}") from exc
    return DEFAULT_GENERATED_CARD_FULL, True


def _apply_saved_device_order_to_dashboard() -> dict[str, Any]:
    """Project current order/state from the preserved full-card dashboard source."""
    source, seeded = _ensure_full_dashboard_source()
    if source is None:
        return {"updated": False, "reason": "generated_dashboard_missing"}
    try:
        options = _self_addon_options()
    except RuntimeError:
        options = _load_options(DEFAULT_OPTIONS_FILE)
    result = dashboard_device_order.apply_dashboard_order(
        DEFAULT_GENERATED_CARD,
        DEFAULT_DEVICE_CONTROL,
        source_path=source,
        snmp_states=dashboard_device_order.snmp_states_from_options(options),
    )
    return {"updated": True, "full_source_seeded": seeded, **result}


def _home_assistant_service(domain: str, service: str, payload: dict[str, Any]) -> None:
    """Call a Home Assistant service through the supported Supervisor Core proxy."""
    token = _read_supervisor_token()
    if not token:
        raise RuntimeError(
            "Home Assistant API token is unavailable. Rebuild/reinstall the Discovery app "
            "with homeassistant_api: true."
        )
    request = Request(
        f"http://supervisor/core/api/services/{quote(domain, safe='')}/{quote(service, safe='')}",
        method="POST",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        data=json.dumps(payload).encode("utf-8"),
    )
    try:
        with urlopen(request, timeout=12.0) as response:
            response.read()
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Home Assistant API returned HTTP {exc.code}: {detail[:240]}") from exc
    except (URLError, TimeoutError, OSError) as exc:
        raise RuntimeError(f"Home Assistant API request failed: {exc}") from exc


def _home_assistant_ws(command: dict[str, Any], *, max_size: int = 4 * 1024 * 1024) -> Any:
    """Call a Switch Vision WebSocket command through Supervisor."""
    command_type = str(
        command.get("type") or ""
    ).strip()

    if not command_type.startswith(
        "switch_vision/"
    ):
        raise ValueError(
            "Unsupported Home Assistant WebSocket command."
        )

    token = _read_supervisor_token()

    if not token:
        raise RuntimeError(
            "Home Assistant API token is unavailable."
        )

    try:
        with websocket_connect(
            "ws://supervisor/core/websocket",
            open_timeout=12,
            close_timeout=5,
            max_size=max_size,
        ) as connection:

            required = json.loads(
                connection.recv(timeout=12)
            )

            if (
                required.get("type")
                != "auth_required"
            ):
                raise RuntimeError(
                    "Home Assistant WebSocket did not "
                    "request authentication."
                )

            connection.send(
                json.dumps(
                    {
                        "type": "auth",
                        "access_token": token,
                    }
                )
            )

            authenticated = json.loads(
                connection.recv(timeout=12)
            )

            if (
                authenticated.get("type")
                != "auth_ok"
            ):
                raise RuntimeError(
                    str(
                        authenticated.get(
                            "message"
                        )
                        or
                        "Home Assistant WebSocket "
                        "authentication failed."
                    )
                )

            payload = dict(command)
            payload["id"] = 1

            connection.send(
                json.dumps(payload)
            )

            while True:
                response = json.loads(
                    connection.recv(
                        timeout=12
                    )
                )

                if response.get("id") != 1:
                    continue

                if (
                    response.get("type")
                    != "result"
                    or
                    response.get("success")
                    is not True
                ):
                    error = response.get(
                        "error"
                    )

                    if isinstance(
                        error,
                        dict,
                    ):
                        detail = (
                            error.get("message")
                            or
                            error.get("code")
                        )
                    else:
                        detail = error

                    raise RuntimeError(
                        str(
                            detail
                            or
                            "Home Assistant WebSocket "
                            "command failed."
                        )
                    )

                return response.get(
                    "result"
                )

    except RuntimeError:
        raise

    except Exception as exc:
        raise RuntimeError(
            "Home Assistant WebSocket "
            f"request failed: {exc}"
        ) from exc


def _calibration_profile_name(
    value: Any,
) -> str:
    profile = _plain_text(
        value,
        "Calibration profile",
        max_length=128,
        allow_empty=False,
    ).strip()

    if not profile:
        raise ValueError(
            "Calibration profile cannot be empty."
        )

    return profile


def _set_discovery_ui_density(value: Any) -> dict[str, str]:
    density = str(value or "").strip().lower()
    if density not in _UI_ALLOWED["density"]:
        raise ValueError("UI density must be spacious, comfortable, compact, dense, or ultra_dense.")
    _home_assistant_service("switch_vision", "set_ui_density", {"density": density})
    preferences = _discovery_ui_preferences()
    # The integration writes the shared preference file synchronously as part of
    # the service call. Fall back to the requested value only if storage is slow.
    if preferences.get("density") != density:
        preferences["density"] = density
    return preferences


def _find_snmp2mqtt_addon() -> dict[str, Any] | None:
    payload = _supervisor_json("/addons")
    data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    addons = data.get("addons", []) if isinstance(data, dict) else []
    candidates: list[tuple[int, dict[str, Any]]] = []
    for addon in addons if isinstance(addons, list) else []:
        if not isinstance(addon, dict):
            continue
        slug = str(addon.get("slug") or "")
        name = str(addon.get("name") or "")
        haystack = f"{slug} {name}".lower().replace("-", "_")
        if "snmp2mqtt" not in haystack or "discovery" in haystack:
            continue
        score = 0
        if "switch_vision" in haystack or "switch vision" in haystack:
            score += 10
        if slug.endswith("switch_vision_snmp2mqtt") or slug.endswith("switch_vision_snmp2mqtt_addon"):
            score += 10
        if name.strip().lower() == "switch vision snmp2mqtt":
            score += 20
        candidates.append((score, addon))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _snmp2mqtt_runtime_info() -> dict[str, Any]:
    """Return non-secret SNMP2MQTT runtime details needed for safe retirement."""
    try:
        addon = _find_snmp2mqtt_addon()
    except RuntimeError:
        addon = None
    if addon is None:
        return {
            "installed": False,
            "slug": None,
            "state": "not_installed",
            "options_readable": False,
            "homeassistant_prefix": None,
            "base_topic": None,
            "host_name_as_target": None,
            "wrapper_options_readable": False,
            "use_switch_vision_generated_yaml": None,
            "switch_vision_generated_yaml_path": None,
        }
    slug = str(addon.get("slug") or "").strip()
    state = str(addon.get("state") or addon.get("status") or "unknown").lower()
    result: dict[str, Any] = {
        "installed": bool(slug),
        "slug": slug or None,
        "state": state,
        "options_readable": False,
        "homeassistant_prefix": None,
        "base_topic": None,
        "host_name_as_target": None,
        "wrapper_options_readable": False,
        "use_switch_vision_generated_yaml": None,
        "switch_vision_generated_yaml_path": None,
    }
    if not slug:
        return result
    try:
        info = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
        data = info.get("data") if isinstance(info.get("data"), dict) else info
        if not isinstance(data, dict):
            return result
        result["state"] = str(data.get("state") or state).lower()
        options = data.get("options")
        if not isinstance(options, dict):
            return result
        result["wrapper_options_readable"] = True
        generated_mode = options.get("use_switch_vision_generated_yaml")
        if isinstance(generated_mode, bool):
            result["use_switch_vision_generated_yaml"] = generated_mode
        elif isinstance(generated_mode, str):
            normalized_mode = generated_mode.strip().casefold()
            if normalized_mode in {"true", "1", "yes", "on", "enabled"}:
                result["use_switch_vision_generated_yaml"] = True
            elif normalized_mode in {"false", "0", "no", "off", "disabled"}:
                result["use_switch_vision_generated_yaml"] = False
        generated_path = str(
            options.get("switch_vision_generated_yaml_path")
            or DEFAULT_GENERATED_SNMP2MQTT
        ).strip()
        result["switch_vision_generated_yaml_path"] = generated_path
        mqtt = options.get("mqtt") if isinstance(options.get("mqtt"), dict) else {}
        homeassistant = options.get("homeassistant") if isinstance(options.get("homeassistant"), dict) else {}
        prefix = str(homeassistant.get("prefix") or "homeassistant").strip().strip("/")
        base_topic = str(mqtt.get("base_topic") or "snmp2mqtt").strip().strip("/")
        if not prefix or not base_topic or "+" in prefix or "#" in prefix:
            return result
        result.update({
            "options_readable": True,
            "homeassistant_prefix": prefix,
            "base_topic": base_topic,
            "host_name_as_target": bool(mqtt.get("host_name_as_target", False)),
        })
    except RuntimeError:
        pass
    return result


def _core_settings_status() -> dict[str, Any]:
    result = _home_assistant_ws({"type": "switch_vision/get_settings"})
    if not isinstance(result, dict) or not isinstance(result.get("settings"), dict):
        raise RuntimeError("Switch Vision Core did not return a valid settings payload.")
    return result


def _save_core_settings(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("Core settings request must contain a JSON object.")
    unknown = sorted(set(data) - {"settings", "reset_to_defaults"})
    if unknown:
        raise ValueError(f"Unsupported Core settings request field: {unknown[0]}")
    reset = data.get("reset_to_defaults", False)
    if not isinstance(reset, bool):
        raise ValueError("reset_to_defaults must be true or false.")
    command: dict[str, Any] = {"type": "switch_vision/set_settings", "reset_to_defaults": reset}
    if not reset:
        settings = data.get("settings")
        if not isinstance(settings, dict):
            raise ValueError("Core settings must contain a settings object.")
        command["settings"] = settings
    result = _home_assistant_ws(command)
    if not isinstance(result, dict) or not isinstance(result.get("settings"), dict):
        raise RuntimeError("Switch Vision Core did not confirm the saved settings.")
    return result


def _hub_app_path(value: Any, field: str) -> str:
    text = _plain_text(value, field, max_length=512, allow_empty=False).strip()
    path = PurePosixPath(text)
    if not path.is_absolute() or ".." in path.parts:
        raise ValueError(f"{field} must be an absolute path without parent traversal.")
    if not (text == "/config" or text.startswith("/config/") or text == "/share" or text.startswith("/share/")):
        raise ValueError(f"{field} must stay under /config or /share.")
    return str(path)


def _snmp2mqtt_addon_options() -> tuple[str, str, dict[str, Any]]:
    addon = _find_snmp2mqtt_addon()
    if addon is None:
        raise RuntimeError("Switch Vision SNMP2MQTT is not installed.")
    slug = str(addon.get("slug") or "").strip()
    if not slug:
        raise RuntimeError("Switch Vision SNMP2MQTT slug could not be resolved.")
    payload = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
    info = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    options = info.get("options") if isinstance(info, dict) else None
    if not isinstance(options, dict):
        raise RuntimeError("Home Assistant did not expose the SNMP2MQTT app options.")
    state = str(info.get("state") or addon.get("state") or "unknown").strip().lower()
    return slug, state, dict(options)


def _snmp2mqtt_settings_status() -> dict[str, Any]:
    try:
        slug, state, options = _snmp2mqtt_addon_options()
    except RuntimeError as exc:
        if "not installed" in str(exc).lower():
            return {"schema_version": 1, "installed": False, "settings": None, "password_configured": False}
        raise
    mqtt = options.get("mqtt") if isinstance(options.get("mqtt"), dict) else {}
    return {
        "schema_version": 1,
        "installed": True,
        "slug": slug,
        "state": state,
        "password_configured": bool(str(mqtt.get("password") or "")),
        "settings": {
            "mqtt": {
                "host": str(mqtt.get("host") or ""),
                "port": int(mqtt.get("port") or 1883),
                "username": str(mqtt.get("username") or ""),
                "password": "",
            },
            "targets_path": str(options.get("targets_path") or "/config/app_configs/switch_vision_snmp2mqtt/targets.yaml"),
            "use_switch_vision_generated_yaml": bool(options.get("use_switch_vision_generated_yaml", True)),
            "switch_vision_generated_yaml_path": str(options.get("switch_vision_generated_yaml_path") or "/share/switch_vision/generated-snmp2mqtt.yaml"),
            "imported_targets_path": str(options.get("imported_targets_path") or "/config/app_configs/switch_vision_snmp2mqtt/imported/generated-snmp2mqtt.yaml"),
            "backup_existing_config": bool(options.get("backup_existing_config", False)),
            "homeassistant": {"discovery": True, "prefix": "homeassistant"},
            "clear_password": False,
        },
        "enforced": {"homeassistant_discovery": True, "homeassistant_prefix": "homeassistant"},
    }


def _save_snmp2mqtt_settings(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict) or not isinstance(data.get("settings"), dict):
        raise ValueError("SNMP2MQTT settings request must contain a settings object.")
    if sorted(set(data) - {"settings"}):
        raise ValueError("SNMP2MQTT settings request contains unsupported fields.")
    requested = data["settings"]
    allowed = {"mqtt", "targets_path", "use_switch_vision_generated_yaml", "switch_vision_generated_yaml_path", "imported_targets_path", "backup_existing_config", "homeassistant", "clear_password"}
    unknown = sorted(set(requested) - allowed)
    if unknown:
        raise ValueError(f"Unsupported SNMP2MQTT setting: {unknown[0]}")
    ha_requested = requested.get("homeassistant")
    if not isinstance(ha_requested, dict) or sorted(set(ha_requested) - {"discovery", "prefix"}):
        raise ValueError("SNMP2MQTT Home Assistant discovery settings are invalid.")
    if ha_requested.get("discovery") is not True or str(ha_requested.get("prefix") or "") != "homeassistant":
        raise ValueError("Switch Vision requires SNMP2MQTT MQTT Discovery with the homeassistant prefix.")
    slug, app_state, current = _snmp2mqtt_addon_options()
    updated = dict(current)
    current_mqtt = current.get("mqtt") if isinstance(current.get("mqtt"), dict) else {}
    mqtt_requested = requested.get("mqtt")
    if not isinstance(mqtt_requested, dict) or sorted(set(mqtt_requested) - {"host", "port", "username", "password"}):
        raise ValueError("SNMP2MQTT MQTT settings are invalid.")
    host = _plain_text(mqtt_requested.get("host", ""), "MQTT host", max_length=255).strip()
    username = _plain_text(mqtt_requested.get("username", ""), "MQTT username", max_length=256).strip()
    port = mqtt_requested.get("port", 1883)
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError("MQTT port must be between 1 and 65535.")
    password = _plain_text(mqtt_requested.get("password", ""), "MQTT password", max_length=512)
    clear_password = requested.get("clear_password", False)
    if not isinstance(clear_password, bool):
        raise ValueError("Clear saved MQTT password must be true or false.")
    merged_mqtt = dict(current_mqtt)
    merged_mqtt.update({"host": host, "port": port, "username": username})
    merged_mqtt["password"] = "" if clear_password else (password if password else current_mqtt.get("password", ""))
    updated["mqtt"] = merged_mqtt
    for key in ("targets_path", "switch_vision_generated_yaml_path", "imported_targets_path"):
        if key not in requested:
            raise ValueError(f"SNMP2MQTT setting '{key}' is required by the Hub contract.")
        updated[key] = _hub_app_path(requested[key], key)
    for key in ("use_switch_vision_generated_yaml", "backup_existing_config"):
        value = requested.get(key)
        if type(value) is not bool:
            raise ValueError(f"{key} must be true or false.")
        updated[key] = value
    homeassistant = dict(current.get("homeassistant") or {}) if isinstance(current.get("homeassistant"), dict) else {}
    homeassistant.update({"discovery": True, "prefix": "homeassistant"})
    updated["homeassistant"] = homeassistant
    changed = updated != current
    if changed:
        _supervisor_json(f"/addons/{quote(slug, safe='')}/options", method="POST", timeout=20.0, payload={"options": updated})
        confirmed_slug, _, confirmed = _snmp2mqtt_addon_options()
        if confirmed_slug != slug:
            raise RuntimeError("SNMP2MQTT app identity changed while saving settings.")
        if confirmed != updated:
            raise RuntimeError("Home Assistant did not confirm the complete SNMP2MQTT settings update.")
        if app_state in {"started", "running"}:
            _supervisor_json(f"/addons/{quote(slug, safe='')}/restart", method="POST", timeout=30.0)
    result = _snmp2mqtt_settings_status()
    result.update({"saved": True, "changed": changed, "restart_requested": bool(changed and app_state in {"started", "running"})})
    return result


_DISCOVERY_HUB_SUPPORT_KEYS = {"generate_support_my_switch_bundle", "support_mask_management_ips", "support_mask_mac_addresses", "support_mask_hostnames", "support_mask_vlan_names", "support_mask_interface_descriptions", "support_contributor_type", "support_contributor_value"}
_DISCOVERY_HUB_KEYS = DISCOVERY_CONFIG_KEYS | _DISCOVERY_HUB_SUPPORT_KEYS
_DISCOVERY_HUB_BOOL_KEYS = {"run_snmp_walks", "enable_switch_list", "parse_all_walks", "generate_snmp2mqtt", "clean_output_before_walk", "backup_retention_enabled", "generate_support_my_switch_bundle", "support_mask_management_ips", "support_mask_mac_addresses", "support_mask_hostnames", "support_mask_vlan_names", "support_mask_interface_descriptions"}
_DISCOVERY_HUB_PATH_KEYS = {"input_path", "snmpwalks_dir", "report_path", "targets_csv", "last_run_summary_path", "generated_yaml_path", "generated_card_path", "snmp_log_path"}


def _discovery_settings_status() -> dict[str, Any]:
    options = _effective_discovery_options(_self_addon_options())
    defaults = {
        "input_path": "/share/switch_vision/snmpwalk.txt", "snmpwalks_dir": "/share/switch_vision/snmpwalks", "report_path": "/share/switch_vision/discovery-report.txt",
        "run_snmp_walks": "true", "enable_switch_list": "true", "switches": [], "stack_member_prefixes": [], "parse_all_walks": "false", "generate_snmp2mqtt": "true", "clean_output_before_walk": "false",
        "targets_csv": "/share/switch_vision/discovery-targets.csv", "last_run_summary_path": "/share/switch_vision/last-discovery-run.txt", "generated_yaml_path": "/share/switch_vision/generated-snmp2mqtt.yaml", "generated_card_path": "/share/switch_vision/generated-dashboard-card.yaml",
        "snmp_timeout": "3", "snmp_retries": "1", "snmp_log_path": "/share/switch_vision/snmpwalk.log", "minimum_valid_walk_lines": "100", "backup_retention_enabled": "true", "backup_retention_count": 5,
        "generate_support_my_switch_bundle": "true", "support_mask_management_ips": "true", "support_mask_mac_addresses": "true", "support_mask_hostnames": "true", "support_mask_vlan_names": "true", "support_mask_interface_descriptions": "true",
        "support_contributor_type": "anonymous", "support_contributor_value": "",
    }
    settings = {key: options.get(key, defaults.get(key)) for key in _DISCOVERY_HUB_KEYS}
    safe_switches: list[dict[str, Any]] = []
    for raw in settings.get("switches") if isinstance(settings.get("switches"), list) else []:
        if not isinstance(raw, dict):
            continue
        row = dict(raw)
        original_name = str(row.get("switch_name") or "").strip()
        row["snmp_community_configured"] = bool(str(row.get("snmp_community") or ""))
        row["snmp_community"] = ""
        row["original_switch_name"] = original_name
        safe_switches.append(row)
    pending_restore = _load_configuration_restore_pending()
    pending_switches = pending_restore.get("discovery_switches", [])
    if pending_switches:
        current_by_name = {
            str(row.get("switch_name") or "").strip(): row
            for row in safe_switches
            if isinstance(row, dict) and str(row.get("switch_name") or "").strip()
        }
        if not current_by_name:
            # Replace the blank Home Assistant placeholder with the backed-up
            # rows so a fresh install only needs its communities entered.
            safe_switches = []
        else:
            pending_names = {
                str(row.get("switch_name") or "").strip()
                for row in pending_switches
                if isinstance(row, dict) and str(row.get("switch_name") or "").strip()
            }
            safe_switches = [
                row
                for row in safe_switches
                if str(row.get("switch_name") or "").strip() not in pending_names
            ]
        for raw in pending_switches:
            if not isinstance(raw, dict):
                continue
            name = str(raw.get("switch_name") or "").strip()
            current_row = current_by_name.get(name)
            row = dict(raw)
            row["snmp_community"] = ""
            row["snmp_community_configured"] = bool(
                current_row and current_row.get("snmp_community_configured")
            )
            row["original_switch_name"] = name
            row["restore_pending"] = not row["snmp_community_configured"]
            safe_switches.append(row)
    settings["switches"] = safe_switches

    stack = settings.get("stack_member_prefixes")
    safe_stack = [dict(item) for item in stack if isinstance(item, dict)] if isinstance(stack, list) else []
    pending_stack = pending_restore.get("discovery_stack_member_prefixes", [])
    if pending_stack:
        pending_stack_keys = {
            (
                str(row.get("switch_name") or "").strip().casefold(),
                str(row.get("member") or row.get("member_number") or "").strip(),
            )
            for row in pending_stack
            if isinstance(row, dict)
        }
        safe_stack = [
            row
            for row in safe_stack
            if (
                str(row.get("switch_name") or "").strip().casefold(),
                str(row.get("member") or row.get("member_number") or "").strip(),
            ) not in pending_stack_keys
        ]
        safe_stack.extend(dict(raw) for raw in pending_stack if isinstance(raw, dict))
    settings["stack_member_prefixes"] = safe_stack
    settings["support_contributor_value_configured"] = bool(str(options.get("support_contributor_value") or ""))
    settings["support_contributor_value"] = ""
    return {
        "schema_version": 1,
        "settings": settings,
        "models": sorted({"auto"} | _manual_snmp_override_models()),
        "secret_policy": {
            "snmp_community": "redacted_default_reveal_on_demand_blank_preserves",
            "support_contributor_value": "write_only_blank_preserves",
        },
        "effective_config": _discovery_effective_config_provenance(options),
    }


def _save_discovery_settings(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict) or not isinstance(data.get("settings"), dict):
        raise ValueError("Discovery settings request must contain a settings object.")
    if sorted(set(data) - {"settings"}):
        raise ValueError("Discovery settings request contains unsupported fields.")
    requested = dict(data["settings"])
    requested.pop("support_contributor_value_configured", None)
    unknown = sorted(set(requested) - _DISCOVERY_HUB_KEYS)
    if unknown:
        raise ValueError(f"Unsupported Discovery setting: {unknown[0]}")
    with _OPTIONS_UPDATE_LOCK:
        current = _self_addon_options()
        current_effective = _effective_discovery_options(current)
        updated = dict(current)
        for key in _DISCOVERY_HUB_PATH_KEYS:
            if key in requested:
                updated[key] = _share_path(requested[key], key)
        walk_root = str(updated.get("snmpwalks_dir") or "")
        if walk_root and not (walk_root == "/share/switch_vision/snmpwalks" or walk_root.startswith("/share/switch_vision/snmpwalks/")):
            raise ValueError("snmpwalks_dir must stay under /share/switch_vision/snmpwalks.")
        for key in _DISCOVERY_HUB_BOOL_KEYS:
            if key in requested:
                updated[key] = _bool_string(requested[key], key)
        if "snmp_timeout" in requested:
            updated["snmp_timeout"] = _bounded_int_string(requested["snmp_timeout"], "snmp_timeout", 1, 30)
        if "snmp_retries" in requested:
            updated["snmp_retries"] = _bounded_int_string(requested["snmp_retries"], "snmp_retries", 0, 10)
        if "minimum_valid_walk_lines" in requested:
            updated["minimum_valid_walk_lines"] = _bounded_int_string(requested["minimum_valid_walk_lines"], "minimum_valid_walk_lines", 1, 1000000)
        if "backup_retention_count" in requested:
            updated["backup_retention_count"] = int(_bounded_int_string(requested["backup_retention_count"], "backup_retention_count", 1, 10))
        if "support_contributor_type" in requested:
            contributor_type = str(requested["support_contributor_type"] or "").strip()
            if contributor_type not in {"anonymous", "first_name", "full_name", "github", "forum"}:
                raise ValueError("support_contributor_type is not supported.")
            updated["support_contributor_type"] = contributor_type
        if "support_contributor_value" in requested or "support_contributor_type" in requested:
            contributor_type = str(updated.get("support_contributor_type") or "anonymous")
            value = _plain_text(requested.get("support_contributor_value", ""), "support_contributor_value", max_length=120).strip()
            current_type = str(current.get("support_contributor_type") or "anonymous")
            current_value = str(current.get("support_contributor_value") or "")
            if contributor_type == "anonymous":
                updated["support_contributor_value"] = ""
            elif value:
                updated["support_contributor_value"] = value
            elif contributor_type == current_type and current_value:
                updated["support_contributor_value"] = current_value
            else:
                raise ValueError("Enter the name or username for the selected recognition type.")
        if "switches" in requested:
            rows = requested["switches"]
            if not isinstance(rows, list) or len(rows) > 256:
                raise ValueError("switches must contain at most 256 entries.")
            current_rows = (
                current_effective.get("switches")
                if isinstance(current_effective.get("switches"), list)
                else []
            )
            current_by_name = {
                str(row.get("switch_name") or "").strip(): row
                for row in current_rows
                if isinstance(row, dict) and str(row.get("switch_name") or "").strip()
            }
            validated_rows: list[dict[str, Any]] = []
            for index, raw in enumerate(rows, start=1):
                if not isinstance(raw, dict):
                    raise ValueError(f"Switch entry {index} must be an object.")
                row = dict(raw)
                row.pop("snmp_community_configured", None)
                row.pop("restore_pending", None)
                original_name = str(row.pop("original_switch_name", "") or "").strip()
                community = row.get("snmp_community", "")
                if not isinstance(community, str):
                    raise ValueError(f"Switch entry {index} snmp_community must be text.")
                # The Hub intentionally never returns a saved community.  Treat
                # whitespace-only edits as blank so a harmless settings save
                # cannot replace a working write-only value with whitespace.
                community = community.strip()
                row["snmp_community"] = community
                if not community:
                    previous = current_by_name.get(original_name or str(row.get("switch_name") or "").strip())
                    preserved = str(previous.get("snmp_community") or "").strip() if previous else ""
                    if not preserved:
                        raise ValueError(f"Switch entry {index} requires an SNMP community for a new or renamed switch.")
                    row["snmp_community"] = preserved
                validated_rows.append(_validate_switch_row(row, index))
            updated["switches"] = validated_rows
        if "stack_member_prefixes" in requested:
            stack = requested["stack_member_prefixes"]
            if not isinstance(stack, list) or len(stack) > 512:
                raise ValueError("stack_member_prefixes must contain at most 512 entries.")
            updated["stack_member_prefixes"] = [_validate_stack_row(item, index) for index, item in enumerate(stack, start=1)]
        _validate_inventory_identities(updated)
        changed = updated != current
        if changed:
            create_pre_mutation_backup(current, reason="hub_settings_update")
            _supervisor_json("/addons/self/options", method="POST", timeout=20.0, payload={"options": updated})
            confirmed = _self_addon_options()
            if confirmed != updated:
                raise RuntimeError("Home Assistant did not confirm the complete Discovery settings update.")
            if "switches" in requested:
                _reconcile_device_added_at(confirmed)
            enforce_retention(confirmed)
    if "switches" in requested:
        _clear_configuration_restore_pending("discovery_switches")
    if "stack_member_prefixes" in requested:
        _clear_configuration_restore_pending("discovery_stack_member_prefixes")
    result = _discovery_settings_status()
    result.update({"saved": True, "changed": changed})
    return result


def _reveal_hub_secret(data: Any) -> dict[str, Any]:
    """Return exactly one saved Hub credential after an explicit operator request."""
    if not isinstance(data, dict):
        raise ValueError("Secret reveal request must be a JSON object.")
    unknown = sorted(set(data) - {"scope", "kind", "identifier"})
    if unknown:
        raise ValueError(f"Unsupported secret reveal field: {unknown[0]}")
    scope = _plain_text(data.get("scope", ""), "scope", max_length=64, allow_empty=False).strip().lower()
    kind = _plain_text(data.get("kind", ""), "kind", max_length=64, allow_empty=False).strip().lower()
    identifier = _plain_text(data.get("identifier", ""), "identifier", max_length=256).strip()
    value = ""

    if scope == "discovery":
        if kind != "snmp_community":
            raise ValueError("Unsupported Discovery credential type.")
        if not identifier:
            raise ValueError("A saved switch name is required.")
        options = _effective_discovery_options(_self_addon_options())
        rows = options.get("switches") if isinstance(options.get("switches"), list) else []
        matches = [
            row for row in rows
            if isinstance(row, dict) and str(row.get("switch_name") or "").strip() == identifier
        ]
        if len(matches) != 1:
            raise ValueError("The saved switch could not be uniquely resolved.")
        value = str(matches[0].get("snmp_community") or "")

    elif scope == "snmp2mqtt":
        if kind != "mqtt_password":
            raise ValueError("Unsupported SNMP2MQTT credential type.")
        _slug, _state, options = _snmp2mqtt_addon_options()
        mqtt = options.get("mqtt") if isinstance(options.get("mqtt"), dict) else {}
        value = str(mqtt.get("password") or "")

    elif scope == "unifi2mqtt":
        addon = _find_unifi2mqtt_addon(include_store=True)
        if addon is None or not addon.get("slug"):
            raise RuntimeError("Switch Vision UniFi2MQTT is not installed.")
        slug = str(addon.get("slug") or "").strip()
        info = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
        info_data = info.get("data") if isinstance(info.get("data"), dict) else info
        options = info_data.get("options") if isinstance(info_data, dict) else None
        if not isinstance(options, dict):
            raise RuntimeError("Home Assistant did not expose the current UniFi2MQTT options.")
        legacy_transport = str(options.get("transport") or "local").strip().lower()
        legacy_value = str(options.get("api_key") or "")
        if kind == "local_api_key":
            value = str(options.get("local_api_key") or "")
            if not value and legacy_transport == "local":
                value = legacy_value
        elif kind == "remote_api_key":
            value = str(options.get("remote_api_key") or "")
            if not value and legacy_transport == "remote":
                value = legacy_value
        elif kind == "mqtt_password":
            value = str(options.get("mqtt_password") or "")
        elif kind == "controller_api_key":
            if not identifier:
                raise ValueError("A saved controller ID is required.")
            rows = options.get("controllers") if isinstance(options.get("controllers"), list) else []
            matches = [
                row for row in rows
                if isinstance(row, dict) and str(row.get("id") or "").strip() == identifier
            ]
            if len(matches) != 1:
                raise ValueError("The saved UniFi controller could not be uniquely resolved.")
            value = str(matches[0].get("api_key") or "")
        else:
            raise ValueError("Unsupported UniFi2MQTT credential type.")
    else:
        raise ValueError("Unsupported secret reveal scope.")

    if not value:
        raise ValueError("No saved credential is configured for this field.")
    if "\x00" in value or "\r" in value or "\n" in value:
        raise RuntimeError("The saved credential contains invalid control characters and cannot be revealed.")
    return {"ok": True, "secret": value}


def _snmp2mqtt_slug(value: Any) -> str:
    """Match Switch Vision SNMP2MQTT's generated ASCII sensor-name slugs."""
    text = str(value or "").lower().replace("-", "_").replace("~", "_")
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[^a-z0-9_]+", "_", text)
    return text.strip("_")


def _snmp2mqtt_discovery_topics(path: Path, prefix: str) -> list[str]:
    """Enumerate HA MQTT Discovery topics emitted from a generated target file."""
    if not path.is_file():
        return []
    try:
        document = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        return []
    if not isinstance(document, dict) or not isinstance(document.get("targets"), list):
        return []
    topics: set[str] = set()
    safe_prefix = str(prefix or "").strip().strip("/")
    if not safe_prefix or "+" in safe_prefix or "#" in safe_prefix:
        return []
    for target in document["targets"]:
        if not isinstance(target, dict):
            continue
        sensors = target.get("sensors")
        if not isinstance(sensors, list):
            continue
        for sensor in sensors:
            if not isinstance(sensor, dict):
                continue
            component = "binary_sensor" if bool(sensor.get("binary_sensor")) else "sensor"
            topic_name = str(sensor.get("object_id") or "").strip() or _snmp2mqtt_slug(sensor.get("name"))
            if not topic_name or "/" in topic_name or "+" in topic_name or "#" in topic_name:
                continue
            topics.add(f"{safe_prefix}/{component}/snmp2mqtt/{topic_name}/config")
    return sorted(topics)


def _load_snmp2mqtt_retirement_topics() -> list[str]:
    """Load the last known generated HA MQTT Discovery topics (never secrets)."""
    if not DEFAULT_SNMP_RETIREMENT_STATE.is_file():
        return []
    try:
        data = json.loads(DEFAULT_SNMP_RETIREMENT_STATE.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return []
    raw_topics = data.get("topics") if isinstance(data, dict) else None
    if not isinstance(raw_topics, list):
        return []
    topics: set[str] = set()
    for value in raw_topics:
        topic = str(value or "").strip().strip("/")
        if not topic or "+" in topic or "#" in topic or not topic.endswith("/config"):
            continue
        topics.add(topic)
    return sorted(topics)


def _save_snmp2mqtt_retirement_topics(topics: list[str]) -> None:
    """Persist only exact discovery topic names so cleanup survives app restarts."""
    clean = sorted({str(topic).strip().strip("/") for topic in topics if str(topic).strip()})
    DEFAULT_SNMP_RETIREMENT_STATE.parent.mkdir(parents=True, exist_ok=True)
    if not clean:
        DEFAULT_SNMP_RETIREMENT_STATE.unlink(missing_ok=True)
        return
    payload = {
        "version": 1,
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "topics": clean,
    }
    tmp = DEFAULT_SNMP_RETIREMENT_STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, DEFAULT_SNMP_RETIREMENT_STATE)


def _remember_current_snmp2mqtt_topics() -> list[str]:
    """Snapshot active generated discovery topics for later retirement."""
    if not DEFAULT_GENERATED_SNMP2MQTT.is_file():
        return _load_snmp2mqtt_retirement_topics()
    runtime = _snmp2mqtt_runtime_info()
    if runtime.get("options_readable") and runtime.get("homeassistant_prefix"):
        topics = _snmp2mqtt_discovery_topics(
            DEFAULT_GENERATED_SNMP2MQTT,
            str(runtime["homeassistant_prefix"]),
        )
        if topics:
            _save_snmp2mqtt_retirement_topics(topics)
            return topics
    return _load_snmp2mqtt_retirement_topics()


def _stop_snmp2mqtt_for_reset(info: dict[str, Any]) -> bool:
    slug = str(info.get("slug") or "").strip()
    state = str(info.get("state") or "").lower()
    if not slug or state not in {"started", "running"}:
        return False
    _supervisor_json(f"/addons/{quote(slug, safe='')}/stop", method="POST", timeout=30.0)
    return True


def _clear_retained_snmp2mqtt_discovery(topics: list[str]) -> tuple[int, list[str]]:
    cleared = 0
    warnings: list[str] = []
    for topic in topics:
        try:
            # Home Assistant MQTT treats an empty retained payload as deletion of
            # the retained discovery configuration, which removes the entity.
            _home_assistant_service(
                "mqtt",
                "publish",
                {"topic": topic, "payload": "", "qos": 0, "retain": True},
            )
            cleared += 1
        except RuntimeError as exc:
            warnings.append(f"Could not clear {topic}: {exc}")
            if len(warnings) >= 8:
                break
    return cleared, warnings


def _clear_generated_directory(path: Path) -> int:
    if not path.exists():
        path.mkdir(parents=True, exist_ok=True)
        return 0
    removed = 0
    for child in list(path.iterdir()):
        try:
            if child.is_dir() and not child.is_symlink():
                removed += sum(1 for item in child.rglob("*") if item.is_file() or item.is_symlink())
                shutil.rmtree(child)
            else:
                child.unlink(missing_ok=True)
                removed += 1
        except OSError as exc:
            raise RuntimeError(f"Could not remove generated SNMP data {child}: {exc}") from exc
    path.mkdir(parents=True, exist_ok=True)
    return removed


def _reset_snmp_discovery_data() -> dict[str, Any]:
    """Retire SNMP-generated state without touching UniFi API data or config."""
    if _discovery_state_snapshot().get("running"):
        raise RuntimeError("Stop Discovery before resetting SNMP Discovery data.")

    runtime = _snmp2mqtt_runtime_info()
    topics: set[str] = set(_load_snmp2mqtt_retirement_topics())
    warnings: list[str] = []
    if DEFAULT_GENERATED_SNMP2MQTT.is_file():
        if runtime.get("options_readable") and runtime.get("homeassistant_prefix"):
            topics.update(_snmp2mqtt_discovery_topics(
                DEFAULT_GENERATED_SNMP2MQTT,
                str(runtime["homeassistant_prefix"]),
            ))
        elif runtime.get("installed") and not topics:
            warnings.append(
                "SNMP2MQTT settings could not be read safely, so retained MQTT discovery topics were not guessed or removed."
            )
    topic_list = sorted(topics)

    stopped = False
    safe_to_clear_mqtt = str(runtime.get("state") or "").lower() not in {"started", "running"}
    try:
        stopped = _stop_snmp2mqtt_for_reset(runtime)
        if stopped:
            safe_to_clear_mqtt = True
    except RuntimeError as exc:
        safe_to_clear_mqtt = False
        warnings.append(f"Could not stop Switch Vision SNMP2MQTT: {exc}")

    mqtt_cleared = 0
    if topic_list and safe_to_clear_mqtt:
        mqtt_cleared, mqtt_warnings = _clear_retained_snmp2mqtt_discovery(topic_list)
        warnings.extend(mqtt_warnings)
        if mqtt_cleared == len(topic_list) and not mqtt_warnings:
            _save_snmp2mqtt_retirement_topics([])
    elif topic_list and not safe_to_clear_mqtt:
        warnings.append("Retained MQTT discovery entries were left in place because SNMP2MQTT could not be stopped safely.")

    removed_files: list[str] = []
    for path in SNMP_RESET_FILES:
        try:
            if path.is_file() or path.is_symlink():
                path.unlink(missing_ok=True)
                removed_files.append(path.name)
        except OSError as exc:
            raise RuntimeError(f"Could not remove {path}: {exc}") from exc

    walk_entries = _clear_generated_directory(DEFAULT_SNMPWALKS_DIR)
    capability_entries = _clear_generated_directory(DEFAULT_CAPABILITIES_DIR)

    return {
        "reset": True,
        "snmp2mqtt_stopped": stopped,
        "mqtt_topics_found": len(topic_list),
        "mqtt_topics_cleared": mqtt_cleared,
        "removed_files": removed_files,
        "walk_entries_removed": walk_entries,
        "capability_entries_removed": capability_entries,
        "unifi_snapshot_preserved": DEFAULT_UNIFI_SNAPSHOT.is_file(),
        "warnings": warnings,
        "message": (
            "SNMP Discovery data reset. Run Discovery again to rebuild the dashboard from the currently enabled sources."
        ),
    }


def _unifi_mqtt_slug(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value or "").strip().lower()).strip("_") or "unifi_switch"


def _unifi_retirement_topics_from_snapshot(
    snapshot: Any,
    options: dict[str, Any],
) -> list[str]:
    """Return only retained MQTT topics proven to belong to current UniFi snapshot rows."""
    if not isinstance(snapshot, dict):
        return []
    devices = snapshot.get("devices")
    if not isinstance(devices, list):
        return []
    topic_prefix = str(options.get("mqtt_topic_prefix") or "switch_vision/unifi").strip().strip("/")
    discovery_prefix = str(options.get("mqtt_discovery_prefix") or "homeassistant").strip().strip("/")
    if not topic_prefix or not discovery_prefix or any(mark in topic_prefix + discovery_prefix for mark in "+#"):
        return []

    topics: set[str] = {f"{topic_prefix}/status"}
    for raw in devices:
        if not isinstance(raw, dict):
            continue
        did = _unifi_mqtt_slug(raw.get("id") or raw.get("name"))
        base = f"{topic_prefix}/{did}"
        topics.add(f"{base}/available")

        def sensor(key: str) -> None:
            uid = f"switch_vision_unifi_{did}_{_unifi_mqtt_slug(key)}"
            topics.add(f"{base}/{key}")
            topics.add(f"{discovery_prefix}/sensor/{uid}/config")

        def binary(key: str) -> None:
            uid = f"switch_vision_unifi_{did}_{_unifi_mqtt_slug(key)}"
            topics.add(f"{base}/{key}")
            topics.add(f"{discovery_prefix}/binary_sensor/{uid}/config")

        for key in ("model", "firmware"):
            sensor(key)
        binary("online")
        for key in ("cpu", "memory", "uptime", "uplink_rx_rate", "uplink_tx_rate"):
            sensor(key)

        ports = raw.get("ports")
        for port in ports if isinstance(ports, list) else []:
            if not isinstance(port, dict) or port.get("idx") is None:
                continue
            try:
                number = int(port["idx"])
            except (TypeError, ValueError):
                continue
            prefix = f"port/{number}"
            binary(f"{prefix}/status")
            for key in ("speed", "max_speed", "connector"):
                sensor(f"{prefix}/{key}")
            binary(f"{prefix}/poe_enabled")
            binary(f"{prefix}/poe_active")
            sensor(f"{prefix}/poe_standard")
            for key in ("traffic_available", "activity", "activity_at", "rx_bytes", "tx_bytes"):
                topics.add(f"{base}/{prefix}/{key}")
            activity_uid = f"switch_vision_unifi_{did}_{_unifi_mqtt_slug(prefix + '/activity')}"
            topics.add(f"{discovery_prefix}/binary_sensor/{activity_uid}/config")
    return sorted(topics)


def _reset_everything() -> dict[str, Any]:
    """Reset mutable Switch Vision configuration/runtime state, preserving user recovery/content."""
    if _discovery_state_snapshot().get("running"):
        raise RuntimeError("Stop Discovery before using Reset Everything.")

    current_discovery = _self_addon_options()
    create_pre_mutation_backup(current_discovery, reason="reset_everything")

    unifi_status = _unifi2mqtt_settings_status()
    unifi_snapshot = _read_json(DEFAULT_UNIFI_SNAPSHOT)
    unifi_options = dict(UNIFI2MQTT_DEFAULT_OPTIONS)
    unifi_slug = str(unifi_status.get("slug") or "").strip()
    if unifi_status.get("installed") and unifi_slug:
        try:
            info = _supervisor_json(f"/addons/{quote(unifi_slug, safe='')}/info")
            info_data = info.get("data") if isinstance(info.get("data"), dict) else info
            stored = info_data.get("options") if isinstance(info_data, dict) else None
            if isinstance(stored, dict):
                unifi_options.update(stored)
            if str(info_data.get("state") or "").lower() in {"started", "running"}:
                _supervisor_json(
                    f"/addons/{quote(unifi_slug, safe='')}/stop",
                    method="POST",
                    timeout=30.0,
                )
        except RuntimeError as exc:
            raise RuntimeError(f"Could not stop UniFi2MQTT safely before reset: {exc}") from exc

    snmp_result = _reset_snmp_discovery_data()

    unifi_topics = _unifi_retirement_topics_from_snapshot(unifi_snapshot, unifi_options)
    unifi_cleared = 0
    unifi_warnings: list[str] = []
    for topic in unifi_topics:
        try:
            _home_assistant_service(
                "mqtt",
                "publish",
                {"topic": topic, "payload": "", "qos": 0, "retain": True},
            )
            unifi_cleared += 1
        except RuntimeError as exc:
            unifi_warnings.append(f"Could not clear {topic}: {exc}")
            if len(unifi_warnings) >= 8:
                break

    _home_assistant_service(
        "switch_vision",
        "reset_calibrations",
        {"scope": "all"},
    )
    _save_core_settings({"reset_to_defaults": True})

    installer_reset = False
    try:
        installer = _installer_settings_status()
        if installer.get("installed"):
            _save_installer_settings(INSTALLER_RESET_SETTINGS)
            installer_reset = True
    except RuntimeError as exc:
        raise RuntimeError(f"Could not reset Installer settings: {exc}") from exc

    snmp_addon = _find_snmp2mqtt_addon()
    snmp_settings_reset = False
    if snmp_addon is not None:
        snmp_slug = str(snmp_addon.get("slug") or "").strip()
        if snmp_slug:
            _supervisor_json(
                f"/addons/{quote(snmp_slug, safe='')}/options",
                method="POST",
                timeout=20.0,
                payload={"options": copy.deepcopy(SNMP2MQTT_RESET_OPTIONS)},
            )
            snmp_settings_reset = True

    unifi_settings_reset = False
    if unifi_status.get("installed") and unifi_slug:
        _supervisor_json(
            f"/addons/{quote(unifi_slug, safe='')}/options",
            method="POST",
            timeout=20.0,
            payload={"options": copy.deepcopy(UNIFI2MQTT_DEFAULT_OPTIONS)},
        )
        unifi_settings_reset = True

    _supervisor_json(
        "/addons/self/options",
        method="POST",
        timeout=20.0,
        payload={"options": copy.deepcopy(DISCOVERY_RESET_OPTIONS)},
    )

    removed_runtime: list[str] = []
    for path in (
        DEFAULT_UNIFI_SNAPSHOT,
        DEFAULT_UNIFI_DIAGNOSTICS,
        DEFAULT_DEVICE_CONTROL,
        DEFAULT_CONFIGURATION_RESTORE_PENDING,
        UI_PREFERENCES_PATH,
        DEFAULT_DISCOVERY_HISTORY,
        DEFAULT_INSTALLER_MAINTENANCE_RESPONSE,
        DEFAULT_DISCOVERY_LOG,
        DEFAULT_CURRENT_DISCOVERY_DEBUG,
    ):
        try:
            if path.is_file() or path.is_symlink():
                path.unlink(missing_ok=True)
                removed_runtime.append(str(path))
        except OSError as exc:
            raise RuntimeError(f"Could not remove mutable Switch Vision runtime state {path}: {exc}") from exc

    return {
        "reset": True,
        "core_settings_reset": True,
        "core_calibrations_reset": True,
        "discovery_settings_reset": True,
        "snmp2mqtt_settings_reset": snmp_settings_reset,
        "unifi2mqtt_settings_reset": unifi_settings_reset,
        "installer_settings_reset": installer_reset,
        "snmp": snmp_result,
        "unifi_mqtt_topics_found": len(unifi_topics),
        "unifi_mqtt_topics_cleared": unifi_cleared,
        "warnings": list(snmp_result.get("warnings") or []) + unifi_warnings,
        "removed_runtime": removed_runtime,
        "preserved": [
            "installed Switch Vision apps",
            "Installer recovery backups",
            "Discovery configuration backups",
            "Support My Switch contribution archives",
            "custom faceplate and logo files",
            "protected contribution/source originals",
        ],
        "message": (
            "Switch Vision mutable settings and runtime state were reset. "
            "Installed apps, backup sets, contribution archives, and custom visual assets were preserved."
        ),
    }


def _addon_payload_list(path: str) -> list[dict[str, Any]]:
    payload = _supervisor_json(path)
    data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    if isinstance(data, dict):
        items = data.get("addons", [])
    elif isinstance(data, list):
        items = data
    else:
        items = []
    return [item for item in items if isinstance(item, dict)]


def _unifi2mqtt_score(addon: dict[str, Any]) -> int:
    slug = str(addon.get("slug") or "").strip()
    name = str(addon.get("name") or "").strip()
    haystack = f"{slug} {name}".casefold().replace("-", "_")
    if "unifi2mqtt" not in haystack:
        return -1
    score = 0
    if "switch_vision" in haystack or "switch vision" in haystack:
        score += 20
    normalized_slug = slug.casefold().replace("-", "_")
    if normalized_slug.endswith("switch_vision_unifi2mqtt"):
        score += 20
    if name.casefold() == "switch vision unifi2mqtt":
        score += 40
    if addon.get("installed") not in (False, None, "", 0):
        score += 5
    return score


def _find_unifi2mqtt_addon(*, include_store: bool = True) -> dict[str, Any] | None:
    candidates: list[tuple[int, dict[str, Any]]] = []
    try:
        for addon in _addon_payload_list("/addons"):
            score = _unifi2mqtt_score(addon)
            if score >= 0:
                copy = dict(addon)
                copy["_source"] = "addons"
                candidates.append((score + 100, copy))
    except RuntimeError:
        pass
    if include_store:
        try:
            for addon in _addon_payload_list("/store/addons"):
                score = _unifi2mqtt_score(addon)
                if score >= 0:
                    copy = dict(addon)
                    copy["_source"] = "store"
                    candidates.append((score, copy))
        except RuntimeError:
            pass
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _unifi2mqtt_snapshot_status() -> dict[str, Any]:
    info = _file_info(DEFAULT_UNIFI_SNAPSHOT)
    count = 0
    generated_at = None
    snapshot = _read_json(DEFAULT_UNIFI_SNAPSHOT)
    if isinstance(snapshot, dict):
        devices = snapshot.get("devices")
        if isinstance(devices, list):
            count = len([item for item in devices if isinstance(item, dict)])
        generated_at = snapshot.get("generated_at")
    return {**info, "device_count": count, "generated_at": generated_at}


def _safe_unifi_diagnostic_text(
    value: Any,
    *,
    max_length: int = 128,
) -> str | None:
    text = str(value or "").strip()
    if not text or len(text) > max_length:
        return None
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in text):
        return None
    return text


def _unifi2mqtt_diagnostics_status() -> dict[str, Any]:
    """Return only privacy-safe UniFi2MQTT diagnostic evidence."""
    info = _file_info(DEFAULT_UNIFI_DIAGNOSTICS)
    payload = _read_json(DEFAULT_UNIFI_DIAGNOSTICS)

    if not isinstance(payload, dict):
        return {
            **info,
            "valid": False,
            "version": None,
            "status": None,
            "stage": None,
            "adopted_devices": 0,
            "switching_devices": 0,
            "rejected_devices": 0,
            "empty_switch_polls": 0,
            "error_type": None,
            "connection_mode": None,
            "priority_transport": None,
            "fallback_transport": None,
            "active_transport": None,
            "failover_active": False,
            "transports_attempted": [],
            "device_classification": [],
        }

    classifications: list[dict[str, Any]] = []

    raw_rows = payload.get("device_classification")
    if isinstance(raw_rows, list):
        for raw in raw_rows[:256]:
            if not isinstance(raw, dict):
                continue

            model = _safe_unifi_diagnostic_text(
                raw.get("model"),
                max_length=128,
            ) or "Unknown"

            features: list[str] = []
            raw_features = raw.get("features")
            if isinstance(raw_features, list):
                for value in raw_features[:64]:
                    feature = _safe_unifi_diagnostic_text(
                        value,
                        max_length=64,
                    )
                    if (
                        feature
                        and re.fullmatch(
                            r"[A-Za-z0-9_.:+-]+",
                            feature,
                        )
                    ):
                        features.append(feature)

            reason = _safe_unifi_diagnostic_text(
                raw.get("reason"),
                max_length=64,
            )

            classifications.append(
                {
                    "model": model,
                    "features": sorted(
                        set(features),
                        key=str.casefold,
                    ),
                    "accepted": bool(
                        raw.get("accepted")
                    ),
                    "reason": reason,
                }
            )

    def safe_count(key: str) -> int:
        value = payload.get(key)
        if isinstance(value, bool):
            return 0
        if isinstance(value, int):
            return max(0, min(value, 100000))
        return 0

    return {
        **info,
        "valid": True,
        "version": _safe_unifi_diagnostic_text(
            payload.get("version"),
            max_length=32,
        ),
        "status": _safe_unifi_diagnostic_text(
            payload.get("status"),
            max_length=32,
        ),
        "stage": _safe_unifi_diagnostic_text(
            payload.get("stage"),
            max_length=64,
        ),
        "adopted_devices": safe_count(
            "adopted_devices"
        ),
        "switching_devices": safe_count(
            "switching_devices"
        ),
        "rejected_devices": safe_count(
            "rejected_devices"
        ),
        "empty_switch_polls": safe_count(
            "empty_switch_polls"
        ),
        "error_type": _safe_unifi_diagnostic_text(
            payload.get("error_type"),
            max_length=128,
        ),
        "connection_mode": _safe_unifi_diagnostic_text(
            payload.get("connection_mode"),
            max_length=32,
        ),
        "priority_transport": _safe_unifi_diagnostic_text(
            payload.get("priority_transport"),
            max_length=16,
        ),
        "fallback_transport": _safe_unifi_diagnostic_text(
            payload.get("fallback_transport"),
            max_length=16,
        ),
        "active_transport": _safe_unifi_diagnostic_text(
            payload.get("active_transport"),
            max_length=16,
        ),
        "failover_active": bool(payload.get("failover_active")),
        "transports_attempted": [
            value
            for value in (
                _safe_unifi_diagnostic_text(item, max_length=16)
                for item in (payload.get("transports_attempted") or [])[:4]
            )
            if value in {"local", "remote"}
        ] if isinstance(payload.get("transports_attempted"), list) else [],
        "device_classification": classifications,
    }


def _unifi_connection_transport(value: Any, field: str, *, allow_none: bool = False) -> str:
    text = str(value or ("none" if allow_none else "local")).strip().lower()
    allowed = {"local", "remote"} | ({"none"} if allow_none else set())
    if text not in allowed:
        expected = "local, remote or none" if allow_none else "local or remote"
        raise ValueError(f"{field} must be {expected}.")
    return text


def _unifi_origin(value: Any, field: str, *, allow_http: bool = False) -> str:
    text = _plain_text(str(value or ""), field, max_length=512, allow_empty=False).strip().rstrip("/")
    parsed = urlparse(text)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"{field} must be a valid http:// or https:// controller URL.")
    if parsed.username or parsed.password:
        raise ValueError(f"{field} must not contain embedded credentials.")
    if parsed.query or parsed.fragment or parsed.path not in {"", "/"}:
        raise ValueError(f"{field} must identify the controller origin without an extra path, query or fragment.")
    if parsed.scheme == "http" and not allow_http:
        raise ValueError(f"{field} uses plaintext HTTP. Enable the explicit insecure-HTTP option only when that risk is accepted.")
    return text


def _unifi_controller_browser_rows(options: dict[str, Any]) -> list[dict[str, Any]]:
    rows = options.get("controllers")
    if not isinstance(rows, list):
        return []
    safe: list[dict[str, Any]] = []
    for raw in rows[:32]:
        if not isinstance(raw, dict):
            continue
        transport = str(raw.get("transport") or "local").strip().lower()
        if transport not in {"local", "remote"}:
            transport = "local"
        safe.append({
            "id": str(raw.get("id") or "")[:64],
            "transport": transport,
            "controller_url": str(raw.get("controller_url") or "")[:512],
            "host_id": str(raw.get("host_id") or "auto")[:256],
            "site_id": str(raw.get("site_id") or "auto")[:256],
            "verify_ssl": str(raw.get("verify_ssl", "true")).lower() in {"1", "true", "yes", "on"},
            "allow_insecure_http": str(raw.get("allow_insecure_http", "false")).lower() in {"1", "true", "yes", "on"},
            "api_key_configured": bool(str(raw.get("api_key") or "").strip()),
        })
    return safe


def _unifi2mqtt_settings_status() -> dict[str, Any]:
    addon = _find_unifi2mqtt_addon(include_store=True)
    snapshot = _unifi2mqtt_snapshot_status()
    diagnostics = _unifi2mqtt_diagnostics_status()
    options = dict(UNIFI2MQTT_DEFAULT_OPTIONS)
    options_readable = False
    installed = False
    available = addon is not None
    state = "not_installed"
    slug: str | None = None

    if addon is not None:
        slug = str(addon.get("slug") or "").strip() or None
        installed_value = addon.get("installed")
        installed = addon.get("_source") == "addons" or installed_value not in (False, None, "", 0)
        state = str(addon.get("state") or ("stopped" if installed else "not_installed"))
        if installed and slug:
            try:
                info = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
                info_data = info.get("data") if isinstance(info.get("data"), dict) else info
                if isinstance(info_data, dict):
                    state = str(info_data.get("state") or state)
                    stored = info_data.get("options")
                    if isinstance(stored, dict):
                        options.update(stored)
                        options_readable = True
            except RuntimeError:
                pass

    safe_options = {
        key: value
        for key, value in options.items()
        if key not in UNIFI2MQTT_SECRET_FIELDS and key != "controllers"
    }
    safe_controllers = _unifi_controller_browser_rows(options)
    pending_controllers = _load_configuration_restore_pending().get("unifi_controllers", [])
    if pending_controllers:
        known_ids = {str(row.get("id") or "").strip() for row in safe_controllers}
        for raw in pending_controllers:
            if not isinstance(raw, dict):
                continue
            controller_id = str(raw.get("id") or "").strip()
            if controller_id and controller_id in known_ids:
                continue
            row = dict(raw)
            row["api_key_configured"] = False
            row["restore_pending"] = True
            safe_controllers.append(row)
            if controller_id:
                known_ids.add(controller_id)
    safe_options["controllers"] = safe_controllers

    legacy_transport = str(options.get("transport") or "local").strip().lower()
    legacy_key = bool(str(options.get("api_key") or "").strip())
    local_key = bool(str(options.get("local_api_key") or "").strip()) or (
        legacy_transport == "local" and legacy_key
    )
    remote_key = bool(str(options.get("remote_api_key") or "").strip()) or (
        legacy_transport == "remote" and legacy_key
    )
    controller_credentials_configured = bool(safe_controllers) and all(
        bool(row.get("api_key_configured")) for row in safe_controllers
    )
    multi_controller_enabled = bool(safe_controllers)
    connection_ready = controller_credentials_configured if multi_controller_enabled else (local_key or remote_key)

    return {
        "installed": installed,
        "available": available,
        "state": state,
        "slug": slug,
        "config_url": f"/config/app/{quote(slug, safe='')}/config" if installed and slug else None,
        "options": safe_options,
        "api_key_configured": legacy_key,
        "local_api_key_configured": local_key,
        "remote_api_key_configured": remote_key,
        "mqtt_password_configured": bool(str(options.get("mqtt_password") or "").strip()),
        "multi_controller_enabled": multi_controller_enabled,
        "controller_count": len(safe_controllers),
        "controller_credentials_configured": controller_credentials_configured,
        "connection_ready": connection_ready,
        "active_transport": diagnostics.get("active_transport"),
        "failover_active": bool(diagnostics.get("failover_active")),
        "connection_diagnostics": diagnostics,
        "options_readable": options_readable,
        "snapshot": snapshot,
    }


def _validate_unifi_controller_rows(data: Any, current: dict[str, Any]) -> list[dict[str, Any]]:
    if not isinstance(data, list):
        raise ValueError("controllers must be a list.")
    if len(data) > 32:
        raise ValueError("No more than 32 UniFi controller entries are supported.")
    current_rows = current.get("controllers") if isinstance(current.get("controllers"), list) else []
    current_by_id = {
        str(row.get("id") or "").strip(): row
        for row in current_rows
        if isinstance(row, dict) and str(row.get("id") or "").strip()
    }
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for position, raw in enumerate(data, start=1):
        if not isinstance(raw, dict):
            raise ValueError(f"Controller {position} must be an object.")
        controller_id = _plain_text(str(raw.get("id") or ""), f"controllers[{position}].id", max_length=64, allow_empty=False).strip()
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", controller_id):
            raise ValueError(f"Controller {position} ID must use letters, digits, hyphen or underscore and start with a letter or digit.")
        normalized = controller_id.casefold()
        if normalized in seen:
            raise ValueError(f"Controller ID {controller_id!r} is duplicated.")
        seen.add(normalized)
        previous = current_by_id.get(controller_id, {})
        transport = _unifi_connection_transport(raw.get("transport", previous.get("transport", "local")), f"controllers[{position}].transport")
        api_key = str(raw.get("api_key") or "") or str(previous.get("api_key") or "")
        if not api_key:
            raise ValueError(f"Controller {controller_id} requires an API key.")
        api_key = _plain_text(api_key, f"controllers[{position}].api_key", max_length=4096, allow_empty=False)
        site_id = _plain_text(str(raw.get("site_id", previous.get("site_id", "auto")) or "auto"), f"controllers[{position}].site_id", max_length=256, allow_empty=False).strip()
        if transport == "local":
            allow_http = _bool_string(raw.get("allow_insecure_http", previous.get("allow_insecure_http", "false")), f"controllers[{position}].allow_insecure_http")
            controller_url = _unifi_origin(raw.get("controller_url", previous.get("controller_url", "")), f"controllers[{position}].controller_url", allow_http=allow_http == "true")
            verify_ssl = _bool_string(raw.get("verify_ssl", previous.get("verify_ssl", "true")), f"controllers[{position}].verify_ssl")
            host_id = "auto"
        else:
            controller_url = ""
            host_id = _plain_text(str(raw.get("host_id", previous.get("host_id", "auto")) or "auto"), f"controllers[{position}].host_id", max_length=256, allow_empty=False).strip()
            verify_ssl = "true"
            allow_http = "false"
        result.append({
            "id": controller_id,
            "transport": transport,
            "controller_url": controller_url,
            "host_id": host_id,
            "site_id": site_id,
            "api_key": api_key,
            "verify_ssl": verify_ssl,
            "allow_insecure_http": allow_http,
        })
    return result


def _validate_unifi2mqtt_options(data: Any, current: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("UniFi2MQTT settings must be a JSON object.")
    result = dict(current)

    priority = _unifi_connection_transport(
        data.get("priority_transport", result.get("priority_transport", result.get("transport", "local"))),
        "priority_transport",
    )
    fallback = _unifi_connection_transport(
        data.get("fallback_transport", result.get("fallback_transport", "none")),
        "fallback_transport",
        allow_none=True,
    )
    if fallback == priority:
        raise ValueError("Fallback must differ from Priority, or be None.")
    result["priority_transport"] = priority
    result["fallback_transport"] = fallback

    local_allow_http = _bool_string(
        data.get("local_allow_insecure_http", result.get("local_allow_insecure_http", "false")),
        "local_allow_insecure_http",
    )
    result["local_allow_insecure_http"] = local_allow_http
    result["local_controller_url"] = _unifi_origin(
        data.get("local_controller_url", result.get("local_controller_url", "https://192.168.1.1:11443")),
        "local_controller_url",
        allow_http=local_allow_http == "true",
    )
    result["local_site_id"] = _plain_text(
        str(data.get("local_site_id", result.get("local_site_id", "auto")) or "auto"),
        "local_site_id",
        max_length=256,
        allow_empty=False,
    ).strip()
    result["local_verify_ssl"] = _bool_string(
        data.get("local_verify_ssl", result.get("local_verify_ssl", "false")),
        "local_verify_ssl",
    )
    result["remote_host_id"] = _plain_text(
        str(data.get("remote_host_id", result.get("remote_host_id", "auto")) or "auto"),
        "remote_host_id",
        max_length=256,
        allow_empty=False,
    ).strip()
    result["remote_site_id"] = _plain_text(
        str(data.get("remote_site_id", result.get("remote_site_id", "auto")) or "auto"),
        "remote_site_id",
        max_length=256,
        allow_empty=False,
    ).strip()

    for key in ("local_api_key", "remote_api_key", "mqtt_password"):
        if key in data and str(data.get(key) or ""):
            result[key] = _plain_text(str(data[key]), key, max_length=4096)

    if "controllers" in data:
        result["controllers"] = _validate_unifi_controller_rows(data["controllers"], current)

    result["poll_interval"] = _bounded_int_string(
        data.get("poll_interval", result.get("poll_interval", "30")),
        "poll_interval",
        10,
        300,
    )
    host = _plain_text(
        str(data.get("mqtt_host", result.get("mqtt_host", ""))),
        "mqtt_host",
        max_length=255,
        allow_empty=False,
    ).strip()
    if any(ch.isspace() for ch in host):
        raise ValueError("mqtt_host cannot contain whitespace.")
    result["mqtt_host"] = host
    result["mqtt_port"] = _bounded_int_string(
        data.get("mqtt_port", result.get("mqtt_port", "1883")),
        "mqtt_port",
        1,
        65535,
    )
    result["mqtt_username"] = _plain_text(
        str(data.get("mqtt_username", result.get("mqtt_username", ""))),
        "mqtt_username",
        max_length=256,
    )
    result["mqtt_tls"] = _bool_string(
        data.get("mqtt_tls", result.get("mqtt_tls", "false")),
        "mqtt_tls",
    )
    result["mqtt_verify_ssl"] = _bool_string(
        data.get("mqtt_verify_ssl", result.get("mqtt_verify_ssl", "true")),
        "mqtt_verify_ssl",
    )
    result["mqtt_ca"] = _plain_text(
        str(data.get("mqtt_ca", result.get("mqtt_ca", ""))),
        "mqtt_ca",
        max_length=512,
    ).strip()
    for key in ("mqtt_topic_prefix", "mqtt_discovery_prefix"):
        value = _plain_text(
            str(data.get(key, result.get(key, ""))),
            key,
            max_length=256,
            allow_empty=False,
        ).strip().strip("/")
        if not value or "+" in value or "#" in value:
            raise ValueError(f"{key} must be a plain MQTT topic prefix without + or # wildcards.")
        result[key] = value
    return result



def _unifi_test_rows(payload: Any, keys: tuple[str, ...]) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if not isinstance(payload, dict):
        return []
    for key in keys:
        value = payload.get(key)
        if isinstance(value, list):
            return [row for row in value if isinstance(row, dict)]
        if isinstance(value, dict):
            for nested in keys:
                nested_value = value.get(nested)
                if isinstance(nested_value, list):
                    return [row for row in nested_value if isinstance(row, dict)]
    data = payload.get("data")
    if isinstance(data, list):
        return [row for row in data if isinstance(row, dict)]
    return []


def _unifi_test_safe_reason(value: Any, *secrets: str) -> str:
    text = str(value or "").strip()
    for secret in secrets:
        if secret:
            text = text.replace(secret, "[redacted]")
    text = sanitize_debug_text(text)
    return _safe_unifi_diagnostic_text(text, max_length=512) or "Unknown connection error"


def _unifi_test_get_json(
    url: str,
    api_key: str,
    *,
    verify_ssl: bool,
    timeout: float = 12.0,
) -> Any:
    request = Request(
        url,
        headers={
            "Accept": "application/json",
            "X-API-Key": api_key,
            "User-Agent": "Switch-Vision-Discovery/UniFi-Test",
        },
        method="GET",
    )
    context = ssl.create_default_context()
    if url.lower().startswith("https://") and not verify_ssl:
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    try:
        with urlopen(request, context=context, timeout=timeout) as response:
            raw = response.read(4 * 1024 * 1024 + 1)
    except HTTPError as exc:
        if exc.code in {401, 403}:
            raise RuntimeError(f"authentication|HTTP {exc.code}: API key was rejected or is not authorized") from exc
        if exc.code == 404:
            raise RuntimeError("api_endpoint|HTTP 404: expected UniFi API endpoint was not found") from exc
        raise RuntimeError(f"api_endpoint|HTTP {exc.code}: UniFi API request failed") from exc
    except URLError as exc:
        reason = exc.reason
        if isinstance(reason, ssl.SSLCertVerificationError):
            raise RuntimeError(f"tls|TLS certificate verification failed: {reason}") from exc
        raise RuntimeError(f"network|Connection failed: {reason}") from exc
    except TimeoutError as exc:
        raise RuntimeError("network|Connection timed out") from exc
    except ssl.SSLError as exc:
        raise RuntimeError(f"tls|TLS negotiation failed: {exc}") from exc
    except OSError as exc:
        raise RuntimeError(f"network|Connection failed: {exc}") from exc
    if len(raw) > 4 * 1024 * 1024:
        raise RuntimeError("api_response|UniFi API response exceeded the 4 MiB safety limit")
    try:
        return json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("api_response|UniFi API returned invalid JSON") from exc


def _unifi_test_select_site(sites: list[dict[str, Any]], requested: Any) -> dict[str, Any]:
    usable = [site for site in sites if str(site.get("id") or "").strip()]
    if not usable:
        raise RuntimeError("site_resolution|UniFi Network API returned no sites")
    requested_text = str(requested or "auto").strip() or "auto"
    key = requested_text.casefold()
    if key in {"auto", "default"}:
        defaults = [
            site for site in usable
            if str(site.get("internalReference") or "").strip().casefold() == "default"
            or str(site.get("name") or "").strip().casefold() == "default"
        ]
        if len(defaults) == 1:
            return defaults[0]
        if len(usable) == 1:
            return usable[0]
        raise RuntimeError(
            "site_resolution|Multiple UniFi Network sites were returned; select the required site ID, internal reference, or exact site name"
        )
    matches = [
        site for site in usable
        if str(site.get("id") or "").strip() == requested_text
        or str(site.get("internalReference") or "").strip().casefold() == key
        or str(site.get("name") or "").strip().casefold() == key
    ]
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise RuntimeError("site_resolution|Configured site did not match any UniFi Network Integration site")
    raise RuntimeError("site_resolution|Configured site matched multiple UniFi Network Integration sites")


def _unifi_test_network_host(row: dict[str, Any]) -> bool:
    if bool(row.get("isBlocked")):
        return False
    kind = str(row.get("type") or "").strip().casefold()
    return kind in {"network-server", "console", "ucore"}


def _unifi2mqtt_current_options() -> tuple[str, dict[str, Any]]:
    status = _unifi2mqtt_settings_status()
    if not status.get("installed") or not status.get("slug"):
        raise RuntimeError("Switch Vision UniFi2MQTT is not installed.")
    slug = str(status["slug"])
    info = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
    info_data = info.get("data") if isinstance(info.get("data"), dict) else info
    stored = info_data.get("options") if isinstance(info_data, dict) else None
    if not isinstance(stored, dict):
        raise RuntimeError("Home Assistant did not expose the current UniFi2MQTT options to the Hub.")
    current = dict(UNIFI2MQTT_DEFAULT_OPTIONS)
    current.update(stored)
    return slug, current


def _test_unifi2mqtt_connection(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("UniFi connection test request must be a JSON object.")
    transport = _unifi_connection_transport(data.get("transport"), "transport")
    _slug, current = _unifi2mqtt_current_options()
    legacy_transport = str(current.get("transport") or "local").strip().lower()
    legacy_key = str(current.get("api_key") or "").strip()
    debug: list[str] = [f"{transport.title()} test: validating profile"]
    if transport == "local":
        allow_http = _bool_string(
            data.get("allow_insecure_http", current.get("local_allow_insecure_http", "false")),
            "local_allow_insecure_http",
        ) == "true"
        controller_url = _unifi_origin(
            data.get("controller_url", current.get("local_controller_url", "https://192.168.1.1:11443")),
            "local_controller_url",
            allow_http=allow_http,
        )
        site_request = _plain_text(
            str(data.get("site_id", current.get("local_site_id", "auto")) or "auto"),
            "local_site_id",
            max_length=256,
            allow_empty=False,
        ).strip()
        api_key = str(data.get("api_key") or "").strip() or str(current.get("local_api_key") or "").strip()
        if not api_key and legacy_transport == "local":
            api_key = legacy_key
        if not api_key:
            raise ValueError("Local Integration API key is not configured.")
        verify_ssl = _bool_string(
            data.get("verify_ssl", current.get("local_verify_ssl", "false")),
            "local_verify_ssl",
        ) == "true"
        base = controller_url
        debug.append(f"Local test: connecting to {controller_url}")
        host_id = ""
    else:
        host_request = _plain_text(
            str(data.get("host_id", current.get("remote_host_id", "auto")) or "auto"),
            "remote_host_id",
            max_length=256,
            allow_empty=False,
        ).strip()
        site_request = _plain_text(
            str(data.get("site_id", current.get("remote_site_id", "auto")) or "auto"),
            "remote_site_id",
            max_length=256,
            allow_empty=False,
        ).strip()
        api_key = str(data.get("api_key") or "").strip() or str(current.get("remote_api_key") or "").strip()
        if not api_key and legacy_transport == "remote":
            api_key = legacy_key
        if not api_key:
            raise ValueError("Remote Site Manager API key is not configured.")
        verify_ssl = True
        debug.append("Remote test: contacting official UniFi Site Manager API")
        try:
            if host_request.casefold() == "auto":
                payload = _unifi_test_get_json(
                    "https://api.ui.com/v1/hosts?pageSize=100",
                    api_key,
                    verify_ssl=True,
                )
                hosts = [row for row in _unifi_test_rows(payload, ("data", "hosts")) if _unifi_test_network_host(row)]
                if len(hosts) == 1:
                    selected_host = hosts[0]
                elif not hosts:
                    raise RuntimeError("host_resolution|Site Manager returned no usable UniFi Network hosts")
                else:
                    raise RuntimeError("host_resolution|Multiple usable UniFi Network hosts were returned; configure Remote host ID")
            else:
                payload = _unifi_test_get_json(
                    "https://api.ui.com/v1/hosts/" + quote(host_request, safe=""),
                    api_key,
                    verify_ssl=True,
                )
                selected_host = payload.get("data") if isinstance(payload, dict) and isinstance(payload.get("data"), dict) else payload
                if not isinstance(selected_host, dict) or str(selected_host.get("id") or "").strip() != host_request:
                    raise RuntimeError("host_resolution|Configured Remote host ID did not match the Site Manager response")
                if not _unifi_test_network_host(selected_host):
                    raise RuntimeError("host_resolution|Configured Remote host is not a usable UniFi Network host")
            host_id = str(selected_host.get("id") or "").strip()
            if not host_id:
                raise RuntimeError("host_resolution|Resolved Site Manager host did not contain an ID")
            debug.append("Remote test: Site Manager host resolved")
        except RuntimeError as exc:
            raw = str(exc)
            stage, sep, reason = raw.partition("|")
            stage = stage if sep else "host_resolution"
            reason = reason if sep else raw
            safe = _unifi_test_safe_reason(reason, api_key)
            debug.append(f"Remote test: FAILED at {stage}: {safe}")
            return {"ok": False, "transport": transport, "stage": stage, "reason": safe, "debug": debug}
        base = "https://api.ui.com/v1/connector/consoles/" + quote(host_id, safe="")

    try:
        debug.append(f"{transport.title()} test: requesting Network Integration sites")
        sites_payload = _unifi_test_get_json(
            base + "/proxy/network/integration/v1/sites",
            api_key,
            verify_ssl=verify_ssl,
        )
        sites = _unifi_test_rows(sites_payload, ("data", "sites"))
        site = _unifi_test_select_site(sites, site_request)
        site_id = str(site.get("id") or "").strip()
        if not site_id:
            raise RuntimeError("site_resolution|Resolved UniFi Network site did not contain an ID")
        site_name = str(site.get("name") or site.get("internalReference") or site_id).strip()[:120]
        debug.append(f"{transport.title()} test: authenticated; site resolved ({site_name})")
        devices_payload = _unifi_test_get_json(
            base + "/proxy/network/integration/v1/sites/" + quote(site_id, safe="") + "/devices",
            api_key,
            verify_ssl=verify_ssl,
        )
        devices = _unifi_test_rows(devices_payload, ("data", "devices"))
        debug.append(f"{transport.title()} test: adopted-device read succeeded ({len(devices)} device(s))")
        debug.append(f"{transport.title()} test: PASS")
        return {
            "ok": True,
            "transport": transport,
            "stage": "complete",
            "reason": "Connection test passed",
            "host_id": host_id if transport == "remote" else "",
            "site_id": site_id,
            "site_name": site_name,
            "device_count": len(devices),
            "debug": debug,
        }
    except RuntimeError as exc:
        raw = str(exc)
        stage, sep, reason = raw.partition("|")
        stage = stage if sep else "network_api"
        reason = reason if sep else raw
        safe = _unifi_test_safe_reason(reason, api_key)
        debug.append(f"{transport.title()} test: FAILED at {stage}: {safe}")
        return {"ok": False, "transport": transport, "stage": stage, "reason": safe, "debug": debug}

def _save_unifi2mqtt_settings(data: Any) -> dict[str, Any]:
    status = _unifi2mqtt_settings_status()
    if not status.get("installed") or not status.get("slug"):
        raise RuntimeError("Switch Vision UniFi2MQTT is not installed.")
    slug = str(status["slug"])
    info = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
    info_data = info.get("data") if isinstance(info.get("data"), dict) else info
    current = dict(UNIFI2MQTT_DEFAULT_OPTIONS)
    stored_options = info_data.get("options") if isinstance(info_data, dict) else None
    if not isinstance(stored_options, dict):
        raise RuntimeError(
            "Home Assistant did not expose the current UniFi2MQTT options to the Hub. "
            "To protect stored secrets, use the Home Assistant App configuration fallback for this change."
        )
    current.update(stored_options)
    merged = _validate_unifi2mqtt_options(data, current)
    _supervisor_json(
        f"/addons/{quote(slug, safe='')}/options",
        method="POST",
        timeout=20.0,
        payload={"options": merged},
    )
    state = str((info_data or {}).get("state") or "") if isinstance(info_data, dict) else ""
    restarted = False
    started = False
    if state in {"started", "running"}:
        _supervisor_json(
            f"/addons/{quote(slug, safe='')}/restart",
            method="POST",
            timeout=30.0,
        )
        restarted = True
    elif state == "stopped":
        _supervisor_json(
            f"/addons/{quote(slug, safe='')}/start",
            method="POST",
            timeout=30.0,
        )
        started = True
    _clear_configuration_restore_pending("unifi_controllers")
    result = _unifi2mqtt_settings_status()
    result["saved"] = True
    result["restarted"] = restarted
    result["started"] = started
    return result



_INSTALLER_BACKUP_OPTION_KEYS = {
    "release_api_url",
    "allow_custom_release_source",
    "release_asset_pattern",
    "preserve_custom_assets",
    "create_backup",
    "allow_prerelease",
    "backup_retention",
}


def _load_configuration_restore_pending() -> dict[str, Any]:
    payload = _read_json(DEFAULT_CONFIGURATION_RESTORE_PENDING)
    if not isinstance(payload, dict) or payload.get("schema_version") != 1:
        return {
            "schema_version": 1,
            "discovery_switches": [],
            "discovery_stack_member_prefixes": [],
            "unifi_controllers": [],
        }
    switches = payload.get("discovery_switches")
    stack_members = payload.get("discovery_stack_member_prefixes")
    controllers = payload.get("unifi_controllers")
    return {
        "schema_version": 1,
        "discovery_switches": [dict(row) for row in switches if isinstance(row, dict)] if isinstance(switches, list) else [],
        "discovery_stack_member_prefixes": [dict(row) for row in stack_members if isinstance(row, dict)] if isinstance(stack_members, list) else [],
        "unifi_controllers": [dict(row) for row in controllers if isinstance(row, dict)] if isinstance(controllers, list) else [],
    }


def _save_configuration_restore_pending(payload: dict[str, Any]) -> None:
    normalized = {
        "schema_version": 1,
        "discovery_switches": [dict(row) for row in payload.get("discovery_switches", []) if isinstance(row, dict)],
        "discovery_stack_member_prefixes": [dict(row) for row in payload.get("discovery_stack_member_prefixes", []) if isinstance(row, dict)],
        "unifi_controllers": [dict(row) for row in payload.get("unifi_controllers", []) if isinstance(row, dict)],
    }
    if (
        not normalized["discovery_switches"]
        and not normalized["discovery_stack_member_prefixes"]
        and not normalized["unifi_controllers"]
    ):
        try:
            DEFAULT_CONFIGURATION_RESTORE_PENDING.unlink(missing_ok=True)
        except OSError:
            pass
        return
    DEFAULT_CONFIGURATION_RESTORE_PENDING.parent.mkdir(parents=True, exist_ok=True)
    temporary = DEFAULT_CONFIGURATION_RESTORE_PENDING.with_name(
        f".{DEFAULT_CONFIGURATION_RESTORE_PENDING.name}.{os.getpid()}.tmp"
    )
    try:
        temporary.write_text(json.dumps(normalized, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.chmod(temporary, 0o644)
        os.replace(temporary, DEFAULT_CONFIGURATION_RESTORE_PENDING)
        os.chmod(DEFAULT_CONFIGURATION_RESTORE_PENDING, 0o644)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def _clear_configuration_restore_pending(section: str) -> None:
    pending = _load_configuration_restore_pending()
    if section == "discovery_switches":
        pending["discovery_switches"] = []
    elif section == "discovery_stack_member_prefixes":
        pending["discovery_stack_member_prefixes"] = []
    elif section == "unifi_controllers":
        pending["unifi_controllers"] = []
    else:
        raise ValueError("Unknown pending restore section.")
    _save_configuration_restore_pending(pending)


def _installer_settings_status() -> dict[str, Any]:
    links = _installed_switch_vision_app_links()
    item = links.get("installer") if isinstance(links, dict) else None
    if not isinstance(item, dict) or not item.get("found") or not item.get("slug"):
        return {"installed": False, "settings": None}
    slug = str(item["slug"])
    payload = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
    info = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    options = info.get("options") if isinstance(info, dict) else None
    if not isinstance(options, dict):
        raise RuntimeError("Home Assistant did not expose Switch Vision Installer options.")
    return {
        "installed": True,
        "slug": slug,
        "state": str(info.get("state") or "unknown") if isinstance(info, dict) else "unknown",
        "settings": {key: copy.deepcopy(options[key]) for key in _INSTALLER_BACKUP_OPTION_KEYS if key in options},
    }


def _save_installer_settings(settings: Any) -> dict[str, Any]:
    if not isinstance(settings, dict):
        raise ValueError("Installer backup settings must contain an object.")
    unknown = sorted(set(settings) - _INSTALLER_BACKUP_OPTION_KEYS)
    if unknown:
        raise ValueError(f"Unsupported Installer backup setting: {unknown[0]}")
    status = _installer_settings_status()
    if not status.get("installed") or not status.get("slug"):
        raise RuntimeError("Switch Vision Installer is not installed.")
    slug = str(status["slug"])
    info_payload = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
    info = info_payload.get("data") if isinstance(info_payload.get("data"), dict) else info_payload
    current = dict(info.get("options") or {}) if isinstance(info, dict) and isinstance(info.get("options"), dict) else {}
    updated = dict(current)
    for key, value in settings.items():
        if key in {"allow_custom_release_source", "preserve_custom_assets", "create_backup", "allow_prerelease"}:
            if type(value) is not bool:
                raise ValueError(f"Installer setting {key} must be true or false.")
            updated[key] = value
        elif key == "backup_retention":
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 10:
                raise ValueError("Installer backup_retention must be between 1 and 10.")
            updated[key] = value
        elif key == "release_api_url":
            text = _plain_text(value, key, max_length=2048, allow_empty=False).strip()
            if not text.startswith(("https://", "http://")):
                raise ValueError("Installer release_api_url must be an HTTP or HTTPS URL.")
            updated[key] = text
        elif key == "release_asset_pattern":
            updated[key] = _plain_text(value, key, max_length=256, allow_empty=False).strip()
    if updated != current:
        _supervisor_json(
            f"/addons/{quote(slug, safe='')}/options",
            method="POST",
            timeout=20.0,
            payload={"options": updated},
        )
    return _installer_settings_status()


def _calibration_profile_management_view(result: dict[str, Any]) -> dict[str, Any]:
    """Annotate Core calibration metadata with safe deletion eligibility."""
    view = copy.deepcopy(result)
    items = view.get("items")
    active_profiles = view.get("active_profiles")
    if not isinstance(items, list):
        return view
    if not isinstance(active_profiles, dict):
        active_profiles = {}

    active_bases = {
        str(base or "").strip()
        for base in active_profiles
        if str(base or "").strip()
    }
    active_targets = {
        str(profile or "").strip()
        for profile in active_profiles.values()
        if str(profile or "").strip()
    }

    for item in items:
        if not isinstance(item, dict):
            continue
        profile = str(item.get("profile") or "").strip()
        scope = str(item.get("scope") or "").strip().lower()
        reason = ""
        if scope == "factory":
            reason = "factory"
        elif item.get("active") is True or profile in active_targets:
            reason = "active"
        elif profile in active_bases:
            reason = "active_base"

        item["deletion_protected"] = bool(reason)
        item["deletion_protection_reason"] = reason

    return view


def _core_calibration_backup() -> dict[str, Any]:
    listing = _home_assistant_ws({"type": "switch_vision/list_calibrations"})
    if not isinstance(listing, dict):
        raise RuntimeError("Switch Vision Core did not return calibration metadata.")
    items = listing.get("items")
    if not isinstance(items, list):
        raise RuntimeError("Switch Vision Core calibration metadata is invalid.")
    profiles: list[dict[str, Any]] = []
    active_profiles: dict[str, str] = {}
    for item in items:
        if not isinstance(item, dict) or str(item.get("scope") or "") == "factory":
            continue
        profile = _calibration_profile_name(item.get("profile"))
        detail = _home_assistant_ws(
            {"type": "switch_vision/get_calibration", "profile": profile, "exact": True}
        )
        if not isinstance(detail, dict) or detail.get("exists") is not True or not isinstance(detail.get("calibration"), dict):
            raise RuntimeError(f"Switch Vision Core could not export calibration profile {profile!r}.")
        calibration = copy.deepcopy(detail["calibration"])
        encoded = json.dumps(calibration, ensure_ascii=False).encode("utf-8")
        if len(encoded) > 2 * 1024 * 1024:
            raise RuntimeError(f"Calibration profile {profile!r} exceeds the backup size limit.")
        profiles.append({"profile": profile, "calibration": calibration})
        base = str(item.get("base_profile") or "").strip()
        if item.get("active") is True and base and base != profile:
            active_profiles[base] = profile
    return {"profiles": profiles, "active_profiles": active_profiles}


def _core_asset_backup() -> list[dict[str, Any]]:
    listing = _home_assistant_ws({"type": "switch_vision/list_assets"})
    if not isinstance(listing, dict):
        raise RuntimeError("Switch Vision Core did not return asset metadata.")
    if int(listing.get("backup_api") or 0) < 2:
        raise RuntimeError("Switch Vision Core is too old for complete configuration backup. Update Core before exporting.")
    result: list[dict[str, Any]] = []
    for kind in ("logos", "faceplates"):
        names = listing.get(f"custom_{kind}")
        if not isinstance(names, list):
            raise RuntimeError(f"Switch Vision Core custom asset list for {kind} is invalid.")
        for raw_name in names:
            name = str(raw_name or "").strip()
            if not name:
                continue
            asset = _home_assistant_ws(
                {"type": "switch_vision/get_backup_asset", "kind": kind, "filename": name},
                max_size=32 * 1024 * 1024,
            )
            if not isinstance(asset, dict):
                raise RuntimeError(f"Switch Vision Core could not export asset {kind}/{name}.")
            result.append({
                "kind": kind,
                "filename": name,
                "size": int(asset.get("size") or 0),
                "sha256": str(asset.get("sha256") or ""),
                "content_base64": str(asset.get("content_base64") or ""),
            })
    return result


def _backup_credential_requirements(
    discovery: dict[str, Any], snmp2mqtt: dict[str, Any], unifi2mqtt: dict[str, Any]
) -> list[dict[str, str]]:
    requirements: list[dict[str, str]] = []
    settings = discovery.get("settings") if isinstance(discovery, dict) else None
    switches = settings.get("switches") if isinstance(settings, dict) else None
    if isinstance(switches, list):
        for row in switches:
            if not isinstance(row, dict) or not row.get("snmp_community_configured"):
                continue
            identifier = str(row.get("switch_name") or row.get("display_name") or "switch").strip()
            requirements.append({"component": "discovery", "kind": "snmp_community", "identifier": identifier})
    if isinstance(settings, dict) and settings.get("support_contributor_value_configured"):
        requirements.append({"component": "discovery", "kind": "private_contributor_value", "identifier": "Support My Switch recognition"})
    if isinstance(snmp2mqtt, dict) and snmp2mqtt.get("password_configured"):
        requirements.append({"component": "snmp2mqtt", "kind": "mqtt_password", "identifier": "MQTT"})
    if isinstance(unifi2mqtt, dict):
        for key, kind, label in (
            ("local_api_key_configured", "api_key", "Local controller"),
            ("remote_api_key_configured", "api_key", "Remote / Site Manager"),
            ("mqtt_password_configured", "mqtt_password", "MQTT"),
        ):
            if unifi2mqtt.get(key):
                requirements.append({"component": "unifi2mqtt", "kind": kind, "identifier": label})
        options = unifi2mqtt.get("options")
        controllers = options.get("controllers") if isinstance(options, dict) else None
        if isinstance(controllers, list):
            for row in controllers:
                if isinstance(row, dict) and row.get("api_key_configured"):
                    requirements.append({
                        "component": "unifi2mqtt",
                        "kind": "controller_api_key",
                        "identifier": str(row.get("id") or "controller"),
                    })
    return requirements


def _switch_vision_backup_export(version: str) -> dict[str, Any]:
    core = _core_settings_status()
    discovery = _discovery_settings_status()
    snmp2mqtt = _snmp2mqtt_settings_status()
    unifi2mqtt = _unifi2mqtt_settings_status()
    installer = _installer_settings_status()
    # Snapshotting configured devices establishes any missing immutable added_at
    # migration metadata before the control state is captured.
    _configured_devices_snapshot(DEFAULT_OPTIONS_FILE)
    control = device_control_state.load(DEFAULT_DEVICE_CONTROL)
    payload = {
        "format": COMPLETE_BACKUP_FORMAT,
        "schema_version": COMPLETE_BACKUP_SCHEMA_VERSION,
        "switch_vision_discovery_version": version,
        "exported_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "secrets_included": False,
        "secret_policy": {
            "snmp_communities": "excluded",
            "mqtt_passwords": "excluded",
            "unifi_api_keys": "excluded",
            "tokens_and_passwords": "excluded",
            "support_contributor_value": "excluded_private_value",
        },
        "components": {
            "core": {"settings": copy.deepcopy(core.get("settings"))},
            "discovery": {"settings": copy.deepcopy(discovery.get("settings"))},
            "snmp2mqtt": {
                "installed": bool(snmp2mqtt.get("installed")),
                "settings": copy.deepcopy(snmp2mqtt.get("settings")),
            },
            "unifi2mqtt": {
                "installed": bool(unifi2mqtt.get("installed")),
                "options": copy.deepcopy(unifi2mqtt.get("options")),
            },
            "installer": {
                "installed": bool(installer.get("installed")),
                "settings": copy.deepcopy(installer.get("settings")),
            },
        },
        "device_control": copy.deepcopy(control),
        "calibrations": _core_calibration_backup(),
        "assets": _core_asset_backup(),
        "credential_requirements": _backup_credential_requirements(discovery, snmp2mqtt, unifi2mqtt),
    }
    _validate_complete_backup(payload)
    return payload


def _validate_complete_backup(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict) or data.get("format") != COMPLETE_BACKUP_FORMAT:
        raise ValueError("This is not a supported complete Switch Vision backup.")
    if data.get("schema_version") != COMPLETE_BACKUP_SCHEMA_VERSION:
        raise ValueError("Unsupported complete Switch Vision backup schema version.")
    if data.get("secrets_included") is not False:
        raise ValueError("Complete Switch Vision backups must not contain secrets.")
    components = data.get("components")
    if not isinstance(components, dict):
        raise ValueError("Complete backup components are missing.")
    for required in ("core", "discovery", "snmp2mqtt", "unifi2mqtt", "installer"):
        if not isinstance(components.get(required), dict):
            raise ValueError(f"Complete backup component {required!r} is missing.")

    discovery_settings = components["discovery"].get("settings")
    if not isinstance(discovery_settings, dict):
        raise ValueError("Complete backup Discovery settings are invalid.")
    if str(discovery_settings.get("support_contributor_value") or ""):
        raise ValueError("Complete backup contains a private Support My Switch value.")
    switches = discovery_settings.get("switches")
    if not isinstance(switches, list) or len(switches) > 256:
        raise ValueError("Complete backup Discovery switch list is invalid.")
    for row in switches:
        if not isinstance(row, dict) or str(row.get("snmp_community") or ""):
            raise ValueError("Complete backup must not contain SNMP community strings.")
    stack_members = discovery_settings.get("stack_member_prefixes")
    if not isinstance(stack_members, list) or len(stack_members) > 512:
        raise ValueError("Complete backup Discovery stack member list is invalid.")
    for index, row in enumerate(stack_members, start=1):
        _validate_stack_row(row, index)
    # Validate parent/member relationships before any restore side effect.  A
    # portable backup may omit secrets, but its inventory identities must
    # still be internally coherent.
    _validate_inventory_identities(discovery_settings)

    snmp_settings = components["snmp2mqtt"].get("settings")
    if snmp_settings is not None:
        if not isinstance(snmp_settings, dict):
            raise ValueError("Complete backup SNMP2MQTT settings are invalid.")
        mqtt = snmp_settings.get("mqtt")
        if isinstance(mqtt, dict) and str(mqtt.get("password") or ""):
            raise ValueError("Complete backup must not contain MQTT passwords.")

    unifi_options = components["unifi2mqtt"].get("options")
    if unifi_options is not None:
        if not isinstance(unifi_options, dict):
            raise ValueError("Complete backup UniFi2MQTT options are invalid.")
        for key in UNIFI2MQTT_SECRET_FIELDS:
            if str(unifi_options.get(key) or ""):
                raise ValueError("Complete backup must not contain UniFi/MQTT secrets.")
        controllers = unifi_options.get("controllers")
        if controllers is not None:
            if not isinstance(controllers, list) or len(controllers) > 32:
                raise ValueError("Complete backup UniFi controller list is invalid.")
            for row in controllers:
                if not isinstance(row, dict) or str(row.get("api_key") or ""):
                    raise ValueError("Complete backup must not contain controller API keys.")

    calibrations = data.get("calibrations")
    if not isinstance(calibrations, dict):
        raise ValueError("Complete backup calibration data is invalid.")
    profiles = calibrations.get("profiles")
    if not isinstance(profiles, list) or len(profiles) > 2048:
        raise ValueError("Complete backup calibration profile list is invalid.")
    for row in profiles:
        if not isinstance(row, dict) or not isinstance(row.get("calibration"), dict):
            raise ValueError("Complete backup contains an invalid calibration profile.")
        _calibration_profile_name(row.get("profile"))
        if len(json.dumps(row["calibration"], ensure_ascii=False).encode("utf-8")) > 2 * 1024 * 1024:
            raise ValueError("Complete backup contains an oversized calibration profile.")
    active_profiles = calibrations.get("active_profiles")
    if not isinstance(active_profiles, dict):
        raise ValueError("Complete backup active calibration map is invalid.")

    assets = data.get("assets")
    if not isinstance(assets, list) or len(assets) > 2048:
        raise ValueError("Complete backup asset list is invalid.")
    for asset in assets:
        if not isinstance(asset, dict):
            raise ValueError("Complete backup contains an invalid asset.")
        if str(asset.get("kind") or "") not in {"logos", "faceplates"}:
            raise ValueError("Complete backup contains an unsupported asset kind.")
        name = str(asset.get("filename") or "")
        if not name or name != Path(name).name or name.startswith("."):
            raise ValueError("Complete backup contains an invalid asset filename.")
        digest = str(asset.get("sha256") or "")
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError("Complete backup contains an invalid asset digest.")
        content = asset.get("content_base64")
        if not isinstance(content, str) or len(content) > 24 * 1024 * 1024:
            raise ValueError("Complete backup contains an invalid or oversized asset payload.")
        try:
            raw_asset = base64.b64decode(content.encode("ascii"), validate=True)
        except (UnicodeEncodeError, binascii.Error, ValueError) as exc:
            raise ValueError("Complete backup contains invalid base64 asset content.") from exc
        if len(raw_asset) > MAX_COMPLETE_BACKUP_ASSET_BYTES:
            raise ValueError("Complete backup contains an asset above the 16 MiB restore limit.")
        if int(asset.get("size") or -1) != len(raw_asset):
            raise ValueError("Complete backup asset size does not match its manifest.")
        if hashlib.sha256(raw_asset).hexdigest() != digest:
            raise ValueError("Complete backup asset SHA-256 does not match its content.")

    control = data.get("device_control")
    if not isinstance(control, dict):
        raise ValueError("Complete backup device-control state is invalid.")
    device_control_state.load_from_object(control)
    return copy.deepcopy(data)


def _restore_core_calibrations(calibrations: dict[str, Any]) -> int:
    profiles = calibrations.get("profiles") if isinstance(calibrations, dict) else None
    if not isinstance(profiles, list):
        raise ValueError("Calibration restore payload is invalid.")
    by_name: dict[str, dict[str, Any]] = {}
    restored = 0
    for row in profiles:
        profile = _calibration_profile_name(row.get("profile"))
        calibration = row.get("calibration")
        if not isinstance(calibration, dict):
            raise ValueError(f"Calibration profile {profile!r} is invalid.")
        by_name[profile] = copy.deepcopy(calibration)
        _home_assistant_service(
            "switch_vision",
            "save_calibration",
            {"profile": profile, "calibration": calibration, "mirror_to_base": False},
        )
        restored += 1
    active = calibrations.get("active_profiles")
    if isinstance(active, dict):
        for base, profile_value in active.items():
            base_name = _calibration_profile_name(base)
            profile = _calibration_profile_name(profile_value)
            calibration = by_name.get(profile)
            if calibration is None:
                raise ValueError(f"Active calibration {profile!r} is missing from the backup.")
            if not profile.startswith(f"{base_name}__faceplate__"):
                raise ValueError("Active calibration map does not match its base profile.")
            _home_assistant_service(
                "switch_vision",
                "save_calibration",
                {"profile": profile, "calibration": calibration, "mirror_to_base": True},
            )
    return restored


def _restore_core_assets(assets: list[dict[str, Any]]) -> int:
    restored = 0
    for asset in assets:
        result = _home_assistant_ws(
            {
                "type": "switch_vision/put_backup_asset",
                "kind": asset["kind"],
                "filename": asset["filename"],
                "sha256": asset["sha256"],
                "content_base64": asset["content_base64"],
            },
            max_size=32 * 1024 * 1024,
        )
        if not isinstance(result, dict) or str(result.get("sha256") or "") != asset["sha256"]:
            raise RuntimeError(f"Switch Vision Core did not confirm restored asset {asset['filename']!r}.")
        restored += 1
    return restored


def _restore_unifi2mqtt_nonsecret(options: dict[str, Any]) -> None:
    status = _unifi2mqtt_settings_status()
    if not status.get("installed") or not status.get("slug"):
        raise RuntimeError("Switch Vision UniFi2MQTT is not installed.")
    slug = str(status["slug"])
    info_payload = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
    info = info_payload.get("data") if isinstance(info_payload.get("data"), dict) else info_payload
    stored = info.get("options") if isinstance(info, dict) else None
    if not isinstance(stored, dict):
        raise RuntimeError("Home Assistant did not expose current UniFi2MQTT options.")
    safe = {key: copy.deepcopy(value) for key, value in options.items() if key not in UNIFI2MQTT_SECRET_FIELDS and key != "controllers"}
    updated = _validate_unifi2mqtt_options(safe, dict(stored))
    if updated != stored:
        _supervisor_json(
            f"/addons/{quote(slug, safe='')}/options",
            method="POST",
            timeout=20.0,
            payload={"options": updated},
        )


def _restore_complete_backup(data: Any) -> dict[str, Any]:
    backup = _validate_complete_backup(data)
    # Preflight the coordinated Core contract before changing any component.
    core_assets = _home_assistant_ws({"type": "switch_vision/list_assets"})
    if not isinstance(core_assets, dict) or int(core_assets.get("backup_api") or 0) < 2:
        raise RuntimeError("Switch Vision Core is too old for complete configuration restore. Update Core before importing.")
    components = backup["components"]
    restored_components: list[str] = []
    warnings: list[str] = []

    core_settings = components["core"].get("settings")
    if isinstance(core_settings, dict):
        _save_core_settings({"settings": core_settings})
        restored_components.append("core")
    asset_count = _restore_core_assets(backup["assets"])
    profile_count = _restore_core_calibrations(backup["calibrations"])

    installer_settings = components["installer"].get("settings")
    if components["installer"].get("installed") and isinstance(installer_settings, dict):
        try:
            _save_installer_settings(installer_settings)
            restored_components.append("installer")
        except RuntimeError as exc:
            warnings.append(str(exc))

    snmp_settings = components["snmp2mqtt"].get("settings")
    if components["snmp2mqtt"].get("installed") and isinstance(snmp_settings, dict):
        try:
            safe_snmp = copy.deepcopy(snmp_settings)
            if isinstance(safe_snmp.get("mqtt"), dict):
                safe_snmp["mqtt"]["password"] = ""
            safe_snmp["clear_password"] = False
            _save_snmp2mqtt_settings({"settings": safe_snmp})
            restored_components.append("snmp2mqtt")
        except RuntimeError as exc:
            warnings.append(str(exc))

    pending = _load_configuration_restore_pending()
    unifi_options = components["unifi2mqtt"].get("options")
    if components["unifi2mqtt"].get("installed") and isinstance(unifi_options, dict):
        controllers = unifi_options.get("controllers")
        pending["unifi_controllers"] = [
            {key: copy.deepcopy(value) for key, value in row.items() if key not in {"api_key", "api_key_configured"}}
            | {"api_key_configured": False, "restore_pending": True}
            for row in controllers if isinstance(row, dict)
        ] if isinstance(controllers, list) else []
        try:
            _restore_unifi2mqtt_nonsecret(unifi_options)
            restored_components.append("unifi2mqtt")
        except RuntimeError as exc:
            warnings.append(str(exc))

    discovery_settings = copy.deepcopy(components["discovery"].get("settings"))
    if not isinstance(discovery_settings, dict):
        raise ValueError("Complete backup Discovery settings are invalid.")
    switches = discovery_settings.pop("switches", [])
    stack_members = discovery_settings.pop("stack_member_prefixes", [])
    discovery_settings.pop("support_contributor_value_configured", None)
    contributor_was_configured = bool(
        components["discovery"].get("settings", {}).get("support_contributor_value_configured")
    )
    discovery_settings["support_contributor_value"] = ""
    if contributor_was_configured and str(discovery_settings.get("support_contributor_type") or "anonymous") != "anonymous":
        # Existing write-only privacy policy does not permit a backup to recreate
        # this private value. Preserve current live recognition until re-entered.
        discovery_settings.pop("support_contributor_type", None)
        discovery_settings.pop("support_contributor_value", None)
    _save_discovery_settings({"settings": discovery_settings})
    restored_components.append("discovery")
    pending["discovery_switches"] = [
        {key: copy.deepcopy(value) for key, value in row.items() if key not in {"snmp_community", "snmp_community_configured", "original_switch_name"}}
        | {"snmp_community": "", "snmp_community_configured": False, "restore_pending": True}
        for row in switches
        if isinstance(row, dict) and (str(row.get("switch_name") or "").strip() or str(row.get("switch_host") or "").strip())
    ]
    pending["discovery_stack_member_prefixes"] = [
        copy.deepcopy(row)
        for row in stack_members
        if isinstance(row, dict)
    ]
    _save_configuration_restore_pending(pending)

    control = device_control_state.load_from_object(backup["device_control"])
    device_control_state.save(control, DEFAULT_DEVICE_CONTROL)

    return {
        "imported": True,
        "format": COMPLETE_BACKUP_FORMAT,
        "restored_components": restored_components,
        "asset_count": asset_count,
        "calibration_profile_count": profile_count,
        "credential_requirements": copy.deepcopy(backup.get("credential_requirements") or []),
        "pending_discovery_switches": len(pending["discovery_switches"]),
        "pending_discovery_stack_members": len(pending["discovery_stack_member_prefixes"]),
        "pending_unifi_controllers": len(pending["unifi_controllers"]),
        "warnings": warnings,
        "restart_required": False,
    }


def _install_unifi2mqtt() -> dict[str, Any]:
    status = _unifi2mqtt_settings_status()
    if status.get("installed"):
        return status
    addon = _find_unifi2mqtt_addon(include_store=True)
    if addon is None or not addon.get("slug"):
        raise RuntimeError(
            "Switch Vision UniFi2MQTT is not available in the Home Assistant app store yet. "
            "Open Switch Vision Installer and install UniFi2MQTT, then reload the App Store and try again."
        )
    slug = str(addon["slug"])
    _supervisor_json(
        f"/store/addons/{quote(slug, safe='')}/install",
        method="POST",
        timeout=120.0,
        payload={"background": False},
    )
    return _unifi2mqtt_settings_status()


def _installed_switch_vision_app_links() -> dict[str, Any]:
    """Resolve installed Switch Vision app routes without hard-coded repository hashes."""
    links: dict[str, Any] = {
        "discovery": {"found": False, "slug": None, "config_url": None},
        "snmp2mqtt": {"found": False, "slug": None, "config_url": None},
        "unifi2mqtt": {"found": False, "available": False, "slug": None, "config_url": None},
        "installer": {"found": False, "slug": None, "ingress_url": None},
    }
    try:
        payload = _supervisor_json("/addons")
        data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
        addons = data.get("addons", []) if isinstance(data, dict) else []
        for addon in addons if isinstance(addons, list) else []:
            if not isinstance(addon, dict):
                continue
            slug = str(addon.get("slug") or "").strip()
            if not slug:
                continue
            normalized = slug.lower().replace("-", "_")
            name = str(addon.get("name") or "").lower().replace("-", "_")
            haystack = f"{normalized} {name}"
            if (
                normalized.endswith("switch_vision_discovery")
                or ("switch_vision" in haystack and "discovery" in haystack)
            ):
                links["discovery"] = {
                    "found": True,
                    "slug": slug,
                    "config_url": f"/config/app/{quote(slug, safe='')}/config",
                }
            if (
                normalized.endswith("switch_vision_snmp2mqtt")
                or normalized.endswith("switch_vision_snmp2mqtt_addon")
                or ("switch_vision" in haystack and "snmp2mqtt" in haystack and "discovery" not in haystack)
            ):
                links["snmp2mqtt"] = {
                    "found": True,
                    "slug": slug,
                    "config_url": f"/config/app/{quote(slug, safe='')}/config",
                }
            if normalized.endswith("switch_vision_installer") or (
                "switch_vision" in haystack and "installer" in haystack
            ):
                links["installer"] = {
                    "found": True,
                    "slug": slug,
                    "ingress_url": f"/app/{quote(slug, safe='')}",
                }
    except RuntimeError as exc:
        links["error"] = str(exc)
    try:
        unifi = _unifi2mqtt_settings_status()
        links["unifi2mqtt"] = {
            "found": bool(unifi.get("installed")),
            "available": bool(unifi.get("available")),
            "slug": unifi.get("slug"),
            "config_url": unifi.get("config_url"),
            "state": unifi.get("state"),
        }
    except RuntimeError as exc:
        links["unifi2mqtt"]["error"] = str(exc)
    return links


def _snmp2mqtt_handoff_mode(runtime: dict[str, Any]) -> tuple[str, str | None]:
    """Return the generated/manual handoff mode without exposing credentials."""
    if not runtime.get("wrapper_options_readable"):
        return "unknown", None
    configured = runtime.get("use_switch_vision_generated_yaml")
    if configured is False:
        return (
            "manual",
            "Switch Vision SNMP2MQTT is configured for manual targets. "
            "Discovery generated a new YAML file but will not override deliberate manual mode. "
            "Enable Use Switch Vision generated YAML in the SNMP2MQTT app configuration, then run Discovery again.",
        )
    generated_path = str(
        runtime.get("switch_vision_generated_yaml_path")
        or DEFAULT_GENERATED_SNMP2MQTT
    ).strip()
    if Path(generated_path) != DEFAULT_GENERATED_SNMP2MQTT:
        return (
            "generated_path_mismatch",
            "Switch Vision SNMP2MQTT is configured to read generated YAML from a different path. "
            f"Set its generated YAML path to {DEFAULT_GENERATED_SNMP2MQTT}, then run Discovery again.",
        )
    return ("generated" if configured is True else "generated_default"), None


def _verify_snmp2mqtt_activation(
    lines: list[str],
    *,
    attempts: int = 3,
    retry_delay: float = 2.0,
) -> dict[str, Any]:
    """Prove the generated MQTT discovery identity set is retained and current."""
    last = {
        "activation_verified": False,
        "mqtt_current_expected": None,
        "mqtt_current_retained": None,
        "mqtt_current_missing": None,
        "mqtt_stale_count": None,
        "verification_status": "unavailable",
    }
    for attempt in range(1, max(1, attempts) + 1):
        if attempt > 1 and retry_delay > 0:
            time.sleep(retry_delay)
        try:
            scan = scan_mqtt_entities()
        except Exception as exc:
            lines.append(
                f"SNMP2MQTT activation verification attempt {attempt} unavailable: "
                f"{type(exc).__name__}."
            )
            continue
        if not isinstance(scan, dict):
            lines.append(
                f"SNMP2MQTT activation verification attempt {attempt} returned invalid data."
            )
            continue

        def safe_count(key: str) -> int | None:
            value = scan.get(key)
            return value if isinstance(value, int) and not isinstance(value, bool) and value >= 0 else None

        expected = safe_count("current_expected_count")
        retained = safe_count("current_retained_count")
        missing = safe_count("current_missing_retained_count")
        stale = safe_count("stale_count")
        last = {
            "activation_verified": bool(
                expected is not None
                and expected > 0
                and retained == expected
                and missing == 0
            ),
            "mqtt_current_expected": expected,
            "mqtt_current_retained": retained,
            "mqtt_current_missing": missing,
            "mqtt_stale_count": stale,
            "verification_status": "verified" if (
                expected is not None
                and expected > 0
                and retained == expected
                and missing == 0
            ) else "incomplete",
        }
        if last["activation_verified"]:
            lines.append(
                "SNMP2MQTT activation verified from retained MQTT discovery counts: "
                f"{retained}/{expected} current."
            )
            return last
        lines.append(
            "SNMP2MQTT activation verification incomplete: "
            f"{retained if retained is not None else 'unknown'}/"
            f"{expected if expected is not None else 'unknown'} current; "
            f"missing {missing if missing is not None else 'unknown'}."
        )
    return last


def _verify_snmp2mqtt_generated_config_loaded(
    lines: list[str], runtime: dict[str, Any]
) -> bool:
    generation_id = generated_yaml_generation_id(DEFAULT_GENERATED_SNMP2MQTT)
    base_topic = str(runtime.get("base_topic") or "").strip().strip("/")
    if not generation_id:
        lines.append("SNMP2MQTT exact-load verification unavailable: generated YAML has no generation ID.")
        return False
    # The HA app can reach Supervisor's running state before its retained
    # runtime config marker is visible on MQTT. Give that asynchronous
    # publication a small bounded window instead of recording a false handoff
    # warning immediately after a clean start/restart.
    attempts = 6
    for attempt in range(attempts):
        try:
            verified = verify_generated_yaml_loaded(base_topic, generation_id)
        except Exception as exc:
            lines.append(f"SNMP2MQTT exact-load verification unavailable: {type(exc).__name__}.")
            return False
        if verified:
            lines.append(
                "SNMP2MQTT exact generated configuration load verified"
                + (f" after {attempt + 1} checks." if attempt else ".")
            )
            return True
        if attempt + 1 < attempts:
            time.sleep(1.0)
    lines.append("SNMP2MQTT exact generated configuration load was not verified after the bounded retry window.")
    return False


def _ensure_snmp2mqtt_running(
    lines: list[str],
    previous_mtime: float | None,
    previous_topics: list[str] | None = None,
) -> dict[str, Any]:
    if not DEFAULT_GENERATED_SNMP2MQTT.is_file():
        # If Discovery retired a previously generated YAML, stop the bridge and
        # retire exactly the retained HA MQTT Discovery configs we recorded
        # before the shell removed the active file.
        if previous_mtime is not None:
            runtime = _snmp2mqtt_runtime_info()
            stopped = False
            try:
                stopped = _stop_snmp2mqtt_for_reset(runtime)
            except RuntimeError as exc:
                message = f"Generated SNMP2MQTT YAML was retired, but Switch Vision could not stop SNMP2MQTT: {exc}"
                lines.append(message)
                return {"status": "Warning", "action": "stop_failed", "slug": runtime.get("slug"), "state": runtime.get("state"), "message": message}

            topics = sorted(set(previous_topics or _load_snmp2mqtt_retirement_topics()))
            mqtt_cleared = 0
            mqtt_warnings: list[str] = []
            if topics:
                mqtt_cleared, mqtt_warnings = _clear_retained_snmp2mqtt_discovery(topics)
                if mqtt_cleared == len(topics) and not mqtt_warnings:
                    _save_snmp2mqtt_retirement_topics([])
            if mqtt_warnings:
                lines.extend(mqtt_warnings)
            action_text = "stopped" if stopped else "already stopped/not running"
            message = (
                f"SNMP-generated YAML retired; Switch Vision SNMP2MQTT {action_text}. "
                f"Retained Home Assistant MQTT discovery entries retired: {mqtt_cleared}/{len(topics)}."
            )
            if mqtt_warnings:
                message += " Some retained discovery entries could not be cleared; use Reset SNMP Discovery Data to retry."
            lines.append(message)
            return {
                "status": "Stopped" if not mqtt_warnings else "Warning",
                "action": "retire",
                "slug": runtime.get("slug"),
                "state": "stopped" if stopped else runtime.get("state"),
                "mqtt_topics_found": len(topics),
                "mqtt_topics_cleared": mqtt_cleared,
                "message": message,
            }
        message = "SNMP2MQTT was not started because Discovery has no active SNMP-generated YAML."
        lines.append(message)
        return {"status": "Not used", "action": "none", "slug": None, "state": None, "message": message}
    current_mtime = DEFAULT_GENERATED_SNMP2MQTT.stat().st_mtime
    if previous_mtime is not None and current_mtime <= previous_mtime:
        message = "SNMP2MQTT was not restarted because generated-snmp2mqtt.yaml was not updated by this Discovery run."
        lines.append(message)
        return {"status": "Not changed", "action": "none", "slug": None, "state": None, "message": message}
    validation = _validate_snmp2mqtt_yaml(DEFAULT_GENERATED_SNMP2MQTT)
    if not validation.get("valid"):
        message = f"Generated SNMP2MQTT YAML was not applied: {validation.get('error')}"
        lines.append(message)
        return {"status": "Warning", "action": "none", "slug": None, "state": None, "message": message}

    try:
        runtime = _snmp2mqtt_runtime_info()
        if not runtime.get("installed") or not runtime.get("slug"):
            message = "Switch Vision SNMP2MQTT app is not installed; Discovery completed without restarting it."
            lines.append(message)
            return {"status": "Warning", "action": "none", "slug": None, "state": "not_installed", "message": message}

        configuration_mode, mode_issue = _snmp2mqtt_handoff_mode(runtime)
        slug = str(runtime.get("slug") or "")
        state = str(runtime.get("state") or "unknown").lower()
        if mode_issue:
            lines.append(mode_issue)
            return {
                "status": "Warning",
                "action": "blocked_configuration",
                "slug": slug,
                "state": state,
                "configuration_mode": configuration_mode,
                "activation_verified": False,
                "handoff_failed": True,
                "message": mode_issue,
            }

        action = "restart" if state in {"started", "running"} else "start"
        lines.append(f"SNMP2MQTT app found: {slug} ({state}); requesting {action}.")
        _supervisor_json(f"/addons/{quote(slug, safe='')}/{action}", method="POST", timeout=20.0)

        # Supervisor accepting a restart request is not proof that the new
        # generated file was consumed. Wait briefly, inspect state, then check
        # the exact generated configuration identity. Retained MQTT discovery
        # publication is asynchronous (and some entities intentionally publish
        # on slower timers), so entity counts are never a Discovery success gate.
        time.sleep(2.0)
        resulting_state = "requested"
        try:
            info = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
            info_data = info.get("data") if isinstance(info.get("data"), dict) else info
            if isinstance(info_data, dict):
                resulting_state = str(info_data.get("state") or resulting_state)
        except Exception as exc:
            lines.append(f"SNMP2MQTT status refresh warning: {type(exc).__name__}.")

        exact_load_verified = _verify_snmp2mqtt_generated_config_loaded(lines, runtime)
        activation = {
            "activation_verified": exact_load_verified,
            "mqtt_current_expected": None,
            "mqtt_current_retained": None,
            "mqtt_current_missing": None,
            "mqtt_stale_count": None,
            "verification_status": "not_required",
        }
        try:
            info = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
            info_data = info.get("data") if isinstance(info.get("data"), dict) else info
            if isinstance(info_data, dict):
                resulting_state = str(info_data.get("state") or resulting_state)
        except Exception as exc:
            lines.append(f"SNMP2MQTT final status refresh warning: {type(exc).__name__}.")

        if resulting_state not in {"started", "running"}:
            message = (
                f"Switch Vision SNMP2MQTT {action} was requested, but the app did not "
                "return to a running state. Previous retained identities were preserved."
            )
            lines.append(message)
            return {
                "status": "Warning",
                "action": action,
                "slug": slug,
                "state": resulting_state,
                "configuration_mode": configuration_mode,
                **activation,
                "activation_verified": False,
                "handoff_failed": True,
                "message": message,
            }

        if not exact_load_verified:
            message = (
                f"Switch Vision SNMP2MQTT {action} was requested and the app is running, "
                "but exact generated-configuration load was not verified yet. "
                "Discovery output remains valid; review the SNMP2MQTT app status/log if entities do not appear."
            )
            lines.append(message)
            return {
                "status": "Warning",
                "action": action,
                "slug": slug,
                "state": resulting_state,
                "configuration_mode": configuration_mode,
                **activation,
                "config_load_verified": False,
                "activation_verified": False,
                "handoff_failed": True,
                "message": message,
            }

        # The replacement configuration is proven loaded. Retained Home
        # Assistant discovery publication is runtime health evidence and can
        # lag a working poller, so it must not turn this successful handoff
        # into a false activation failure.
        refreshed_runtime = _snmp2mqtt_runtime_info()
        prefix = str(
            refreshed_runtime.get("homeassistant_prefix")
            or runtime.get("homeassistant_prefix")
            or ""
        ).strip().strip("/")
        current_topics = (
            _snmp2mqtt_discovery_topics(DEFAULT_GENERATED_SNMP2MQTT, prefix)
            if prefix
            else []
        )
        retired_topics = sorted(set(previous_topics or []) - set(current_topics))
        retired_cleared = 0
        retired_warnings: list[str] = []
        if retired_topics:
            retired_cleared, retired_warnings = _clear_retained_snmp2mqtt_discovery(retired_topics)
            lines.extend(retired_warnings)

        if current_topics:
            retirement_state = current_topics if not retired_warnings else sorted(
                set(current_topics) | set(retired_topics)
            )
            _save_snmp2mqtt_retirement_topics(retirement_state)

        message = f"Switch Vision SNMP2MQTT {action} verified active from exact generated configuration load."
        if retired_topics:
            message += (
                f" Previous generated discovery entries retired: "
                f"{retired_cleared}/{len(retired_topics)}."
            )
        if retired_warnings:
            message += " Some previous generated discovery entries could not be retired."
        lines.append(message)
        return {
            "status": "Warning" if retired_warnings else "Running",
            "action": action,
            "slug": slug,
            "state": resulting_state,
            "configuration_mode": configuration_mode,
            **activation,
            "config_load_verified": True,
            "activation_verified": True,
            "handoff_failed": False,
            "mqtt_topics_retired": retired_cleared,
            "mqtt_topics_retired_found": len(retired_topics),
            "message": message,
        }
    except Exception as exc:
        message = f"Could not start or restart Switch Vision SNMP2MQTT: {exc}"
        lines.append(message)
        return {
            "status": "Warning",
            "action": "failed",
            "slug": None,
            "state": None,
            "activation_verified": False,
            "handoff_failed": True,
            "message": message,
        }


def _validate_snmp2mqtt_yaml(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"valid": False, "error": "Generated SNMP2MQTT YAML was not found."}
    try:
        text = path.read_text(encoding="utf-8")
        data = yaml.safe_load(text)
    except (OSError, UnicodeDecodeError, yaml.YAMLError) as exc:
        return {"valid": False, "error": f"YAML validation failed: {exc}"}
    if not isinstance(data, (dict, list)) or not data:
        return {"valid": False, "error": "Generated YAML is empty or does not contain a YAML mapping/list."}

    targets = data.get("targets") if isinstance(data, dict) else data
    if not isinstance(targets, list) or not targets:
        return {"valid": False, "error": "Generated YAML does not contain a non-empty targets list."}
    total_sensors = 0
    for index, target in enumerate(targets, start=1):
        if not isinstance(target, dict):
            return {"valid": False, "error": f"Generated YAML target {index} is not a mapping."}
        host = target.get("host") or target.get("target")
        if not isinstance(host, str) or not host.strip():
            return {"valid": False, "error": f"Generated YAML target {index} has no management host/target."}
        sensors = target.get("sensors")
        # Discovery intentionally emits some empty polling chunks for models
        # that do not expose a sensor family (for example Huawei VLAN/trunk
        # chunks).  Empty chunks are valid, but null/non-list sensor blocks are
        # not, and a generated file must contain at least one sensor overall.
        if not isinstance(sensors, list):
            return {"valid": False, "error": f"Generated YAML target {index} sensors must be a list."}
        total_sensors += len(sensors)
        for sensor_index, sensor in enumerate(sensors, start=1):
            if not isinstance(sensor, dict):
                return {"valid": False, "error": f"Generated YAML target {index} sensor {sensor_index} is not a mapping."}

            sensor_source = str(sensor.get("source") or "").strip()
            oid = str(sensor.get("oid") or "").strip()

            if sensor_source in {"juniper_ex_vlan", "interface"}:
                if oid:
                    return {
                        "valid": False,
                        "error": (
                            f"Generated YAML target {index} sensor {sensor_index} "
                            f"named-interface source {sensor_source} must not define an OID."
                        ),
                    }

                interface_name = str(sensor.get("interface") or "").strip()
                interfaces_value = sensor.get("interfaces")
                interface_candidates: list[str] = []

                if interfaces_value is not None:
                    if not isinstance(interfaces_value, list) or not interfaces_value:
                        return {
                            "valid": False,
                            "error": (
                                f"Generated YAML target {index} sensor {sensor_index} "
                                f"has invalid interfaces candidate list."
                            ),
                        }
                    for candidate in interfaces_value:
                        if not isinstance(candidate, str) or not candidate.strip():
                            return {
                                "valid": False,
                                "error": (
                                    f"Generated YAML target {index} sensor {sensor_index} "
                                    f"has invalid interfaces candidate list."
                                ),
                            }
                        interface_candidates.append(candidate.strip())

                if not interface_name and not interface_candidates:
                    return {
                        "valid": False,
                        "error": (
                            f"Generated YAML target {index} sensor {sensor_index} "
                            f"has no interface or interface candidates."
                        ),
                    }

                attribute = str(sensor.get("attribute") or "").strip()

                if sensor_source == "juniper_ex_vlan":
                    source_label = "Juniper VLAN"
                    allowed_attributes = {
                        "mode",
                        "native_vlan",
                        "vlans",
                        "tagged_vlans",
                        "untagged_vlans",
                        "summary",
                    }
                else:
                    source_label = "Interface"
                    allowed_attributes = {
                        "oper_status",
                        "admin_status",
                        "speed_mbps",
                        "rx_bytes",
                        "tx_bytes",
                        "alias",
                    }

                if not attribute:
                    return {
                        "valid": False,
                        "error": (
                            f"Generated YAML target {index} sensor {sensor_index} "
                            f"{source_label} sensor has no attribute."
                        ),
                    }

                if attribute not in allowed_attributes:
                    return {
                        "valid": False,
                        "error": (
                            f"Generated YAML target {index} sensor {sensor_index} "
                            f"{source_label} sensor has unsupported attribute: {attribute}"
                        ),
                    }
                continue

            if oid:
                continue

            if sensor_source:
                return {
                    "valid": False,
                    "error": (
                        f"Generated YAML target {index} sensor {sensor_index} "
                        f"uses unsupported OID-less source: {sensor_source}"
                    ),
                }

            return {"valid": False, "error": f"Generated YAML target {index} sensor {sensor_index} has no OID."}
    if total_sensors <= 0:
        return {"valid": False, "error": "Generated YAML contains no SNMP sensors."}

    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return {"valid": True, "error": None, "size": len(text.encode("utf-8")), "sha256": digest, "text": text}


def _snmp2mqtt_applicability() -> dict[str, Any]:
    """Return whether generated SNMP2MQTT YAML is relevant to this installation."""
    try:
        options = _self_addon_options()
    except RuntimeError:
        options = _load_options(DEFAULT_OPTIONS_FILE)

    generate_value = options.get("generate_snmp2mqtt", "true")
    if isinstance(generate_value, bool):
        generator_enabled = generate_value
    else:
        generator_enabled = str(generate_value).strip().lower() not in {
            "false", "0", "no", "off", "disabled", "disable",
        }
    if not generator_enabled:
        return {
            "applicable": False,
            "reason": "SNMP2MQTT YAML generation is disabled in Discovery options.",
        }

    rows = options.get("switches")
    if not isinstance(rows, list):
        rows = options.get("multi_switch_walks")
    if isinstance(rows, list):
        for row in rows:
            if not isinstance(row, dict):
                continue
            enabled_value = row.get("enabled", "enabled")
            if isinstance(enabled_value, bool):
                enabled = enabled_value
            else:
                state = str(enabled_value).strip().lower()
                enabled = state not in {
                    "false", "disabled", "disable", "off", "no", "0",
                }
            if not enabled:
                continue
            switch_name = str(
                row.get("switch_name")
                or row.get("switch")
                or row.get("selected_switch")
                or row.get("name")
                or ""
            ).strip()
            switch_host = str(
                row.get("switch_host")
                or row.get("host")
                or row.get("manual_switch_host")
                or ""
            ).strip()
            if switch_name and switch_host:
                return {
                    "applicable": True,
                    "reason": "At least one enabled SNMP switch target is configured.",
                }

    parse_value = options.get("parse_all_walks", "false")
    if isinstance(parse_value, bool):
        parse_all = parse_value
    else:
        parse_all = str(parse_value).strip().lower() in {
            "true", "1", "yes", "on", "enabled", "enable",
        }
    input_path = Path(
        str(options.get("input_path") or (DEFAULT_SHARE_DIR / "snmpwalk.txt"))
    )
    if parse_all and input_path.is_file():
        return {
            "applicable": True,
            "reason": "Legacy SNMP walk parsing is enabled with an available input walk.",
        }

    return {
        "applicable": False,
        "reason": (
            "No enabled SNMP targets are configured. "
            "UniFi2MQTT-only installations do not require generated SNMP2MQTT YAML."
        ),
    }


def _generated_yaml_status() -> dict[str, Any]:
    applicability = _snmp2mqtt_applicability()
    generated = _file_info(DEFAULT_GENERATED_SNMP2MQTT)
    if not applicability["applicable"]:
        return {
            "applicable": False,
            "reason": applicability["reason"],
            "generated": generated,
            "validation": {"valid": None, "error": None},
            "import_note": (
                "SNMP2MQTT YAML is not required while no enabled SNMP targets are configured. "
                "UniFi API devices continue through UniFi2MQTT independently."
            ),
        }
    validation = _validate_snmp2mqtt_yaml(DEFAULT_GENERATED_SNMP2MQTT)
    return {
        "applicable": True,
        "reason": applicability["reason"],
        "generated": generated,
        "validation": {key: value for key, value in validation.items() if key != "text"},
        "import_note": "A valid changed generated YAML is applied to Switch Vision SNMP2MQTT automatically when that app is available; invalid candidates are never published.",
    }

def _validate_generated_card_yaml(path: Path) -> dict[str, Any]:
    """Validate and return the Discovery-generated dashboard YAML preview."""
    if not path.is_file():
        return {"valid": False, "error": "Generated Card YAML was not found."}
    try:
        text = path.read_text(encoding="utf-8")
        documents = list(yaml.safe_load_all(text))
    except (OSError, UnicodeDecodeError, yaml.YAMLError) as exc:
        return {"valid": False, "error": f"Card YAML validation failed: {exc}"}

    meaningful = [document for document in documents if document not in (None, {}, [])]
    if not meaningful:
        return {"valid": False, "error": "Generated Card YAML is empty."}
    if not all(isinstance(document, (dict, list)) for document in meaningful):
        return {"valid": False, "error": "Generated Card YAML contains an unsupported top-level value."}

    first = meaningful[0]
    if isinstance(first, dict) and not ({"views", "cards", "type"} & set(first)):
        return {"valid": False, "error": "Generated Card YAML does not contain a dashboard, card list, or card type."}

    encoded = text.encode("utf-8")
    return {
        "valid": True,
        "error": None,
        "size": len(encoded),
        "sha256": hashlib.sha256(encoded).hexdigest(),
        "documents": len(meaningful),
        "text": text,
    }


def _generated_card_yaml_status() -> dict[str, Any]:
    validation = _validate_generated_card_yaml(DEFAULT_GENERATED_CARD)
    return {
        "generated": _file_info(DEFAULT_GENERATED_CARD),
        "validation": {key: value for key, value in validation.items() if key != "text"},
        "note": "Review or export this dashboard YAML. Discovery does not install it automatically.",
    }


def _generated_dashboard_export(
    path: Path,
    *,
    cards_only: bool = False,
    custom_dashboard: bool = False,
) -> dict[str, Any]:
    """Return a manual-dashboard export derived from validated Discovery YAML.

    The Native dashboard source intentionally keeps its current layout contract.
    Standard manual exports remove the known third-party vertical-layout wrapper
    so the pasted dashboard has no Layout Card dependency. Custom-dashboard
    exports preserve that reviewed wrapper and its layout metadata so a newly
    created Home Assistant dashboard can match the generated Switch Vision view.
    """
    validation = _validate_generated_card_yaml(path)
    if not validation.get("valid"):
        return {"valid": False, "error": validation.get("error") or "Generated dashboard YAML is invalid."}

    try:
        documents = list(yaml.safe_load_all(validation["text"]))
    except yaml.YAMLError as exc:
        return {"valid": False, "error": f"Dashboard export parse failed: {exc}"}
    meaningful = [document for document in documents if document not in (None, {}, [])]
    if len(meaningful) != 1 or not isinstance(meaningful[0], dict):
        return {"valid": False, "error": "Dashboard export requires exactly one dashboard document."}

    dashboard = copy.deepcopy(meaningful[0])
    views = dashboard.get("views")
    if not isinstance(views, list) or not views:
        return {"valid": False, "error": "Dashboard export requires at least one Home Assistant view."}

    for view in views:
        if not isinstance(view, dict):
            return {"valid": False, "error": "Dashboard export contains an invalid view."}
        view_type = view.get("type")
        if view_type == "custom:vertical-layout":
            if not custom_dashboard:
                view.pop("type", None)
                view.pop("layout", None)
        elif isinstance(view_type, str) and view_type.startswith("custom:"):
            return {"valid": False, "error": f"Dashboard export cannot safely handle unknown custom view dependency: {view_type}"}
        else:
            # Generated layout metadata is only meaningful to custom layout views.
            view.pop("layout", None)

    if cards_only:
        if len(views) != 1:
            return {"valid": False, "error": "Cards-only export requires the generated dashboard to contain exactly one view."}
        cards = views[0].get("cards")
        if not isinstance(cards, list) or not cards:
            return {"valid": False, "error": "Cards-only export found no generated cards."}
        body = yaml.safe_dump(cards, sort_keys=False, allow_unicode=True, default_flow_style=False)
        text = (
            "# Switch Vision cards-only export\n"
            "# Paste these list entries beneath an existing Home Assistant view's cards: key.\n"
            "# This is a snapshot; regenerate and copy again after Discovery changes.\n"
            + body
        )
        mode = "cards"
    else:
        body = yaml.safe_dump(dashboard, sort_keys=False, allow_unicode=True, default_flow_style=False)
        if custom_dashboard:
            text = (
                "# Switch Vision custom dashboard export\n"
                "# Paste into a new Home Assistant dashboard Raw configuration editor.\n"
                "# Preserves the generated custom:vertical-layout view; Layout Card is required.\n"
                "# This is a snapshot; regenerate and copy again after Discovery changes.\n"
                + body
            )
            mode = "custom-dashboard"
        else:
            text = (
                "# Switch Vision dashboard export\n"
                "# Paste into a new Home Assistant dashboard Raw configuration editor.\n"
                "# No third-party Layout Card view dependency is required.\n"
                "# This is a snapshot; regenerate and copy again after Discovery changes.\n"
                + body
            )
            mode = "dashboard"

    encoded = text.encode("utf-8")
    return {
        "valid": True,
        "error": None,
        "mode": mode,
        "text": text,
        "size": len(encoded),
        "sha256": hashlib.sha256(encoded).hexdigest(),
    }


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None


def _file_info(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"found": False, "path": str(path), "size": 0, "modified": None}
    stat = path.stat()
    return {
        "found": True,
        "path": str(path),
        "size": stat.st_size,
        "modified": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(stat.st_mtime)),
    }


def _normalized_device_mac(value: Any) -> str:
    compact = re.sub(r"[^0-9a-f]", "", str(value or "").strip().casefold())
    if len(compact) != 12 or not re.fullmatch(r"[0-9a-f]{12}", compact):
        return ""
    return ":".join(compact[index:index + 2] for index in range(0, 12, 2))


def _normalized_device_ip(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        return ipaddress.ip_address(text).compressed
    except ValueError:
        return ""


def _unique_detected_snmp_identity_match(
    devices: list[dict[str, Any]], *, mac_address: Any = "", ip_address: Any = ""
) -> tuple[dict[str, Any] | None, str]:
    mac = _normalized_device_mac(mac_address)
    if mac:
        matches = [
            item for item in devices
            if item.get("data_source", "SNMP") != "UniFi API"
            and _normalized_device_mac(item.get("_identity_mac")) == mac
        ]
        if len(matches) == 1:
            return matches[0], "hardware_mac"
        if len(matches) > 1:
            return None, ""

    ip = _normalized_device_ip(ip_address)
    if ip:
        matches = [
            item for item in devices
            if item.get("data_source", "SNMP") != "UniFi API"
            and _normalized_device_ip(item.get("_identity_ip")) == ip
        ]
        if len(matches) == 1:
            return matches[0], "management_ip"

    return None, ""


def _walk_management_target(path: Path) -> str:
    """Read the management target recorded in a Switch Vision walk header."""
    if not path.is_file():
        return ""
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for _ in range(32):
                line = handle.readline()
                if not line:
                    break
                if line.startswith("# Switch IP: "):
                    value = line.split(": ", 1)[1].strip()
                    if value not in {"", "not set", "unknown"}:
                        return value[:255]
    except OSError:
        return ""
    return ""


def _diagnostics_snapshot(version: str) -> dict[str, Any]:
    share = DEFAULT_SHARE_DIR
    registry_raw = _read_json(DEFAULT_REGISTRY_FILE)
    if isinstance(registry_raw, dict):
        registry_devices = registry_raw.get("devices") or []
    elif isinstance(registry_raw, list):
        registry_devices = registry_raw
    else:
        registry_devices = []

    capability_dir = share / "capabilities"
    capability_files = sorted(capability_dir.glob("*-capabilities.json")) if capability_dir.is_dir() else []
    devices: list[dict[str, Any]] = []
    warnings: list[str] = []
    errors: list[str] = []
    for cap_path in capability_files:
        data = _read_json(cap_path)
        if not isinstance(data, dict):
            warnings.append(f"Could not read capability file: {cap_path.name}")
            continue
        device = data.get("device") if isinstance(data.get("device"), dict) else {}
        interfaces = data.get("interfaces") if isinstance(data.get("interfaces"), list) else []
        model = str(device.get("detected_model_text") or device.get("model_text") or device.get("model") or "Unknown")
        registry = registry_lookup({"devices": registry_devices}, model) or {}
        validation = registry.get("validation") if isinstance(registry.get("validation"), dict) else {}
        physical = [i for i in interfaces if isinstance(i, dict) and i.get("physical")]
        rj45 = [i for i in physical if i.get("media") == "rj45"]
        uplinks = [i for i in physical if i.get("media") in {"sfp", "sfp_plus", "uplink"}]
        source_walk_value = str(data.get("source_walk") or "").strip()
        source_walk = Path(source_walk_value) if source_walk_value else Path()
        walk_found = source_walk.is_file() if source_walk_value else False
        source_switch_name = source_walk.parent.name if source_walk_value else ""
        # Capability JSON is a current generated cache, not an archive. If a
        # record explicitly names a source walk that no longer exists, do not
        # present it as a currently detected extra device. This also prevents a
        # pre-rename capability alias (for example 2960x-48-rj45) from appearing
        # beside its current saved row after the walk folder moved to 2960x-48p.
        if source_walk_value and not walk_found:
            continue
        management_target = str(device.get("management_target") or "").strip()[:255]
        if not management_target:
            management_target = _walk_management_target(source_walk)
        status = str(registry.get("status") or device.get("support_status") or "detected")
        devices.append({
            "name": cap_path.name.removesuffix("-capabilities.json"),
            "source_switch_name": source_switch_name,
            "management_target": management_target,
            "model": model,
            "family": registry.get("family") or device.get("family") or "Unknown",
            "registry_match": bool(registry),
            "registry_status": status,
            "last_validated_version": registry.get("last_validated_version"),
            "mapping_profile": registry.get("mapping_profile") or registry.get("dashboard_profile"),
            "calibration_profile": registry.get("calibration_profile"),
            "validation": validation,
            "physical_interfaces": len(physical),
            "rj45_interfaces": len(rj45),
            "uplink_interfaces": len(uplinks),
            "walk_found": walk_found,
            "generated_at": data.get("generated_at"),
            # Private server-side identity hints are removed before the
            # diagnostics payload leaves the app. They exist only to collapse a
            # proven SNMP + UniFi observation of the same physical chassis.
            "_identity_mac": (
                device.get("mac_address")
                or device.get("base_mac")
                or device.get("chassis_mac")
                or device.get("mac")
                or ""
            ),
            "_identity_ip": management_target,
        })

    # Merge normalized UniFi2MQTT devices into the same Devices/Diagnostics
    # view without requiring duplicate SNMP target rows.
    unifi_snapshot = _read_json(DEFAULT_UNIFI_SNAPSHOT)
    if isinstance(unifi_snapshot, dict) and isinstance(unifi_snapshot.get("devices"), list):
        for raw in unifi_snapshot["devices"]:
            if not isinstance(raw, dict):
                continue
            model = str(raw.get("model") or "Unknown")
            registry = registry_lookup({"devices": registry_devices}, model) or {}
            validation = registry.get("validation") if isinstance(registry.get("validation"), dict) else {}
            ports = raw.get("ports") if isinstance(raw.get("ports"), list) else []
            physical = [p for p in ports if isinstance(p, dict)]
            rj45 = [p for p in physical if str(p.get("connector") or "").upper() == "RJ45"]
            uplinks = [p for p in physical if str(p.get("connector") or "").upper() in {"SFP", "SFPPLUS", "SFP+"}]
            matched_snmp, match_basis = _unique_detected_snmp_identity_match(
                devices,
                mac_address=raw.get("mac_address"),
                ip_address=raw.get("ip_address"),
            )
            if matched_snmp is not None:
                # Keep the SNMP row as the stable configured/display identity
                # and attach the independently proven UniFi source to it. Never
                # merge by model/name alone: hardware MAC is authoritative and a
                # unique management IP is the only fallback.
                matched_snmp["unifi_device_id"] = str(raw.get("id") or "").strip()
                matched_snmp["data_source"] = "SNMP + UniFi API"
                matched_snmp["unifi_match_basis"] = match_basis
                matched_snmp["online"] = str(raw.get("state") or "").upper() == "ONLINE"
                matched_snmp["firmware"] = raw.get("firmware")
                matched_snmp["api_capabilities"] = (
                    raw.get("api_capabilities")
                    if isinstance(raw.get("api_capabilities"), dict)
                    else {}
                )
                continue

            devices.append({
                "unifi_device_id": str(raw.get("id") or "").strip(),
                "name": str(raw.get("name") or model),
                "model": model,
                "family": registry.get("family") or "UniFi",
                "registry_match": bool(registry),
                "registry_status": str(registry.get("status") or "detected"),
                "last_validated_version": registry.get("last_validated_version"),
                "mapping_profile": registry.get("mapping_profile") or registry.get("dashboard_profile"),
                "calibration_profile": registry.get("calibration_profile"),
                "validation": validation,
                "physical_interfaces": len(physical),
                "rj45_interfaces": len(rj45),
                "uplink_interfaces": len(uplinks),
                "walk_found": False,
                "generated_at": unifi_snapshot.get("generated_at"),
                "data_source": "UniFi API",
                "online": str(raw.get("state") or "").upper() == "ONLINE",
                "firmware": raw.get("firmware"),
                "api_capabilities": raw.get("api_capabilities") if isinstance(raw.get("api_capabilities"), dict) else {},
            })

    unifi_diagnostics = _unifi2mqtt_diagnostics_status()

    if unifi_diagnostics.get("found"):
        if not unifi_diagnostics.get("valid"):
            warnings.append(
                "UniFi2MQTT diagnostics.json could not be read."
            )
        elif unifi_diagnostics.get("status") == "error":
            stage = unifi_diagnostics.get("stage") or "unknown"
            error_type = (
                unifi_diagnostics.get("error_type")
                or "UnknownError"
            )
            warnings.append(
                "UniFi2MQTT poll failed at "
                f"{stage}: {error_type}."
            )

    # Identity hints used for local reconciliation are never returned to the
    # browser/diagnostics download.
    for item in devices:
        item.pop("_identity_mac", None)
        item.pop("_identity_ip", None)

    registry_loaded = isinstance(registry_raw, (dict, list))
    if not registry_loaded:
        errors.append("Supported-device registry could not be loaded.")
    report = _file_info(share / "discovery-report.txt")
    generated_yaml = _file_info(share / "generated-snmp2mqtt.yaml")
    generated_card = _file_info(share / "generated-dashboard-card.yaml")
    if not report["found"]:
        warnings.append("No discovery report has been generated yet.")
    snmp2mqtt_applicability = _snmp2mqtt_applicability()
    if not generated_yaml["found"] and snmp2mqtt_applicability["applicable"]:
        warnings.append("Generated SNMP2MQTT YAML was not found.")
    if not generated_card["found"]:
        warnings.append("Generated dashboard YAML was not found.")
    if report["found"]:
        report_path = share / "discovery-report.txt"
        report_mtime = report_path.stat().st_mtime
        # Files from one successful Discovery run are written sequentially and
        # can legitimately have slightly different mtimes. Only flag a file as
        # stale when it predates the report by more than two minutes, which
        # indicates it came from an earlier run rather than the same pipeline.
        stale_tolerance_seconds = 120
        stale_candidates = [("dashboard YAML", share / "generated-dashboard-card.yaml")]
        if snmp2mqtt_applicability["applicable"]:
            stale_candidates.insert(0, ("SNMP2MQTT YAML", share / "generated-snmp2mqtt.yaml"))
        for label, path in stale_candidates:
            if not path.is_file():
                continue
            generated_mtime = path.stat().st_mtime
            if generated_mtime + stale_tolerance_seconds < report_mtime:
                generated_text = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(generated_mtime))
                report_text = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(report_mtime))
                warnings.append(
                    f"Generated {label} appears stale: generated {generated_text}; latest discovery report {report_text}."
                )

    return {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "version": version,
        "service": "Running",
        "discovery": _discovery_state_snapshot(),
        "registry": {"loaded": registry_loaded, "entries": len(registry_devices), "path": str(DEFAULT_REGISTRY_FILE)},
        "files": {"report": report, "generated_yaml": generated_yaml, "generated_card": generated_card},
        "snmp2mqtt_applicability": snmp2mqtt_applicability,
        "contribution_workflow": {"ready": DEFAULT_SUPPORT_SCRIPT.is_file(), "directory": str(DEFAULT_CONTRIBUTIONS_DIR)},
        "devices": devices,
        "unifi2mqtt_diagnostics": unifi_diagnostics,
        "warnings": warnings,
        "errors": errors,
    }


def _diagnostics_text(data: dict[str, Any]) -> str:
    snmp_applicability = data.get("snmp2mqtt_applicability") or {}
    if snmp_applicability.get("applicable", True):
        snmp_yaml_status = (
            "Found"
            if ((data.get("files") or {}).get("generated_yaml") or {}).get("found")
            else "Missing"
        )
    else:
        snmp_yaml_status = "Not applicable"
    lines = [
        "Switch Vision Diagnostics",
        "=========================",
        f"Generated: {data.get('generated_at')}",
        f"Switch Vision version: {data.get('version')}",
        f"Discovery app: {data.get('service')}",
        f"Discovery status: {(data.get('discovery') or {}).get('message', 'Unknown')}",
        f"Device registry: {'Loaded' if (data.get('registry') or {}).get('loaded') else 'Unavailable'}",
        f"Registry entries: {(data.get('registry') or {}).get('entries', 0)}",
        f"Generated SNMP2MQTT YAML: {snmp_yaml_status}",
        f"Generated dashboard YAML: {'Found' if ((data.get('files') or {}).get('generated_card') or {}).get('found') else 'Missing'}",
        f"Contribution workflow: {'Ready' if (data.get('contribution_workflow') or {}).get('ready') else 'Unavailable'}",
        (
            "UniFi2MQTT diagnostics: "
            + (
                (
                    f"{(data.get('unifi2mqtt_diagnostics') or {}).get('status') or 'unknown'}"
                    f" · stage {(data.get('unifi2mqtt_diagnostics') or {}).get('stage') or 'unknown'}"
                    f" · adopted {(data.get('unifi2mqtt_diagnostics') or {}).get('adopted_devices', 0)}"
                    f" · switches {(data.get('unifi2mqtt_diagnostics') or {}).get('switching_devices', 0)}"
                    f" · rejected {(data.get('unifi2mqtt_diagnostics') or {}).get('rejected_devices', 0)}"
                )
                if (data.get('unifi2mqtt_diagnostics') or {}).get('found')
                else "Unavailable"
            )
        ),
        "",
    ]

    unifi_diag = (
        data.get("unifi2mqtt_diagnostics")
        if isinstance(
            data.get("unifi2mqtt_diagnostics"),
            dict,
        )
        else {}
    )

    classifications = (
        unifi_diag.get("device_classification")
        if isinstance(
            unifi_diag.get("device_classification"),
            list,
        )
        else []
    )

    if classifications:
        lines.append(
            "UniFi2MQTT hardware classification"
        )
        lines.append(
            "---------------------------------"
        )

        for item in classifications:
            if not isinstance(item, dict):
                continue

            model = str(
                item.get("model")
                or "Unknown"
            )

            lines.append(
                f"Model: {model}"
            )
            lines.append(
                "Accepted as switch: "
                + (
                    "yes"
                    if item.get("accepted")
                    else "no"
                )
            )
            lines.append(
                "Classification: "
                + str(
                    item.get("reason")
                    or "unknown"
                )
            )

            features = item.get("features")

            if isinstance(features, list):
                lines.append(
                    "Features: "
                    + (
                        ", ".join(
                            str(value)
                            for value in features
                        )
                        or "none"
                    )
                )

            lines.append("")

    for device in data.get("devices") or []:
        source = str(device.get("data_source") or "SNMP")
        source_status = (
            f"UniFi API state: {'ONLINE' if device.get('online') else 'OFFLINE'}"
            if source == "UniFi API"
            else f"Last SNMP walk: {'PASS/file found' if device.get('walk_found') else 'Unavailable'}"
        )
        lines.extend([
            str(device.get("model") or "Unknown model"),
            "-" * len(str(device.get("model") or "Unknown model")),
            f"Target: {device.get('name')}",
            f"Data source: {source}",
            f"Registry match: {'yes' if device.get('registry_match') else 'no'}",
            f"Registry status: {device.get('registry_status')}",
            source_status,
            *( [f"Firmware: {device.get('firmware') or 'Unknown'}"] if source == "UniFi API" else [] ),
            f"Physical interfaces: {device.get('physical_interfaces', 0)}",
            f"RJ45 interfaces: {device.get('rj45_interfaces', 0)}",
            f"Uplink interfaces: {device.get('uplink_interfaces', 0)}",
            f"Mapping profile: {device.get('mapping_profile') or 'Not assigned'}",
            f"Calibration profile: {device.get('calibration_profile') or 'Not assigned'}",
        ])
        validation = device.get("validation") or {}
        for label, key in [("Exact model", "exact_model_detection"), ("RJ45 mapping", "rj45_mapping"), ("PoE", "poe"), ("System sensors", "system_sensors"), ("Uplinks", "uplinks"), ("Stack", "stack")]:
            lines.append(f"{label}: {validation.get(key, 'unknown')}")
        lines.append("")
    if data.get("warnings"):
        lines.append("Warnings")
        lines.append("--------")
        lines.extend(f"WARNING: {item}" for item in data["warnings"])
        lines.append("")
    if data.get("errors"):
        lines.append("Errors")
        lines.append("------")
        lines.extend(f"ERROR: {item}" for item in data["errors"])
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _validate_request(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("Request body must be a JSON object.")
    contributor_type = str(data.get("contributor_type") or "anonymous")
    if contributor_type not in {"anonymous", "first_name", "full_name", "github", "forum"}:
        raise ValueError("Invalid recognition type.")
    contributor_value = str(data.get("contributor_value") or "").replace("\n", " ").replace("\r", " ").strip()[:120]
    if contributor_type != "anonymous" and not contributor_value:
        raise ValueError("Enter the name or username to use for recognition, or choose Anonymous.")
    return {
        "mask_management_ips": _safe_bool(data.get("mask_management_ips"), True),
        "mask_mac_addresses": _safe_bool(data.get("mask_mac_addresses"), True),
        "mask_hostnames": _safe_bool(data.get("mask_hostnames"), True),
        "mask_vlan_names": _safe_bool(data.get("mask_vlan_names"), False),
        "mask_interface_descriptions": _safe_bool(data.get("mask_interface_descriptions"), False),
        "contributor_type": contributor_type,
        "contributor_value": contributor_value,
    }


def _run_bundle(settings: dict[str, Any], support_script: Path, contributions_dir: Path, version: str) -> None:
    log_path = contributions_dir / "support-my-switch-web.log"
    contributions_dir.mkdir(parents=True, exist_ok=True)
    _set_state(
        running=True,
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        finished_at=None,
        success=None,
        message="Preparing contribution bundle…",
        log_tail=[],
    )
    env = os.environ.copy()
    env.update({
        "SWITCH_VISION_DISCOVERY_VERSION": version,
        "SUPPORT_MASK_MANAGEMENT_IPS": str(settings["mask_management_ips"]).lower(),
        "SUPPORT_MASK_MAC_ADDRESSES": str(settings["mask_mac_addresses"]).lower(),
        "SUPPORT_MASK_HOSTNAMES": str(settings["mask_hostnames"]).lower(),
        "SUPPORT_MASK_VLAN_NAMES": str(settings["mask_vlan_names"]).lower(),
        "SUPPORT_MASK_INTERFACE_DESCRIPTIONS": str(settings["mask_interface_descriptions"]).lower(),
        "SUPPORT_CONTRIBUTOR_TYPE": settings["contributor_type"],
        "SUPPORT_CONTRIBUTOR_VALUE": settings["contributor_value"],
        "CONTRIBUTIONS_DIR": str(contributions_dir),
    })
    lines: list[str] = []
    try:
        with log_path.open("a", encoding="utf-8") as log_file:
            log_file.write(f"\n=== Web UI contribution started {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            process = subprocess.Popen(
                [str(support_script)],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=env,
            )
            assert process.stdout is not None
            for line in process.stdout:
                clean = line.rstrip()
                log_file.write(line)
                log_file.flush()
                lines.append(clean)
                lines = lines[-40:]
                _set_state(log_tail=lines, message=clean or "Preparing contribution bundle…")
            return_code = process.wait()
        if return_code != 0:
            raise RuntimeError(f"Support My Switch exited with code {return_code}.")
        _set_state(success=True, message="Contribution ready")
    except Exception as exc:  # noqa: BLE001 - surface safe failure details in local UI
        lines.append(str(exc))
        _set_state(success=False, message=str(exc), log_tail=lines[-40:])
        try:
            with log_path.open("a", encoding="utf-8") as log_file:
                traceback.print_exc(file=log_file)
        except OSError:
            pass
    finally:
        _set_state(running=False, finished_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"))
        _release_operation("Support My Switch")


_PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Switch Vision Hub</title>
<script>
(()=>{const key='switch-vision-management-theme-v1';const allowed=['switch-vision','cisco-classic','cisco-nexus','unifi'];let theme='switch-vision';try{const saved=localStorage.getItem(key);if(allowed.includes(saved))theme=saved}catch(_e){}document.documentElement.dataset.svTheme=theme})();
</script>
<style>
:root{color-scheme:dark;--accent:#2196f3;--accent-strong:#2f83bd;--accent-dark:#0f4f7d;--accent-dark-hover:#146698;--accent-soft:rgba(33,150,243,.12);--page:#071525;--card:#0b1d31;--card-strong:#0e233b;--surface-input:#08192b;--surface-button:#0a1a2c;--surface-inset:#091a2d;--surface-hover:#102a44;--muted:#9bb0c7;--field-label:#b8c7d9;--line:#214766;--line-soft:#183750;--warn:#ffb74d;--warn-soft:rgba(255,183,77,.12);--ok:#45d483;--ok-soft:rgba(69,212,131,.15);--bad:#ff6b6b;--bad-soft:rgba(255,107,107,.13);--neutral-soft:rgba(119,128,138,.15);--text:#edf5fc;--on-accent:#fff;--on-primary:#fff;--shadow:rgba(0,0,0,.12);--status-bg:rgba(0,0,0,.12);--code-bg:rgba(0,0,0,.18);--chip-bg:rgba(255,255,255,.03);--chip-hover:rgba(255,255,255,.06);--heading:#69c8ff;--heading-strong:#a6e3ff;--heading-line:#2787c7;--heading-soft:rgba(105,200,255,.09);--heading-glow:rgba(33,150,243,.20);--heart:#ff6ea9;--sv-font-body:16px;--sv-font-page-title:max(18px,1.8em);--sv-font-section-title:max(14px,1.22em);--sv-font-small:max(10px,.86em);--sv-line-height:1.42;--control-height:38px;--control-radius:8px;--control-pad-x:10px;--control-pad-y:6px}
html[data-sv-theme="cisco-classic"]{color-scheme:dark;--accent:#049fd9;--accent-strong:#049fd9;--accent-dark:#005073;--accent-dark-hover:#00658f;--accent-soft:rgba(4,159,217,.13);--page:#1b2126;--card:#252c32;--card-strong:#303940;--surface-input:#171c21;--surface-button:#20272d;--surface-inset:#20272d;--surface-hover:#303f49;--muted:#b1bec7;--field-label:#c1ced6;--line:#4a5963;--line-soft:#39464f;--warn:#f0b323;--warn-soft:rgba(240,179,35,.13);--ok:#6cc04a;--ok-soft:rgba(108,192,74,.13);--bad:#e05b63;--bad-soft:rgba(224,91,99,.13);--neutral-soft:rgba(177,190,199,.10);--text:#f2f5f7;--on-accent:#fff;--on-primary:#fff;--shadow:rgba(0,0,0,.20);--status-bg:rgba(0,0,0,.18);--code-bg:rgba(0,0,0,.24);--chip-bg:rgba(255,255,255,.04);--chip-hover:rgba(255,255,255,.08);--heading:#4fc3e8;--heading-strong:#86dcf3;--heading-line:#049fd9;--heading-soft:rgba(4,159,217,.10);--heading-glow:rgba(4,159,217,.18)}
html[data-sv-theme="cisco-nexus"]{color-scheme:dark;--accent:#42b4e6;--accent-strong:#42b4e6;--accent-dark:#176b8f;--accent-dark-hover:#1d83ae;--accent-soft:rgba(66,180,230,.12);--page:#0f1418;--card:#171e24;--card-strong:#202a32;--surface-input:#11171c;--surface-button:#182128;--surface-inset:#141b21;--surface-hover:#23313a;--muted:#a4b2bc;--field-label:#b7c8d2;--line:#34434d;--line-soft:#28353d;--warn:#e7b23c;--warn-soft:rgba(231,178,60,.12);--ok:#63bf74;--ok-soft:rgba(99,191,116,.12);--bad:#df6970;--bad-soft:rgba(223,105,112,.12);--neutral-soft:rgba(164,178,188,.10);--text:#eef4f7;--on-accent:#071217;--on-primary:#fff;--shadow:rgba(0,0,0,.25);--status-bg:rgba(0,0,0,.22);--code-bg:rgba(0,0,0,.28);--chip-bg:rgba(255,255,255,.035);--chip-hover:rgba(255,255,255,.075);--heading:#79d7f5;--heading-strong:#ace9fb;--heading-line:#42b4e6;--heading-soft:rgba(66,180,230,.09);--heading-glow:rgba(66,180,230,.18)}
html[data-sv-theme="unifi"]{color-scheme:light;--accent:#006fff;--accent-strong:#57a0ff;--accent-dark:#003c9e;--accent-dark-hover:#0054cf;--accent-soft:rgba(0,111,255,.10);--page:#f5f6f7;--card:#fff;--card-strong:#fbfbfc;--surface-input:#fff;--surface-button:#f7f8f9;--surface-inset:#f8f9fa;--surface-hover:#eef5ff;--muted:#626675;--field-label:#4f6077;--line:#d7dce4;--line-soft:#e7eaf0;--warn:#a66500;--warn-soft:rgba(166,101,0,.10);--ok:#23884e;--ok-soft:rgba(35,136,78,.10);--bad:#c8434e;--bad-soft:rgba(200,67,78,.09);--neutral-soft:rgba(98,102,117,.09);--text:#242635;--on-accent:#fff;--on-primary:#fff;--shadow:rgba(31,35,41,.07);--status-bg:#f0f2f5;--code-bg:#eef0f3;--chip-bg:rgba(36,38,53,.025);--chip-hover:rgba(36,38,53,.065);--heading:#005ed8;--heading-strong:#003f9e;--heading-line:#6aa7ff;--heading-soft:rgba(0,111,255,.07);--heading-glow:rgba(0,111,255,.12)}
*{box-sizing:border-box}body{font-family:system-ui,-apple-system,sans-serif;font-size:var(--sv-font-body);margin:0;padding:22px;line-height:var(--sv-line-height);background:radial-gradient(900px 360px at 50% -180px,var(--heading-soft),transparent 70%),var(--page);color:var(--text)}main{max-width:1180px;margin:auto}h1{font-size:var(--sv-font-page-title);line-height:1.2;margin:.1rem 0;color:var(--heading-strong);text-shadow:0 1px 20px var(--heading-glow)}h2{font-size:var(--sv-font-section-title);line-height:1.25;color:var(--heading)}h3{font-size:1rem;line-height:1.3;color:var(--heading)}.lead{color:var(--muted);margin-top:.25rem}.card{background:linear-gradient(180deg,var(--card-strong) 0,var(--card) 104px);border:1px solid var(--line);border-radius:14px;padding:18px;margin:18px 0;box-shadow:0 12px 32px var(--shadow),inset 0 1px 0 var(--heading-soft)}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px 22px}.option{display:flex;gap:10px;align-items:flex-start;min-height:var(--control-height);padding:7px 0;font-weight:400}.option>span,.option>span>b{font-weight:400;color:var(--field-label)}.option input{margin-top:3px}.field{display:grid;gap:4px;margin:8px 0;align-content:start}.field>span,.field>span>b{color:var(--field-label)}select,input[type=text],input[type=file],input[type=number],input[type=password],input[type=url]{font:inherit;height:var(--control-height);min-height:var(--control-height);padding:var(--control-pad-y) var(--control-pad-x);border-radius:var(--control-radius);border:1px solid var(--line);background:var(--surface-input);color:inherit;transition:border-color .15s ease,box-shadow .15s ease,background-color .15s ease}select:focus-visible,input[type=text]:focus-visible,input[type=file]:focus-visible,input[type=number]:focus-visible,input[type=password]:focus-visible,input[type=url]:focus-visible{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft);outline:none}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}button,a.button{font:inherit;min-height:var(--control-height);border:1px solid var(--line);border-radius:var(--control-radius);padding:7px 13px;background:var(--surface-button);color:inherit;text-decoration:none;cursor:pointer;transition:border-color .15s ease,background-color .15s ease,transform .15s ease}button:hover,a.button:hover,button:focus-visible,a.button:focus-visible{border-color:var(--accent);background:var(--accent-soft);outline:none}.primary{background:linear-gradient(180deg,var(--accent-dark-hover),var(--accent-dark))!important;color:var(--on-primary)!important;border-color:var(--accent-strong)!important;font-weight:700;box-shadow:0 4px 12px var(--shadow)}.primary:hover,.primary:focus-visible{background:linear-gradient(180deg,var(--accent-strong),var(--accent-dark-hover))!important;transform:translateY(-1px)}.danger{border-color:var(--bad)!important;color:var(--bad)!important;font-weight:700}.danger:hover,.danger:focus-visible{background:var(--bad-soft)!important}.hidden{display:none!important}.warning{border-left:4px solid var(--warn);padding:10px 12px;background:var(--warn-soft);margin:12px 0}.success{border-left:4px solid var(--ok);padding:10px 12px}.failure{border-left:4px solid var(--bad);padding:10px 12px}.status{white-space:pre-wrap;font-family:ui-monospace,monospace;font-size:.85rem;max-height:230px;overflow:auto;background:var(--status-bg);padding:12px;border-radius:8px}.device{padding:8px 0;border-bottom:1px solid var(--line)}.device:last-child{border:0}.meta{display:grid;grid-template-columns:max-content 1fr;gap:5px 12px}.meta dt{font-weight:700}.meta dd{margin:0;overflow-wrap:anywhere}small,.muted{font-size:var(--sv-font-small);color:var(--muted)}.topbar{display:flex;align-items:center;gap:12px;margin-bottom:10px}.topbar h1{flex:1}.back-button{padding:8px 12px!important}.device-card{border:1px solid var(--line-soft);border-radius:10px;padding:14px;margin:10px 0;background:var(--surface-inset)}.detected-device-details{padding:0;overflow:hidden}.detected-device-details>summary{display:flex;align-items:center;gap:12px;padding:14px;cursor:pointer;list-style:none}.detected-device-details>summary::-webkit-details-marker{display:none}.detected-device-details>summary::marker{content:""}.detected-device-summary-main{min-width:0;flex:1}.detected-device-summary-side{display:flex;align-items:center;gap:9px;flex:0 0 auto}.detected-device-chevron{font-size:1.05rem;color:var(--muted);transition:transform .12s ease}.detected-device-details[open] .detected-device-chevron{transform:rotate(90deg)}.detected-device-body{border-top:1px solid var(--line-soft);padding:14px}.detected-device-body>.device-card{margin:0;padding:0;border:0;background:transparent}.devices-diagnostics-summary{margin:12px 0}.detected-device-generated{margin-top:5px}.detected-device-extra{margin-top:10px}.device-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap}.device-meta-line{display:flex;align-items:center;gap:4px 14px;flex-wrap:wrap;margin-top:7px;font-size:var(--sv-font-small);color:var(--muted)}.device-meta-line span{white-space:nowrap}.device-meta-line b{font-weight:600;color:var(--text)}.installer-backup-toolbar{align-items:center;margin-top:10px}.installer-backup-summary{margin:8px 0 4px}.installer-backup-list{margin-top:6px}.installer-backup-row{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:8px 12px;padding:7px 10px;margin:6px 0}.installer-backup-line{display:flex;align-items:center;gap:4px 10px;min-width:0;flex-wrap:nowrap;overflow:hidden}.installer-backup-line strong{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.installer-backup-line .muted{white-space:nowrap}.installer-backup-row .actions{margin:0;gap:6px;flex:0 0 auto}@media(max-width:760px){.installer-backup-row{grid-template-columns:1fr}.installer-backup-line{flex-wrap:wrap;overflow:visible}.installer-backup-row .actions{margin-left:0;width:100%}}.badge{display:inline-block;padding:4px 9px;border-radius:999px;font-size:.8rem;font-weight:700;text-transform:capitalize;border:1px solid var(--line)}.badge-confirmed{background:var(--ok-soft);border-color:var(--ok)}.badge-experimental{background:var(--warn-soft);border-color:var(--warn)}.badge-detected{background:var(--neutral-soft)}.validation-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:4px;margin-top:7px}.validation-item{display:flex;justify-content:space-between;align-items:center;gap:6px;border-top:1px solid var(--line);padding:4px 5px 2px}.state-confirmed{color:var(--ok);font-weight:700}.state-pending{color:var(--warn);font-weight:700}.state-not_applicable,.state-unknown{color:var(--muted)}.diag-summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px}.diag-tile{border:1px solid var(--line-soft);border-radius:9px;padding:11px;background:var(--surface-inset)}.diag-value{font-weight:700;font-size:1rem}.diag-list{margin:8px 0 0;padding-left:20px}.diag-good{color:var(--ok)}.diag-warn{color:var(--warn)}.diag-bad{color:var(--bad)}.nav-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin-top:16px}.nav-card{display:flex;flex-direction:column;align-items:flex-start;min-height:150px;text-align:left;padding:16px!important;background:var(--surface-button);border-color:var(--line-soft);transition:border-color .15s ease,background-color .15s ease,transform .15s ease,box-shadow .15s ease;position:relative;overflow:hidden}.nav-card::before{content:"";position:absolute;left:0;top:0;right:0;height:2px;background:linear-gradient(90deg,var(--heading-line),transparent 78%);opacity:.9}.nav-card:hover,.nav-card:focus-visible{border-color:var(--accent-strong);background:var(--surface-hover);outline:none;transform:translateY(-2px);box-shadow:0 10px 24px var(--shadow)}.nav-card.unifi-unavailable{opacity:.48;filter:saturate(.25);cursor:not-allowed;background:var(--surface-inset);border-color:var(--line-soft);transform:none}.nav-card.unifi-unavailable:hover,.nav-card.unifi-unavailable:focus-visible{border-color:var(--line-soft);background:var(--surface-inset);transform:none}.nav-card.unifi-needs-setup{border-color:var(--warn);background:var(--warn-soft)}.nav-card.unifi-needs-setup:hover,.nav-card.unifi-needs-setup:focus-visible{border-color:var(--warn);background:var(--warn-soft)}.nav-card.unifi-warning{border-color:var(--warn);background:var(--warn-soft)}.unifi-card-state{display:inline-flex;margin-top:auto;padding-top:10px;font-size:var(--sv-font-small);font-weight:700;color:var(--muted)}.nav-card b{font-size:1rem;margin-bottom:7px;color:var(--heading)}.nav-points{display:block;margin:0;padding-left:18px;color:var(--muted);font-size:var(--sv-font-small);line-height:1.35}.nav-points span{display:list-item}.nav-points span+span{margin-top:4px}.home-status{display:flex;align-items:center;gap:10px;font-size:1rem}.status-dot{width:11px;height:11px;border-radius:50%;background:var(--ok);display:inline-block}.status-dot.running{background:var(--accent)}.status-dot.failed{background:var(--bad)}.steps{display:grid;gap:8px;margin:16px 0}.step{display:flex;gap:10px;align-items:center;border:1px solid var(--line);border-radius:9px;padding:10px 12px}.step-mark{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;border:1px solid var(--line);font-size:.8rem;font-weight:700}.step.active{border-color:var(--accent)}.step.active .step-mark{background:var(--accent);color:var(--on-accent)}.step.done .step-mark{background:var(--ok);color:var(--on-accent);border-color:var(--ok)}details.advanced{margin-top:14px;border-top:1px solid var(--line);padding-top:12px}details.advanced summary{cursor:pointer;font-weight:600}.page-title{margin-bottom:0}.simple-result{display:flex;justify-content:space-between;gap:12px;align-items:center;border:1px solid var(--line-soft);border-radius:10px;padding:14px;margin:10px 0;background:var(--surface-inset)}.simple-result .result-main{min-width:0}.simple-result .result-actions{flex-shrink:0}.live-status{display:grid;grid-template-columns:max-content 1fr;gap:7px 14px;border:1px solid var(--line-soft);border-radius:10px;padding:14px;margin:14px 0;background:var(--surface-inset)}.live-status dt{font-weight:700}.live-status dd{margin:0;overflow-wrap:anywhere}.command-line{font-family:ui-monospace,monospace;font-size:.84rem;background:var(--status-bg);padding:8px;border-radius:7px}.debug-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:14px}.debug-panel{margin-top:10px;max-height:420px}.elapsed{font-variant-numeric:tabular-nums}.generated-card-manager summary{width:100%;box-sizing:border-box}
.yaml-manager{border:1px solid var(--line-soft);border-radius:10px;padding:14px;margin-top:18px;background:var(--surface-inset)}.yaml-manager summary{cursor:pointer;font-size:1rem;display:flex;align-items:center;gap:8px;list-style:none;width:100%;box-sizing:border-box}.yaml-manager summary::-webkit-details-marker{display:none}.yaml-manager summary::marker{content:""}.yaml-manager summary::after{content:"▸";margin-left:auto;flex:0 0 auto;transition:transform .12s ease}.yaml-manager[open] summary::after{transform:rotate(90deg)}.yaml-manager[open] summary{margin-bottom:10px}.generated-card-manager{border:1px solid var(--line-soft);border-radius:10px;padding:14px;margin-top:18px;background:var(--surface-inset)}.yaml-state{display:grid;grid-template-columns:max-content 1fr;gap:6px 12px;margin-top:12px}.yaml-state dt{font-weight:700}.yaml-state dd{margin:0;overflow-wrap:anywhere}.code-preview{max-height:360px;overflow:auto;white-space:pre;font-family:ui-monospace,monospace;font-size:.82rem;background:var(--code-bg);padding:12px;border-radius:8px}

/* User-selectable UI preferences supplied by the Switch Vision integration.
   Body font size is an explicit 10-20 px value applied inline by the server. */
body.width-standard main{max-width:none;width:64%}
body.width-standard_plus main{max-width:none;width:68%}
body.width-wide main{max-width:none;width:72%}
body.width-wide_plus main{max-width:none;width:76%}
body.width-extra_wide main{max-width:none;width:80%}
body.width-extra_wide_plus main{max-width:none;width:84%}
body.width-ultra_wide main{max-width:none;width:88%}
body.width-ultra_wide_plus main{max-width:none;width:92%}
body.width-max_wide main{max-width:none;width:96%}
body.width-full main{max-width:none;width:100%}
body.density-spacious{padding:30px}
body.density-spacious .card{padding:22px;margin:22px 0}
body.density-spacious .grid{gap:14px 20px}
body.density-spacious .nav-grid{gap:16px;margin-top:20px}
body.density-spacious .nav-card{min-height:168px;padding:20px!important}
body.density-spacious .actions{gap:12px;margin-top:16px}
body.density-spacious .device-card,body.density-spacious .simple-result,body.density-spacious .live-status{padding:16px;margin:12px 0}
body.density-comfortable{padding:22px}
body.density-comfortable .card{padding:18px;margin:18px 0}
body.density-comfortable .nav-grid{gap:12px;margin-top:16px}
body.density-comfortable .nav-card{min-height:150px;padding:16px!important}
body.density-compact{padding:12px}
body.density-compact .card{padding:14px;margin:12px 0}
body.density-compact .grid{gap:8px 14px}
body.density-compact .nav-grid{gap:8px;margin-top:12px}
body.density-compact .nav-card{min-height:132px;padding:12px!important}
body.density-compact .actions{gap:8px;margin-top:12px}
body.density-compact .device-card,body.density-compact .simple-result,body.density-compact .live-status{padding:12px;margin:8px 0}
body.density-compact .diag-summary{gap:8px}
body.density-compact .diag-tile{padding:10px}
body.density-dense{padding:8px}
body.density-dense .card{padding:10px;margin:8px 0}
body.density-dense .grid{gap:6px 10px}
body.density-dense .field{gap:4px;margin:7px 0}
body.density-dense .option{gap:7px;padding:3px 0}
body.density-dense .actions{gap:6px;margin-top:8px}
body.density-dense button,body.density-dense a.button{padding:8px 11px}
body.density-dense .nav-grid{gap:6px;margin-top:8px}
body.density-dense .nav-card{min-height:112px;padding:9px!important}
body.density-dense .device-card,body.density-dense .simple-result,body.density-dense .live-status{padding:9px;margin:6px 0}
body.density-dense .diag-summary{gap:6px}
body.density-dense .diag-tile{padding:8px}
body.density-dense .steps{gap:5px;margin:8px 0}
body.density-dense .step{padding:7px 9px}
body.density-ultra_dense{padding:4px}
body.density-ultra_dense .card{padding:7px;margin:5px 0}
body.density-ultra_dense .grid{gap:4px 7px}
body.density-ultra_dense .field{gap:3px;margin:5px 0}
body.density-ultra_dense .option{gap:5px;padding:2px 0}
body.density-ultra_dense .actions{gap:4px;margin-top:5px}
body.density-ultra_dense button,body.density-ultra_dense a.button{padding:6px 9px}
body.density-ultra_dense .nav-grid{gap:4px;margin-top:5px}
body.density-ultra_dense .nav-card{min-height:96px;padding:7px!important}
body.density-ultra_dense .device-card,body.density-ultra_dense .simple-result,body.density-ultra_dense .live-status{padding:7px;margin:4px 0}
body.density-ultra_dense .diag-summary{gap:4px}
body.density-ultra_dense .diag-tile{padding:6px}
body.density-ultra_dense .steps{gap:3px;margin:5px 0}
body.density-ultra_dense .step{padding:5px 7px}
.topbar-tools{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:wrap}.theme-picker{display:flex;align-items:center;gap:7px;height:36px;padding:0 0 0 10px;border:1px solid var(--line-soft);border-radius:9px;background:var(--surface-button);color:var(--muted);font-size:var(--sv-font-small);font-weight:700;white-space:nowrap}.theme-picker select{height:34px;min-width:150px;margin:-1px -1px -1px 0;padding:7px 10px;border-radius:0 9px 9px 0;border-color:var(--line-soft);background:var(--surface-input);color:var(--text);font-weight:600}.theme-picker select:focus-visible{border-color:var(--accent);outline:none}.topbar-theme-label{pointer-events:none}@media(max-width:760px){.topbar{flex-wrap:wrap}.topbar h1{min-width:180px}.topbar-tools{width:100%;justify-content:flex-end}.theme-picker select{min-width:132px}}
.unifi-test-actions{align-items:center}.unifi-test-inline-status{min-height:1.3em}.unifi-test-pass{color:var(--ok)!important}.unifi-test-fail{color:var(--bad)!important}.unifi-test-debug summary{display:flex;justify-content:space-between;gap:12px;align-items:center}.unifi-test-debug pre{display:block!important;max-height:280px;overflow:auto;white-space:pre-wrap;word-break:break-word}.secret-control{display:grid;grid-template-columns:minmax(0,1fr) 42px;gap:6px;align-items:center;width:100%}.secret-control>input{width:100%;min-width:0}.secret-eye{width:42px;min-width:42px!important;padding:6px 8px!important;font-size:1rem;line-height:1}.secret-eye[aria-pressed="true"]{border-color:var(--accent);background:var(--accent-soft)}.secret-eye:disabled{cursor:not-allowed;opacity:.45}.unified-device-details.disabled{opacity:.62}.unified-device-details{padding:0;overflow:hidden}.unified-device-row{display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:10px;padding:0 10px}.unified-device-summary{display:flex;align-items:center;gap:10px;min-width:0;cursor:pointer}.unified-device-main{min-width:0;flex:1}.unified-device-actions{display:flex;align-items:center;gap:8px;flex:0 0 auto}.unified-device-actions button{min-width:38px;padding:7px 10px}.device-order-controls{display:flex;align-items:center;gap:6px;flex:0 0 auto}.device-order-controls button{min-width:38px;padding:7px 10px}.unified-device-chevron{font-size:1.05rem;color:var(--muted);transition:transform .12s ease}.unified-device-details[data-expanded="true"] .unified-device-chevron{transform:rotate(90deg)}.unified-device-body{border-top:1px solid var(--line-soft);padding:14px}.unified-device-body[hidden]{display:none!important}.unified-device-body>.device-card{margin:0;padding:0;border:0;background:transparent}.device-source-chip{display:inline-flex;align-items:center;padding:4px 8px;border:1px solid var(--line);border-radius:999px;font-size:var(--sv-font-small);font-weight:700;color:var(--muted);white-space:nowrap}.device-state-toggle{display:inline-flex;align-items:center;gap:8px;min-width:118px;justify-content:center;padding:8px 11px!important;font-weight:700}.device-state-toggle .toggle-track{position:relative;display:inline-block;width:34px;height:18px;border-radius:999px;background:var(--line);transition:background-color .15s ease}.device-state-toggle .toggle-knob{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;background:var(--surface-input);transition:transform .15s ease}.device-state-toggle.enabled{border-color:var(--ok);background:var(--ok-soft)}.device-state-toggle.enabled .toggle-track{background:var(--ok)}.device-state-toggle.enabled .toggle-knob{transform:translateX(16px)}.device-state-toggle.disabled{border-color:var(--line);background:var(--surface-button)}.device-state-toggle:disabled{cursor:not-allowed;opacity:.55}.configured-device-note{margin:4px 0 12px}.configured-device-status{min-height:1.25em}@media(max-width:760px){.unified-device-row{grid-template-columns:auto minmax(0,1fr);gap:6px 8px}.unified-device-summary{align-items:flex-start}.unified-device-actions{grid-column:1/-1;justify-content:flex-end;padding-bottom:6px}.device-order-controls{align-self:flex-start}}.sponsor-chip{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border:1px solid var(--line-soft);border-radius:999px;background:var(--chip-bg);color:var(--text);text-decoration:none;font-size:.92rem;font-weight:700;white-space:nowrap}.sponsor-chip:hover{background:var(--chip-hover)}.sponsor-chip .heart{font-size:1rem;line-height:1;color:var(--heart)}
.hub-motd{margin:0 0 14px;padding:12px 14px;border:1px solid var(--line-soft);border-radius:10px;background:linear-gradient(90deg,var(--accent-soft),var(--surface-inset) 72%);box-shadow:inset 0 1px 0 var(--heading-soft)}.hub-motd-header{display:flex;align-items:center;justify-content:space-between;gap:12px}.hub-motd-heading{display:flex;align-items:baseline;gap:9px;min-width:0;flex-wrap:wrap}.hub-motd-heading strong{color:var(--heading-strong)}.hub-motd-heading span{font-size:var(--sv-font-small)}.hub-motd-toggle{flex:0 0 auto;padding:6px 10px!important;min-height:32px!important}.hub-motd-body{margin-top:7px}.hub-motd-body p{margin:0;line-height:1.45}.hub-motd-body[hidden]{display:none!important}.hub-motd.is-collapsed{padding-top:9px;padding-bottom:9px}@media(max-width:600px){.hub-motd-header{align-items:flex-start}.hub-motd-heading{display:grid;gap:2px}}
#creditsCard{position:relative;overflow:hidden;isolation:isolate;border-color:rgba(69,207,255,.38);box-shadow:0 0 0 1px rgba(67,205,255,.06),0 16px 42px -34px rgba(55,210,255,.9);transition:border-color .28s ease,box-shadow .28s ease,transform .28s ease}
#creditsCard::before{content:"";position:absolute;inset:-45%;z-index:0;background:conic-gradient(from 0deg,transparent 0 38%,rgba(54,209,255,.02) 44%,rgba(74,226,255,.85) 49%,rgba(148,242,255,.25) 53%,transparent 59% 100%);opacity:0;animation:credits-edge-orbit 7s linear infinite;pointer-events:none}
#creditsCard::after{content:"";position:absolute;inset:1px;z-index:0;border-radius:inherit;background:linear-gradient(180deg,rgba(4,22,34,.28),rgba(2,13,22,.1)),radial-gradient(circle at 20% 30%,rgba(68,213,255,.08) 0 1px,transparent 1.6px),radial-gradient(circle at 72% 68%,rgba(111,238,255,.06) 0 1px,transparent 1.7px),linear-gradient(90deg,transparent 0 49.7%,rgba(72,213,255,.035) 49.9% 50.1%,transparent 50.3% 100%);background-size:auto,64px 64px,88px 88px,120px 120px;opacity:0;pointer-events:none}
#creditsCard.credits-settled::before{opacity:.72}
#creditsCard.credits-settled::after{opacity:1;animation:credits-circuit-drift 18s linear infinite}
#creditsCard.credits-settled{border-color:rgba(69,207,255,.68);box-shadow:0 0 18px rgba(46,205,255,.12),0 18px 48px -34px rgba(51,218,255,.9)}
#creditsMatrix{position:absolute;inset:0;width:100%;height:100%;z-index:7;pointer-events:none;opacity:0;transition:opacity .55s ease}
#creditsCard.credits-matrix-active #creditsMatrix{opacity:1}
.credits-content{position:relative;z-index:2}
.credits-energy{position:absolute;inset:-35% -70%;z-index:1;pointer-events:none;background:linear-gradient(115deg,transparent 42%,rgba(115,240,255,.02) 47%,rgba(115,240,255,.18) 50%,rgba(115,240,255,.025) 53%,transparent 58%);transform:translateX(-48%);opacity:0}
#creditsCard.credits-settled .credits-energy{opacity:1;animation:credits-energy-sweep 7.5s ease-in-out 2.8s infinite}
.credits-title,.credits-thanks,.credits-test-badge,.credit-entry{opacity:0;transform:translateY(12px);filter:blur(5px);transition:opacity .5s ease,transform .5s ease,filter .5s ease}
#creditsCard.credits-settled .credits-title{opacity:1;transform:none;filter:none;transition-delay:.08s;animation:credits-heading-breathe 4.8s ease-in-out 1.2s infinite}
#creditsCard.credits-settled .credits-thanks{opacity:1;transform:none;filter:none;transition-delay:.25s}
#creditsCard.credits-settled .credits-test-badge{opacity:1;transform:none;filter:none;transition-delay:.42s}
#creditsCard.credits-settled .credit-entry{opacity:1;transform:none;filter:none;transition-delay:calc(.52s + var(--credit-index,0)*.14s)}
.credits-test-badge{display:inline-flex;margin:8px 0 10px;padding:4px 8px;border:1px solid rgba(86,218,255,.28);border-radius:999px;color:var(--muted);font-size:.78rem;font-weight:750;letter-spacing:.045em;background:rgba(29,141,184,.08)}
#creditsList{display:grid;gap:8px;position:relative;overflow:hidden}
.credit-entry{display:flex;justify-content:space-between;align-items:center;gap:18px;padding:10px 12px;border:1px solid var(--line-soft);border-radius:9px;background:linear-gradient(90deg,rgba(58,205,255,.035),transparent 52%);transition:transform .22s ease,border-color .22s ease,box-shadow .22s ease,background .22s ease,opacity .5s ease,filter .5s ease}
.credit-entry:hover,.credit-entry:focus-within{transform:translateY(-3px);border-color:rgba(76,220,255,.58);box-shadow:0 7px 24px -15px rgba(57,221,255,.88);background:linear-gradient(90deg,rgba(64,210,255,.09),transparent 68%)}
.credit-name{font-weight:780;color:var(--heading-strong);background:linear-gradient(100deg,var(--heading-strong) 0 40%,#d7fbff 48%,var(--heading-strong) 56% 100%);background-size:240% 100%;background-position:100% 0;background-clip:text;-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.credit-entry:hover .credit-name{animation:credits-name-shimmer 1.15s ease}
.credit-components{color:var(--muted);text-align:right}
@keyframes credits-edge-orbit{to{transform:rotate(360deg)}}
@keyframes credits-circuit-drift{0%{background-position:0 0,0 0,0 0,0 0}100%{background-position:0 0,64px 32px,-88px 44px,120px 60px}}
@keyframes credits-energy-sweep{0%,72%,100%{transform:translateX(-48%);opacity:0}78%{opacity:.9}88%{transform:translateX(48%);opacity:.2}}
@keyframes credits-heading-breathe{0%,100%{text-shadow:0 0 0 transparent}50%{text-shadow:0 0 16px rgba(84,226,255,.42)}}
@keyframes credits-name-shimmer{from{background-position:100% 0}to{background-position:-110% 0}}
@media(max-width:700px){.credit-entry{align-items:flex-start;flex-direction:column;gap:3px}.credit-components{text-align:left}}
@media(prefers-reduced-motion:reduce){#creditsCard::before,#creditsCard::after,#creditsCard .credits-energy,.credits-title,.credits-thanks,.credits-test-badge,.credit-entry,.credit-entry:hover .credit-name{animation:none!important;transition:none!important}.credits-title,.credits-thanks,.credits-test-badge,.credit-entry{opacity:1!important;transform:none!important;filter:none!important}#creditsMatrix{display:none!important}}

/* Device rows intentionally use a tighter list rhythm than general Hub cards. */
.unified-device-details{margin:5px 0!important}
.unified-device-summary{padding:7px 0!important}
.unified-device-body{padding:10px!important}
body.density-spacious .unified-device-summary{padding:9px 0!important}
body.density-compact .unified-device-summary{padding:6px 0!important}
body.density-dense .unified-device-summary{padding:5px 0!important}
body.density-ultra_dense .unified-device-summary{padding:4px 0!important}
</style>
<link rel="stylesheet" href="credits_v25.css">
</head>
<body><main>
<div class="topbar"><button id="backButton" class="back-button" type="button">← Back to Home Assistant</button><h1 id="pageHeading" class="page-title">Switch Vision Hub</h1><div class="topbar-tools"><label class="theme-picker" title="Management UI theme. Switch dashboards are not affected."><span class="topbar-theme-label">Theme</span><select id="themeSelect" aria-label="Management UI theme"><option value="switch-vision">Switch Vision</option><option value="cisco-classic">Cisco Classic</option><option value="cisco-nexus">Cisco Nexus</option><option value="unifi">UniFi</option></select></label><a class="sponsor-chip" href="https://github.com/sponsors/zemerdon" target="_blank" rel="noopener noreferrer" title="Support Switch Vision on GitHub Sponsors"><span class="heart">♥</span><span>Sponsor</span></a></div></div>
<p id="pageLead" class="lead hidden"></p>

<section id="homeCard" class="card">
<div class="home-status"><span id="homeStatusDot" class="status-dot"></span><strong id="homeStatus">Ready</strong></div>
<p class="muted">The Web UI stays available while Discovery is idle, running, or complete.</p>
<div id="hubMotd" class="hub-motd" role="region" aria-labelledby="hubMotdTitle">
<div class="hub-motd-header"><div class="hub-motd-heading"><strong id="hubMotdTitle">Message of the Day</strong><span class="muted">Current Hub notice</span></div><button id="hubMotdToggle" class="hub-motd-toggle" type="button" data-action="toggle-motd-visibility" aria-expanded="true" aria-controls="hubMotdBody" aria-label="Hide Message of the Day">Hide</button></div>
<div id="hubMotdBody" class="hub-motd-body"><p id="hubMotdMessage">__SV_HUB_MOTD__</p></div>
</div>
<div class="nav-grid">
<button id="openDiscoveryButton" class="nav-card" type="button"><b>Discovery</b><span class="nav-points"><span>SNMP Walk</span><span>Generate Native Dashboard YAML</span><span>Generate SNMP2MQTT YAML</span></span></button>
<button id="openDevicesButton" class="nav-card" type="button"><b>Devices</b><span class="nav-points"><span>Add / Remove Devices</span><span>Show Detected Devices &amp; Status</span><span>Enable / Disable Devices</span><span>Reorder Switches</span></span></button>
<button id="openSupportButton" class="nav-card" type="button"><b>Support My Switch</b><span class="nav-points"><span>Create Contribution Package to Add / Increase Support for Your Switch</span></span></button>
<button id="openMaintenanceButton" class="nav-card" type="button"><b>Maintenance</b><span class="nav-points"><span>Backups</span><span>SNMP Maintenance</span><span>Configuration Import / Export</span><span>Calibration Profiles</span></span></button>
</div>
<div class="nav-grid" style="margin-top:12px">
<button id="openIntegrationSettingsButton" class="nav-card" type="button"><b>Switch Vision Settings</b><span class="nav-points"><span>UI Settings</span><span>Discovery Settings</span><span>SNMP2MQTT Settings</span></span></button>
<button id="openUnifi2mqttSettingsButton" class="nav-card unifi-unavailable" type="button" aria-disabled="true" title="UniFi2MQTT status is being checked."><b>UniFi2MQTT Settings</b><span class="nav-points"><span>UniFi controller API</span><span>MQTT connection</span><span>App &amp; snapshot status</span></span><span id="unifiHomeCardState" class="unifi-card-state">Checking…</span></button>
<button id="openCreditsButton" class="nav-card" type="button"><b>Credits</b><span class="nav-points"><span>Switch Vision is made better by the people who contribute their time, testing, feedback, and knowledge. Thank you to everyone below for helping shape what it is today.</span></span></button>
</div>
</section>

<section id="creditsCard" class="card hidden" aria-live="polite">
<canvas id="creditsMatrix" aria-hidden="true"></canvas>
<div class="credits-spot-soft" aria-hidden="true"></div>
<div class="credits-spot-narrow" aria-hidden="true"></div>
<div id="creditsSweepLight" class="credits-sweep-light" aria-hidden="true"></div>
<div id="creditsContent" class="credits-content credits-roll-mask">
<div id="creditsRollTrack" class="credits-roll-track">
<div id="creditsBuildSource" class="credits-roll-block">
<h2 class="credits-title">Switch Vision Credits</h2>
<div id="creditsList" class="credits-list-v25">
<div class="credit-entry"><span class="credit-name">Finni</span><span class="credit-components">Discovery / Hub • UniFi2MQTT</span></div>
<div class="credit-entry"><span class="credit-name">Paul B</span><span class="credit-components">Discovery / Hub • SNMP2MQTT • Support My Switch</span></div>
<div class="credit-entry"><span class="credit-name">Timb320</span><span class="credit-components">Core • Discovery / Hub • UniFi2MQTT</span></div>
<div class="credit-entry"><span class="credit-name">Brendan P</span><span class="credit-components">Discovery / Hub • UniFi2MQTT • Support My Switch</span></div>
<div class="credit-entry"><span class="credit-name">iangr</span><span class="credit-components">Core • Discovery / Hub • UniFi2MQTT • Support My Switch</span></div>
</div>
</div>
<div class="credits-roll-block" aria-hidden="true">
<h2 class="credits-title">Switch Vision Credits</h2>
<div class="credits-list-v25">
<div class="credit-entry"><span class="credit-name">Finni</span><span class="credit-components">Discovery / Hub • UniFi2MQTT</span></div>
<div class="credit-entry"><span class="credit-name">Paul B</span><span class="credit-components">Discovery / Hub • SNMP2MQTT • Support My Switch</span></div>
<div class="credit-entry"><span class="credit-name">Timb320</span><span class="credit-components">Core • Discovery / Hub • UniFi2MQTT</span></div>
<div class="credit-entry"><span class="credit-name">Brendan P</span><span class="credit-components">Discovery / Hub • UniFi2MQTT • Support My Switch</span></div>
<div class="credit-entry"><span class="credit-name">iangr</span><span class="credit-components">Core • Discovery / Hub • UniFi2MQTT • Support My Switch</span></div>
</div>
</div>
</div>
</div>
<div class="credits-progress" aria-hidden="true"><span id="creditsProgress"></span></div>
</section>

<section id="unifi2mqttCard" class="card hidden">
<h2>UniFi2MQTT Settings</h2>
<p class="lead">Configure Local UniFi and UniFi Site Manager access independently. Keep both configured, choose the priority path, and optionally fall back automatically when the priority path is unavailable.</p>
<div id="unifiStatusGrid" class="diag-summary"></div>
<div id="unifiInstallWrap" class="warning hidden"><b>UniFi2MQTT is not installed.</b><div class="actions"><button id="installUnifi2mqttButton" class="primary" type="button">Install UniFi2MQTT</button></div><p id="unifiInstallStatus" class="muted"></p></div>
<div id="unifiSettingsForm">
<h3>Connection priority &amp; polling</h3>
<div class="grid">
<label class="field"><span><b>Priority connection</b></span><select id="unifi_priority_transport" title="The connection Switch Vision tries first on every poll."><option value="local">Local</option><option value="remote">Remote / Site Manager</option></select><small>The priority path is retried every poll, so Switch Vision automatically returns to it after recovery.</small></label>
<label class="field"><span><b>Fallback connection</b></span><select id="unifi_fallback_transport" title="Used only when the priority connection fails."><option value="remote">Remote / Site Manager</option><option value="local">Local</option><option value="none">None</option></select><small>Choose None to disable automatic failover.</small></label>
<label class="field"><span><b>Poll interval (seconds)</b></span><input id="unifi_poll_interval" type="number" min="10" max="300" step="1" title="How often UniFi2MQTT refreshes device state. Minimum 10 seconds."></label>
</div>
<h3>Local UniFi controller</h3>
<div class="grid">
<label class="field"><span><b>Local controller URL</b></span><input id="unifi_local_controller_url" type="url" maxlength="512" placeholder="https://192.168.1.1:11443" title="Address of the local UniFi Network Integration API."><small><b>Self-hosted UniFi controllers normally use HTTPS port 11443.</b> Example: <code>https://192.168.1.1:11443</code>.</small></label>
<label class="field"><span><b>Local site ID</b></span><input id="unifi_local_site_id" type="text" maxlength="256" placeholder="auto" title="Use auto unless you need to select a specific local UniFi Network site."><small><code>auto</code> resolves the appropriate Network site automatically.</small></label>
<label class="field"><span><b>Local Integration API Key</b></span><input id="unifi_local_api_key" type="password" maxlength="4096" autocomplete="new-password" placeholder="Leave blank to keep the current key" title="Read-only API key created on the local UniFi controller."><small id="unifiLocalApiKeyState">Not configured</small></label>
<label class="option"><input id="unifi_local_verify_ssl" type="checkbox" title="Verify the local controller TLS certificate."><span><b>Verify local SSL</b><br><small>Enable for a trusted local certificate.</small></span></label>
<label class="option"><input id="unifi_local_allow_insecure_http" type="checkbox" title="Explicitly permit plaintext HTTP for a local controller. HTTPS is strongly preferred."><span><b>Allow insecure local HTTP</b><br><small>Only enable when you deliberately accept an unencrypted local API-key connection.</small></span></label>
</div>
<div class="actions unifi-test-actions"><button id="testUnifiLocalButton" type="button" title="Test the Local UniFi Integration API using the values currently shown above. This does not save settings.">Test Local Connection</button><span id="unifiLocalTestStatus" class="muted unifi-test-inline-status">Not tested</span></div>
<h3>Remote / UniFi Site Manager</h3>
<div class="grid">
<label class="field"><span><b>Remote host ID</b></span><input id="unifi_remote_host_id" type="text" maxlength="256" placeholder="auto" title="Site Manager console host ID. Use auto when only one suitable host exists."><small><code>auto</code> discovers the Site Manager host when unambiguous.</small></label>
<label class="field"><span><b>Remote site ID</b></span><input id="unifi_remote_site_id" type="text" maxlength="256" placeholder="auto" title="Network Integration site selector behind the Site Manager connector."><small>This is the Network Integration site, not the separate Site Manager /v1/sites identifier.</small></label>
<label class="field"><span><b>UniFi Site Manager API Key</b></span><input id="unifi_remote_api_key" type="password" maxlength="4096" autocomplete="new-password" placeholder="Leave blank to keep the current key" title="API key used with the official UniFi Site Manager connector."><small id="unifiRemoteApiKeyState">Not configured</small></label>
</div>
<div class="actions unifi-test-actions"><button id="testUnifiRemoteButton" type="button" title="Test the Remote UniFi Site Manager path using the values currently shown above. This does not save settings.">Test Remote Connection</button><span id="unifiRemoteTestStatus" class="muted unifi-test-inline-status">Not tested</span></div>
<p class="muted">Remote access always uses verified HTTPS to the official Site Manager API. Username/password authentication is not used.</p>
<h3>Additional controllers / sites</h3>
<p class="muted">Optional multi-controller mode. Each row has its own Local or Remote transport and API key. When rows are present, they are polled concurrently and take precedence over the single Local/Remote profile above.</p>
<div id="unifiControllersRoot"></div>
<div class="actions"><button id="addUnifiControllerButton" type="button" title="Add another UniFi controller or site to this UniFi2MQTT instance.">Add controller</button></div>
<h3>MQTT</h3>
<div class="grid">
<label class="field"><span><b>MQTT host</b></span><input id="unifi_mqtt_host" type="text" maxlength="255" title="MQTT broker hostname used by UniFi2MQTT. core-mosquitto uses the Home Assistant MQTT service."></label>
<label class="field"><span><b>MQTT port</b></span><input id="unifi_mqtt_port" type="number" min="1" max="65535" step="1" title="MQTT broker TCP port."></label>
<label class="field"><span><b>MQTT username</b></span><input id="unifi_mqtt_username" type="text" maxlength="256" autocomplete="username" title="Optional MQTT username. Supervisor MQTT credentials are used automatically with core-mosquitto."></label>
<label class="field"><span><b>MQTT password</b></span><input id="unifi_mqtt_password" type="password" maxlength="4096" autocomplete="new-password" placeholder="Leave blank to keep the current password" title="Optional MQTT password. Saved values stay masked unless you click the eye to reveal them."><small id="unifiMqttPasswordState">Not configured</small></label>
<label class="option"><input id="unifi_mqtt_tls" type="checkbox" title="Enable TLS for an explicitly configured MQTT broker."><span><b>MQTT TLS</b><br><small>Usually not required for the Supervisor-provided local broker.</small></span></label>
<label class="option"><input id="unifi_mqtt_verify_ssl" type="checkbox" title="Verify the MQTT broker certificate when MQTT TLS is enabled."><span><b>Verify MQTT SSL</b></span></label>
<label class="field"><span><b>MQTT CA file</b></span><input id="unifi_mqtt_ca" type="text" maxlength="512" placeholder="/ssl/ca.pem" title="Optional CA certificate below /ssl for MQTT TLS verification."></label>
<label class="field"><span><b>MQTT topic prefix</b></span><input id="unifi_mqtt_topic_prefix" type="text" maxlength="256" title="Base MQTT topic used for Switch Vision UniFi state."></label>
<label class="field"><span><b>MQTT discovery prefix</b></span><input id="unifi_mqtt_discovery_prefix" type="text" maxlength="256" title="Home Assistant MQTT Discovery prefix, normally homeassistant."></label>
</div>
<div class="actions"><button id="saveUnifi2mqttButton" class="primary" type="button" title="Save all UniFi2MQTT settings and restart/start the app when needed.">Save UniFi2MQTT Settings</button><button id="openUnifiAppConfigButton" type="button" title="Open the native Home Assistant app configuration as a fallback editor.">Open Home Assistant App Configuration</button></div>
<p id="unifiSettingsStatus" class="muted">Saved credentials are masked by default. Use the eye to reveal one on demand; blank API-key and password fields preserve stored values.</p>
<details id="unifiConnectionTestDebug" class="yaml-manager unifi-test-debug">
<summary><strong>Connection Test Debug</strong><span id="unifiConnectionTestDebugSummary" class="muted">Not tested</span></summary>
<p class="muted">Current-session Local/Remote connection-test trace. Credentials are never written here.</p>
<pre id="unifiConnectionTestDebugLog" class="code-preview">No connection tests have been run in this session.</pre>
<div class="actions"><button id="clearUnifiConnectionTestDebugButton" type="button">Clear Debug</button></div>
</details>
</div>
</section>

<section id="maintenanceCard" class="card hidden">
<h2>Maintenance</h2>
<p class="lead">Manage Switch Vision backups, SNMP repair/reset operations, configuration transfer, calibration profiles, and full reset actions from one place.</p>
<div class="maintenance-tabs" role="tablist" aria-label="Maintenance sections">
<button id="maintenanceTabButton-backups" class="maintenance-tab is-active" type="button" role="tab" aria-selected="true" aria-controls="maintenancePanel-backups" data-maintenance-tab="backups">Backups</button>
<button id="maintenanceTabButton-snmp" class="maintenance-tab" type="button" role="tab" aria-selected="false" aria-controls="maintenancePanel-snmp" data-maintenance-tab="snmp">SNMP</button>
<button id="maintenanceTabButton-configuration" class="maintenance-tab" type="button" role="tab" aria-selected="false" aria-controls="maintenancePanel-configuration" data-maintenance-tab="configuration">Configuration Import / Export</button>
<button id="maintenanceTabButton-calibrations" class="maintenance-tab" type="button" role="tab" aria-selected="false" aria-controls="maintenancePanel-calibrations" data-maintenance-tab="calibrations">Calibration Profiles</button>
<button id="maintenanceTabButton-reset" class="maintenance-tab" type="button" role="tab" aria-selected="false" aria-controls="maintenancePanel-reset" data-maintenance-tab="reset">Reset</button>
</div>

<section id="maintenancePanel-backups" class="maintenance-pane" role="tabpanel" aria-labelledby="maintenanceTabButton-backups">
<h3>Installer Recovery Backups</h3>
<p>Manage the full Switch Vision recovery backups created by Installer. These remain separate from Discovery configuration snapshots and portable configuration exports.</p>
<div class="warning"><b>Private boundary preserved:</b> Recovery files stay inside Installer-owned <code>/data/switch-vision-backups</code>. Maintenance receives only sanitized metadata and sends narrow commands through Home Assistant Supervisor; backup files, saved option payloads and credentials are never exposed here.</div>
<div class="actions installer-backup-toolbar"><button id="installerBackupAutomaticRetention" type="button" aria-pressed="false">Automatic retention: Off</button><button id="createInstallerBackupButton" type="button">Create Backup</button><button id="refreshInstallerBackupsButton" type="button">Refresh</button></div>
<div id="installerBackupSummary" class="installer-backup-summary muted">0 retained backups</div>
<p id="installerBackupStatus" class="muted">Loading Installer recovery backups…</p>
<div id="installerBackupList" class="installer-backup-list"></div>
<hr style="border:0;border-top:1px solid var(--line);margin:22px 0">
<h3>Discovery Configuration Backups</h3>
<p>Control automatic retention for the smaller Discovery configuration snapshots created before protected Discovery mutations.</p>
<div id="maintenanceDiscoveryBackupSettings"></div>
<div class="actions"><button id="maintenanceBackupSettingsSave" class="primary" type="button" disabled>Save Backup Settings</button><button id="maintenanceBackupSettingsReload" type="button">Reload Backup Settings</button></div>
<p id="maintenanceBackupSettingsStatus" class="muted">Backup settings have not been loaded yet.</p>
</section>

<section id="maintenancePanel-snmp" class="maintenance-pane" role="tabpanel" aria-labelledby="maintenanceTabButton-snmp" hidden>
<h3>Repair MQTT Entities</h3>
<p>Scan retained Home Assistant MQTT Discovery entries and compare them with the current generated SNMP2MQTT YAML. Only retained entries that prove Switch Vision SNMP2MQTT ownership through their topic, origin, IDs and state-topic contract are eligible for repair.</p>
<div class="warning"><b>Safe scope:</b> Scan is read-only. Repair never performs a broker-wide wipe and never edits Home Assistant <code>.storage</code>. A current valid generated SNMP2MQTT YAML is required so Switch Vision can distinguish current entities from historical ghosts.</div>
<div id="mqttRepairSummary" class="diag-summary"></div>
<div id="mqttRepairEntities"></div>
<div class="actions"><button id="scanMqttEntitiesButton" class="primary" type="button">Scan MQTT Entities</button><button id="exportMqttResultsButton" type="button" disabled>Export Results</button><button id="repairMqttEntitiesButton" type="button" disabled>Repair Stale MQTT Entities</button></div>
<p id="mqttRepairStatus" class="muted">Run a scan to check for historical Switch Vision MQTT entities.</p>
<hr style="border:0;border-top:1px solid var(--line);margin:22px 0">
<h3>Reset SNMP Discovery Data</h3>
<p>Stronger cleanup for retiring SNMP switches or rebuilding the complete SNMP-generated state. It stops Switch Vision SNMP2MQTT, retires the exact retained discovery topics Switch Vision already knows about, deletes saved SNMP walk/capability/generated SNMP data, and clears the generated card. UniFi data and settings are preserved.</p>
<div class="warning"><b>This is more destructive than Repair MQTT Entities.</b> Use Repair first for stale Home Assistant entities. Reset is for a deliberate clean SNMP rebuild.</div>
<div class="actions"><button id="resetSnmpDiscoveryButton" class="danger" type="button">Reset SNMP Discovery Data</button></div>
<p id="resetSnmpDiscoveryStatus" class="muted"></p>
</section>

<section id="maintenancePanel-configuration" class="maintenance-pane" role="tabpanel" aria-labelledby="maintenanceTabButton-configuration" hidden>
<h3>Complete Configuration</h3>
<p>Create one complete, portable Switch Vision backup for a fresh installation. It includes non-secret configuration from every Switch Vision component, device state/order and immutable added-time metadata, calibration profiles, and custom Switch Vision visual assets.</p>
<div class="warning"><b>Credentials are deliberately excluded.</b> SNMP communities, MQTT passwords, UniFi API keys, tokens and other passwords are never written to this file. The backup can still contain network addresses, device names, calibration data and custom images, so keep it private.</div>
<div class="actions"><a id="exportConfigurationButton" class="button primary" href="#">Export Complete Backup</a></div>
<hr style="border:0;border-top:1px solid var(--line);margin:22px 0">
<h3>Switches Only</h3>
<p>Export or import only saved switch definitions and stack-member display mappings. Discovery workflow, paths, privacy settings, component settings, calibration profiles and other configuration are not included. SNMP communities are deliberately excluded and must be re-entered for new switches.</p>
<div class="actions"><a id="exportSwitchesButton" class="button" href="#">Export Switches Only</a></div>
<label class="field"><span><b>Switch configuration file</b></span><input id="switchesConfigurationFile" type="file" accept="application/json,.json"></label>
<div class="actions"><button id="importSwitchesButton" type="button">Import Switches Only</button></div>
<p id="switchesConfigurationStatus" class="muted">No switch configuration imported.</p>
<hr style="border:0;border-top:1px solid var(--line);margin:22px 0">
<h3>Import Configuration</h3>
<p>Select a complete Switch Vision backup or an older Discovery-only configuration export. Complete restore reapplies all available non-secret component settings and restores calibration/assets. Devices/controllers whose credentials were excluded return as pending rows so only the missing credential needs to be entered.</p>
<label class="field"><span><b>Configuration file</b></span><input id="configurationFile" type="file" accept="application/json,.json"></label>
<div class="actions"><button id="importConfigurationButton" type="button">Import Configuration</button></div>
<p id="configurationStatus" class="muted">No configuration imported.</p>
</section>

<section id="maintenancePanel-calibrations" class="maintenance-pane" role="tabpanel" aria-labelledby="maintenanceTabButton-calibrations" hidden>
<h3>Calibration Profiles</h3>
<p class="muted">Manage saved Switch Vision faceplate calibration profiles, transfer profile calibration data, and clean unused profiles.</p>
<div id="calibrationProfilesRoot"></div>
</section>

<section id="maintenancePanel-reset" class="maintenance-pane" role="tabpanel" aria-labelledby="maintenanceTabButton-reset" hidden>
<h3>Reset Everything</h3>
<p>Return Switch Vision mutable settings, generated runtime state, calibration profiles, and Switch Vision-owned retained MQTT state to clean defaults across Core, Discovery, SNMP2MQTT, UniFi2MQTT, and Installer where installed.</p>
<div class="warning"><b>Destructive Switch Vision reset:</b> installed apps remain installed, and recovery backups, Discovery configuration backups, Support My Switch contribution archives, custom faceplates/logos, and protected originals are preserved. SNMP2MQTT and UniFi2MQTT are left stopped so cleared state is not immediately republished. You must type <code>RESET EVERYTHING</code> exactly to continue.</div>
<div class="actions"><button id="resetEverythingButton" class="danger" type="button">Reset Everything</button></div>
<p id="resetEverythingStatus" class="muted"></p>
</section>
</section>

<section id="settingsCard" class="hidden hub-settings-page">
<div class="hub-settings-tabs" role="tablist" aria-label="Switch Vision settings sections">
<button id="hubTab-core" class="hub-settings-tab is-active" type="button" role="tab" aria-selected="true" aria-controls="hubComponent-core" data-hub-settings-tab="core">UI Settings</button>
<button id="hubTab-discovery" class="hub-settings-tab" type="button" role="tab" aria-selected="false" aria-controls="hubComponent-discovery" data-hub-settings-tab="discovery">Discovery Settings</button>
<button id="hubTab-snmp2mqtt" class="hub-settings-tab" type="button" role="tab" aria-selected="false" aria-controls="hubComponent-snmp2mqtt" data-hub-settings-tab="snmp2mqtt">SNMP2MQTT Settings</button>
</div>
<section id="hubComponent-core" class="hub-component hub-settings-pane" role="tabpanel" aria-labelledby="hubTab-core"><div class="actions"><button id="hubCoreFallback" type="button">Native HA fallback</button><button id="hubCoreReset" class="danger" type="button">Reset Core defaults</button></div><div id="hubCoreSettings"></div></section>
<section id="hubComponent-discovery" class="hub-component hub-settings-pane" role="tabpanel" aria-labelledby="hubTab-discovery" hidden><div class="actions"><button id="hubDiscoveryFallback" type="button">Native App fallback</button></div><div id="hubDiscoverySettings"></div></section>
<section id="hubComponent-snmp2mqtt" class="hub-component hub-settings-pane" role="tabpanel" aria-labelledby="hubTab-snmp2mqtt" hidden><div class="actions"><button id="hubSnmpFallback" type="button">Native App fallback</button></div><div id="hubSnmpSettings"></div></section>
<div class="hub-settings-actions"><button id="hubSettingsSave" class="primary" type="button" disabled>Save changes</button><button id="hubSettingsReload" type="button">Reload</button>
      <button id="hubSettingsBack" type="button">Back</button><p id="hubSettingsStatus" class="muted hub-settings-status">All settings loaded from their authoritative components.</p></div>
</section>

<section id="discoveryCard" class="card hidden">
<h2>Run Discovery</h2>
<p id="discoveryStatus" class="lead">Idle / Ready</p>
<div id="discoverySteps" class="steps">
<div class="step" data-step="0"><span class="step-mark">1</span><span>Validating configured switches</span></div>
<div class="step" data-step="1"><span class="step-mark">2</span><span>Running SNMP walks</span></div>
<div class="step" data-step="2"><span class="step-mark">3</span><span>Detecting exact models and interfaces</span></div>
<div class="step" data-step="3"><span class="step-mark">4</span><span>Generating SNMP2MQTT YAML</span></div>
<div class="step" data-step="4"><span class="step-mark">5</span><span>Generating dashboard card YAML</span></div>
<div class="step" data-step="5"><span class="step-mark">6</span><span>Complete</span></div>
</div>
<dl class="live-status">
<dt>Current stage</dt><dd id="liveStage">Ready</dd>
<dt>Switch</dt><dd id="liveSwitch">Not running</dd>
<dt>Target</dt><dd id="liveTarget">Not running</dd>
<dt>Action</dt><dd id="liveActivity">Waiting to start</dd>
<dt>Command</dt><dd id="liveCommand" class="command-line">No command running</dd>
<dt>Status</dt><dd id="liveRunStatus">Idle / Ready</dd>
<dt>SNMP2MQTT</dt><dd id="liveSnmp2mqtt">Waiting for Discovery</dd>
<dt>Elapsed</dt><dd id="liveElapsed" class="elapsed">00:00</dd>
</dl>
<div class="actions"><button class="primary" id="runDiscoveryButton" type="button">Run Discovery</button><button id="regenerateYamlButton" type="button">Regenerate SNMP2MQTT YAML</button><button id="regenerateCardYamlButton" type="button">Regenerate Dashboard Card YAML</button><button id="stopDiscoveryButton" type="button" disabled>Stop Discovery</button><button id="viewResultsButton" type="button">View Results</button><button id="toggleDebugButton" type="button">Show Debug</button></div>
<p id="regenerateYamlHelp" class="muted">Regenerate SNMP2MQTT YAML and Regenerate Dashboard Card YAML reuse existing saved Discovery data and stored SNMP walks. No new SNMP walks are performed.</p>
<p id="regenerateYamlStatus" class="muted"></p>
<p id="regenerateCardYamlStatus" class="muted"></p>
<details class="yaml-manager generated-card-manager">
<summary><strong>Generated Dashboard YAML</strong></summary>
<p>Discovery validates the Native dashboard source and prepares manual exports without changing the Native dashboard. <b>New dashboard:</b> choose the dashboard format below, then use <b>Preview Dashboard YAML</b>, <b>Copy Dashboard YAML</b>, or <b>Download Dashboard YAML</b> and paste it into Home Assistant's Raw configuration editor. <b>Existing dashboard:</b> use <b>Copy Cards Only</b> and paste the list entries beneath the target view's <code>cards:</code> key.</p>
<p class="muted">Manual exports are snapshots. <b>Custom dashboard</b> preserves the generated <code>custom:vertical-layout</code> wrapper and <code>layout:</code> settings and therefore requires Layout Card. <b>Standard dashboard</b> removes that wrapper so no third-party view dependency is required.</p>
<dl class="yaml-state"><dt>Generated file</dt><dd id="generatedCardYamlState">Checking…</dd><dt>Validation</dt><dd id="generatedCardYamlValidation">Checking…</dd><dt>Last updated</dt><dd id="generatedCardYamlUpdated">Checking…</dd></dl>
<label>New dashboard format<select id="generatedDashboardExportMode"><option value="custom-dashboard" selected>Custom dashboard (preserve vertical layout)</option><option value="dashboard">Standard dashboard (no Layout Card)</option></select><small>Preview, Copy, and Download use this format. Cards Only is unchanged.</small></label>
<div class="actions"><button id="previewGeneratedDashboardYamlButton" type="button">Preview Dashboard YAML</button><button id="copyGeneratedDashboardYamlButton" type="button">Copy Dashboard YAML</button><button id="copyGeneratedCardsOnlyButton" type="button">Copy Cards Only</button><a id="downloadGeneratedDashboardYamlButton" class="button" href="#">Download Dashboard YAML</a></div>
<p id="generatedCardYamlActionStatus" class="muted"></p><pre id="generatedCardYamlPreview" class="code-preview hidden"></pre>
</details>
<details class="yaml-manager">
<summary><strong>Generated SNMP2MQTT YAML</strong></summary>
<p id="generatedYamlDescription">SNMP2MQTT YAML is only required for switches using the SNMP data path. UniFi API devices use UniFi2MQTT and do not require this file.</p>
<dl class="yaml-state"><dt>Generated file</dt><dd id="generatedYamlState">Checking…</dd><dt>Validation</dt><dd id="generatedYamlValidation">Checking…</dd><dt>Last updated</dt><dd id="generatedYamlUpdated">Checking…</dd></dl>
<div id="generatedYamlActions" class="actions"><button id="previewGeneratedYamlButton" type="button">Preview generated YAML</button><a id="downloadGeneratedYamlButton" class="button" href="#">Download YAML</a></div>
<p id="generatedYamlActionStatus" class="muted"></p><pre id="generatedYamlPreview" class="code-preview hidden"></pre>
</details>
<div id="debugWrap" class="hidden"><div class="debug-head"><strong>Discovery debug output</strong><small>Commands and detailed activity; credentials remain masked.</small></div><div id="discoveryLog" class="status debug-panel"></div><div class="actions"><button id="copyDebugButton" type="button">Copy Debug Info</button></div><p id="copyDebugStatus" class="muted"></p></div>
<details id="discoveryHistoryWrap" class="yaml-manager">
<summary><strong>Recent Discovery activity</strong></summary>
<p class="muted">Up to 20 completed Discovery and regeneration operations are retained locally. Debug excerpts are limited to 80 credential-sanitized lines per operation.</p>
<div id="discoveryHistory"><p class="muted">No completed Discovery operations are recorded yet.</p></div>
</details>
</section>

<section id="devicesCard" class="card hidden">
<h2>Devices</h2>
<div class="hub-settings-tabs" role="tablist" aria-label="Device sections">
<button id="devicesTab-configure" class="hub-settings-tab is-active" type="button" role="tab" aria-selected="true" aria-controls="devicesPanel-configure" data-devices-tab="configure">Configure Devices</button>
<button id="devicesTab-overview" class="hub-settings-tab" type="button" role="tab" aria-selected="false" aria-controls="devicesPanel-overview" data-devices-tab="overview">Device Overview</button>
</div>
<section id="devicesPanel-configure" role="tabpanel" aria-labelledby="devicesTab-configure">
<p class="muted">Add, remove, and edit saved switches and stack-member display mappings. SNMP communities remain masked and are never included in non-secret exports.</p>
<div id="hubDeviceConfiguration"></div>
<div class="hub-settings-actions">
<button id="devicesConfigSave" class="primary" type="button" disabled>Save Device Configuration</button>
<button id="devicesConfigReload" type="button">Reload</button>
<p id="devicesConfigStatus" class="muted hub-settings-status">Device configuration has not been loaded yet.</p>
</div>
</section>
<section id="devicesPanel-overview" role="tabpanel" aria-labelledby="devicesTab-overview" hidden>
<h3>Switches</h3>
<p class="muted configured-device-note">Manage saved switches from one list. Select a switch to expand its detected hardware and generated-configuration details. Use the up/down arrows to reorder saved switches. Disabled switches remain configured and can be re-enabled at any time.</p>
<div id="devicesDiagnosticsSummary" class="diag-summary devices-diagnostics-summary"></div>
<div id="devicesDiagnosticsMessages"></div>
<div id="configuredDevices"></div>
<p id="configuredDevicesStatus" class="muted configured-device-status"></p>
<div class="actions"><button class="primary" id="refreshDevicesButton" type="button">Refresh Devices</button><button id="resetDeviceOrderButton" type="button">Reset Order</button><button id="devicesRegenerateCardYamlButton" type="button">Regenerate Dashboard Card YAML</button><button id="copyDiagnosticsButton" type="button">Copy Diagnostics</button><a id="downloadDiagnosticsButton" class="button" href="#">Download Diagnostics Report</a><button id="devicesRunDiscoveryButton" type="button">Run Discovery</button></div>
<p id="devicesActionStatus" class="muted"></p>
</section>
</section>

<section id="createCard" class="card hidden">
<h2>Support My Switch</h2>
<p class="lead">Prepare a privacy-processed contribution bundle. Nothing is sent automatically.</p>
<h3>Create contribution</h3>
<div class="grid">
<label class="option"><input id="mask_management_ips" type="checkbox"><span><b>Mask management IPs</b><br><small>Recommended for anything shared outside your private network.</small></span></label>
<label class="option"><input id="mask_mac_addresses" type="checkbox"><span><b>Mask MAC addresses</b><br><small>Replaces hardware addresses while preserving useful structure.</small></span></label>
<label class="option"><input id="mask_hostnames" type="checkbox"><span><b>Mask hostnames</b><br><small>Removes detected hostnames and domain names.</small></span></label>
<label class="option"><input id="mask_vlan_names" type="checkbox"><span><b>Mask VLAN names</b><br><small>Enable when VLAN labels contain private information.</small></span></label>
<label class="option"><input id="mask_interface_descriptions" type="checkbox"><span><b>Mask interface descriptions</b><br><small>Enable when port descriptions contain names or locations.</small></span></label>
</div>
<div id="privacyWarning" class="warning hidden"><b>Privacy warning:</b> one or more common identity masks are disabled. The bundle is still credential-sanitized, but review it carefully before sending.</div>
<div class="grid">
<label class="field"><span><b>Recognition</b></span><select id="contributor_type"><option value="anonymous">Anonymous</option><option value="first_name">First name</option><option value="full_name">Full name</option><option value="github">GitHub username</option><option value="forum">Forum username</option></select></label>
<label class="field" id="recognitionValueWrap"><span><b>Name or username</b></span><input id="contributor_value" type="text" maxlength="120" placeholder="Optional recognition"></label>
</div>
<div class="actions"><button class="primary" id="createButton">Create contribution</button></div>
</section>

<section id="progressCard" class="card hidden"><h2>Preparing contribution</h2><p id="progressMessage">Starting…</p><div id="logTail" class="status"></div></section>

<section id="readyCard" class="card hidden">
<h2 id="readyHeading">Contribution ready</h2>
<div id="qualityBanner"></div>
<p id="qualityDetails" class="muted"></p>
<dl class="meta"><dt>Contribution ID</dt><dd id="contributionId"></dd><dt>Switch Vision version</dt><dd id="version"></dd><dt>Archive</dt><dd id="archiveName"></dd><dt>Archive size</dt><dd id="archiveSize"></dd></dl>
<h3>Detected hardware</h3><div id="devices"></div>
<div class="actions"><a id="prepareEmail" class="button primary">Prepare Email</a><a id="downloadArchive" class="button">Download Archive</a><a id="mailto" class="button">Open Email Without Attachment</a><button id="createAnother">Create Another Contribution</button></div>
<p><small><b>Prepare Email</b> downloads a standard .eml message with the ZIP attached. Open it in your email application, review it, then press Send.</small></p>
</section>

<section id="importantCard" class="card hidden"><h2>Important</h2><p>Credentials are always removed and device serial numbers are always masked in the temporary copy. Automated masking cannot identify every possible private value, so review the archive before sharing it.</p><p class="muted">Files are stored in <code>/share/switch_vision/contributions/</code>.</p></section>
<div id="hubSharedActions" class="hub-settings-actions hub-shared-actions hidden" role="region" aria-label="Page actions">
<button id="hubSharedPrimary" class="primary" type="button">Action</button>
<button id="hubSharedReload" type="button">Reload</button>
<button id="hubSharedBack" type="button">Back</button>
<p id="hubSharedStatus" class="muted hub-settings-status">Ready</p>
</div>
</main>
<script>
const $=id=>document.getElementById(id); const HUB_DOCUMENT_VERSION=String(document.body.dataset.svDiscoveryVersion||'unknown').trim(); const HUB_VERSION_RELOAD_KEY='switch-vision-hub-runtime-version-reload-v1'; let defaultsLoaded=false; let polling=null; let elapsedTicker=null; let refreshInFlight=false; let currentView='home'; let lastRunning=false; let lastDiscoveryState={}; let generatedCardYamlModified=null;
const THEME_STORAGE_KEY='switch-vision-management-theme-v1';const MANAGEMENT_THEMES=new Set(['switch-vision','cisco-classic','cisco-nexus','unifi']);
const MOTD_VISIBILITY_STORAGE_KEY='switch-vision-hub-motd-visibility-v1';
function applyManagementTheme(value,{persist=true}={}){const theme=MANAGEMENT_THEMES.has(value)?value:'switch-vision';document.documentElement.dataset.svTheme=theme;if($('themeSelect'))$('themeSelect').value=theme;if(persist){try{localStorage.setItem(THEME_STORAGE_KEY,theme)}catch(_e){}}}
function initManagementTheme(){let theme=document.documentElement.dataset.svTheme||'switch-vision';try{const saved=localStorage.getItem(THEME_STORAGE_KEY);if(MANAGEMENT_THEMES.has(saved))theme=saved}catch(_e){}applyManagementTheme(theme,{persist:false})}
function applyHubMotdVisibility(visible,{persist=true}={}){const card=$('hubMotd'),body=$('hubMotdBody'),button=$('hubMotdToggle');if(!card||!body||!button)return;const shown=visible!==false;body.hidden=!shown;card.classList.toggle('is-collapsed',!shown);button.textContent=shown?'Hide':'Show';button.setAttribute('aria-expanded',String(shown));button.setAttribute('aria-label',shown?'Hide Message of the Day':'Show Message of the Day');if(persist){try{localStorage.setItem(MOTD_VISIBILITY_STORAGE_KEY,shown?'shown':'hidden')}catch(_e){}}}
function initHubMotdVisibility(){let shown=true;try{shown=localStorage.getItem(MOTD_VISIBILITY_STORAGE_KEY)!=='hidden'}catch(_e){}applyHubMotdVisibility(shown,{persist:false})}
function toggleHubMotdVisibility(){const button=$('hubMotdToggle');if(!button)return;applyHubMotdVisibility(button.getAttribute('aria-expanded')!=='true')}
function syncDensityUi(value){const allowed=['spacious','comfortable','compact','dense','ultra_dense'];const density=allowed.includes(String(value))?String(value):'comfortable';for(const name of allowed)document.body.classList.toggle(`density-${name}`,name===density)}function syncContentWidthUi(value){const allowed=['standard','standard_plus','wide','wide_plus','extra_wide','extra_wide_plus','ultra_wide','ultra_wide_plus','max_wide','full'];const width=allowed.includes(String(value))?String(value):'standard';for(const name of allowed)document.body.classList.toggle(`width-${name}`,name===width)}
function endpoint(path){const href=location.href.endsWith('/')?location.href:location.href+'/';return new URL(path,href).toString()}
function fmtBytes(n){if(!Number.isFinite(n))return 'Unknown';const u=['B','KB','MB','GB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return `${n.toFixed(i?1:0)} ${u[i]}`}
function updateRecognition(){const anon=$('contributor_type').value==='anonymous';$('recognitionValueWrap').classList.toggle('hidden',anon);if(anon)$('contributor_value').value=''}
function updateWarning(){const unsafe=!$('mask_management_ips').checked||!$('mask_mac_addresses').checked||!$('mask_hostnames').checked;$('privacyWarning').classList.toggle('hidden',!unsafe)}
function setForm(d){for(const k of ['mask_management_ips','mask_mac_addresses','mask_hostnames','mask_vlan_names','mask_interface_descriptions'])$(k).checked=!!d[k];$('contributor_type').value=d.contributor_type||'anonymous';$('contributor_value').value=d.contributor_value||'';updateRecognition();updateWarning();defaultsLoaded=true}
function payload(){return {mask_management_ips:$('mask_management_ips').checked,mask_mac_addresses:$('mask_mac_addresses').checked,mask_hostnames:$('mask_hostnames').checked,mask_vlan_names:$('mask_vlan_names').checked,mask_interface_descriptions:$('mask_interface_descriptions').checked,contributor_type:$('contributor_type').value,contributor_value:$('contributor_value').value}}
function mailto(latest){const subject=`Switch Vision Contribution - ${latest.contribution_id}`;const body=`Hello,\n\nPlease find attached my Switch Vision contribution bundle.\n\nContribution ID: ${latest.contribution_id}\nSwitch Vision version: ${latest.version}\n\nWhat works:\n\nWhat is missing or incorrect:\n\nAnything unusual about this switch:\n\nThank you.`;return `mailto:switch-vision@zemerdon.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`}
function statusLabel(value){return String(value||'unknown').replaceAll('_',' ')}
function validationItem(label,value){const item=document.createElement('div');item.className='validation-item';const name=document.createElement('span');name.textContent=label;const state=document.createElement('span');const normalized=String(value||'unknown').toLowerCase();state.className=`state-${normalized}`;state.textContent=statusLabel(normalized);item.append(name,state);return item}
function deviceCard(d){const card=document.createElement('div');card.className='device-card';const head=document.createElement('div');head.className='device-head';const title=document.createElement('div');const strong=document.createElement('strong');strong.textContent=d.model||'Unknown model';title.appendChild(strong);const detail=document.createElement('div');detail.className='muted';detail.textContent=`${d.vendor_name||d.vendor||'Unknown vendor'}${d.family&&d.family!=='unknown'?` · ${d.family}`:''}`;title.appendChild(detail);const status=String(d.registry_status||'detected').toLowerCase();const badge=document.createElement('span');badge.className=`badge badge-${status}`;badge.textContent=statusLabel(status);head.append(title,badge);card.appendChild(head);const meta=document.createElement('div');meta.className='device-meta-line';const fields=[['Registry',d.registry_match?'Yes':'No'],['Validated',d.registry_last_validated_version?`v${d.registry_last_validated_version}`:'Not recorded'],['Physical',d.physical_count??0],['RJ45',d.rj45_count??0]];for(const [label,value] of fields){const item=document.createElement('span');const name=document.createElement('b');name.textContent=`${label}:`;item.append(name,document.createTextNode(` ${value}`));meta.appendChild(item)}card.appendChild(meta);const validation=d.registry_validation||{};const grid=document.createElement('div');grid.className='validation-grid';for(const [label,key] of [['Exact model','exact_model_detection'],['RJ45 mapping','rj45_mapping'],['PoE','poe'],['System sensors','system_sensors'],['Uplinks','uplinks'],['Stack','stack']])grid.appendChild(validationItem(label,validation[key]));card.appendChild(grid);return card}
let creditsAnimationFrame=null;
function settleCredits(){const card=$('creditsCard');if(!card)return;card.classList.remove('credits-matrix-active');card.classList.add('credits-settled');}
function startCreditsAnimation(){
  const card=$('creditsCard'),canvas=$('creditsMatrix');
  if(!card||!canvas)return;
  if(creditsAnimationFrame){cancelAnimationFrame(creditsAnimationFrame);creditsAnimationFrame=null}
  card.classList.remove('credits-settled','credits-matrix-active');
  const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
  if(reduced){settleCredits();return}
  card.classList.add('credits-matrix-active');
  const rect=card.getBoundingClientRect(),dpr=Math.min(window.devicePixelRatio||1,2);
  canvas.width=Math.max(1,Math.floor(rect.width*dpr));canvas.height=Math.max(1,Math.floor(rect.height*dpr));
  const ctx=canvas.getContext('2d');if(!ctx){settleCredits();return}
  ctx.setTransform(dpr,0,0,dpr,0,0);
  const w=rect.width,h=rect.height,fontSize=14,cols=Math.max(1,Math.ceil(w/fontSize));
  const drops=Array.from({length:cols},()=>Math.random()*-22);
  const glyphs='01アイウエオカキクケコSVISION<>[]{}#*+=-';
  const started=performance.now(),duration=2900;
  function frame(now){
    if(currentView!=='credits'){creditsAnimationFrame=null;return}
    const p=Math.min(1,(now-started)/duration);
    ctx.fillStyle=p<.58?'rgba(2,10,8,.17)':'rgba(1,10,16,.18)';ctx.fillRect(0,0,w,h);
    ctx.font=`${fontSize}px ui-monospace,SFMono-Regular,Consolas,monospace`;
    for(let i=0;i<cols;i++){
      const x=i*fontSize,y=drops[i]*fontSize;
      const cyan=Math.max(0,(p-.35)/.65);
      ctx.fillStyle=cyan<.45?'rgba(104,255,150,.78)':'rgba(83,225,255,.82)';
      ctx.fillText(glyphs[Math.floor(Math.random()*glyphs.length)],x,y);
      if(y>h&&Math.random()>.965)drops[i]=Math.random()*-10;else drops[i]+=.62+Math.random()*.52;
    }
    if(p>.64){
      const a=(p-.64)/.36;
      ctx.fillStyle=`rgba(4,22,31,${a*.5})`;ctx.fillRect(0,0,w,h);
      ctx.strokeStyle=`rgba(77,224,255,${a*.2})`;ctx.lineWidth=1;
      for(let y=22;y<h;y+=46){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w*a,y);ctx.stroke()}
    }
    if(p<1){creditsAnimationFrame=requestAnimationFrame(frame)}
    else{creditsAnimationFrame=null;settleCredits()}
  }
  creditsAnimationFrame=requestAnimationFrame(frame);
}
const HUB_SHARED_PAGE_ACTIONS={discovery:{label:'Run Discovery',target:'runDiscoveryButton',status:'discoveryStatus'},devices:{label:'Refresh Devices',target:'refreshDevicesButton',status:'configuredDevicesStatus'},support:{label:'Create Contribution',target:'createButton'},unifi2mqtt:{label:'Save UniFi2MQTT Settings',target:'saveUnifi2mqttButton',status:'unifiSettingsStatus'}};let hubSharedStatusObserver=null;function syncSharedHubStatus(){const cfg=HUB_SHARED_PAGE_ACTIONS[currentView],out=$('hubSharedStatus');if(!out||!cfg)return;const src=cfg.status?$(cfg.status):null;out.textContent=src?.textContent?.trim()||'Ready'}function updateSharedHubActions(view=currentView){const bar=$('hubSharedActions'),primary=$('hubSharedPrimary');if(!bar||!primary)return;hubSharedStatusObserver?.disconnect();hubSharedStatusObserver=null;const cfg=HUB_SHARED_PAGE_ACTIONS[view];bar.classList.toggle('hidden',!cfg);if(!cfg)return;primary.textContent=cfg.label;primary.dataset.target=cfg.target;const src=cfg.status?$(cfg.status):null;if(src){hubSharedStatusObserver=new MutationObserver(syncSharedHubStatus);hubSharedStatusObserver.observe(src,{childList:true,subtree:true,characterData:true})}syncSharedHubStatus()}function runSharedHubPrimary(){const id=$('hubSharedPrimary')?.dataset.target;if(!id)return;const target=$(id);if(!target||target.disabled)return;target.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}))}function reloadSharedHubView(){if(currentView==='discovery'){refresh();Promise.all([loadGeneratedCardYamlStatus(),loadGeneratedYamlStatus()]);return}if(currentView==='devices'){loadDevices();return}if(currentView==='support'){refresh();return}if(currentView==='configuration'){$('exportConfigurationButton').href=endpoint('download/switch-vision-backup.json');$('configurationStatus').textContent='Configuration view refreshed.';return}if(currentView==='maintenance'){window.SwitchVisionMaintenance?.loadInstallerBackups?.();window.SwitchVisionMaintenance?.scan?.();return}if(currentView==='profiles'){window.SwitchVisionCalibrationProfiles?.load?.(true);return}if(currentView==='unifi2mqtt'){loadUnifi2mqttSettings();return}}function setView(view){currentView=view;const isHome=view==='home';$('backButton').textContent=isHome?'← Back to Home Assistant':'← Back';const titles={home:['Switch Vision Hub',''],discovery:['Discovery','Run a guided discovery job and review its progress.'],devices:['Devices','Latest detected hardware and generated configuration status.'],support:['Support My Switch','Prepare a privacy-processed contribution bundle. Nothing is sent automatically.'],configuration:['Import / Export Configuration','Back up or restore the complete non-secret Switch Vision configuration across all components.'],maintenance:['Maintenance','Repair and reset Switch Vision-managed runtime state safely.'],credits:['Credits','Acknowledging the contributors who help make Switch Vision possible.'],profiles:['Calibration Profiles','Manage saved faceplate calibration profiles.'],settings:['Switch Vision Hub Settings','Configure how Switch Vision Hub appears and behaves.'],unifi2mqtt:['UniFi2MQTT Settings','Configure the UniFi controller API and MQTT support path.'],progress:['Support My Switch','Preparing your contribution bundle.'],ready:['Support My Switch','Your contribution bundle is ready to review.']};const title=titles[view]||titles.home;$('pageHeading').textContent=title[0];$('pageLead').textContent=title[1];$('pageLead').classList.toggle('hidden',!title[1]);$('homeCard').classList.toggle('hidden',view!=='home');$('discoveryCard').classList.toggle('hidden',view!=='discovery');$('devicesCard').classList.toggle('hidden',view!=='devices');$('createCard').classList.toggle('hidden',view!=='support');$('importantCard').classList.toggle('hidden',view!=='support');$('maintenanceCard').classList.toggle('hidden',view!=='maintenance');$('creditsCard').classList.toggle('hidden',view!=='credits');$('settingsCard').classList.toggle('hidden',view!=='settings');$('unifi2mqttCard').classList.toggle('hidden',view!=='unifi2mqtt');$('progressCard').classList.toggle('hidden',view!=='progress');$('readyCard').classList.toggle('hidden',view!=='ready');updateSharedHubActions(view);window.scrollTo({top:0,behavior:'smooth'})}
function goBack(){if(!$('homeCard').classList.contains('hidden')){try{if(history.length>1){history.back();return}}catch(_e){}try{window.top.location.href='/';return}catch(_e){}location.href='/';return}setView('home')}
function openHomeAssistantPath(path){try{window.top.location.href=path;return}catch(_e){}window.location.href=path}
let appLinksCache=null;
async function loadAppLinks(){if(appLinksCache)return appLinksCache;const r=await fetch(endpoint('api/app-links'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not resolve installed apps');appLinksCache=d;return d}
async function openResolvedApp(kind){try{const links=await loadAppLinks();const item=links[kind]||{};const path=kind==='installer'?item.ingress_url:item.config_url;const labels={discovery:'Switch Vision Discovery',snmp2mqtt:'Switch Vision SNMP2MQTT',installer:'Switch Vision Installer'};if(!item.found||!path)throw new Error(`${labels[kind]||'Switch Vision app'} is not installed or could not be resolved.`);openHomeAssistantPath(path)}catch(e){alert(e.message||String(e))}}
function setUnifiHomeCardVisibility(show){const btn=$('openUnifi2mqttSettingsButton');if(!btn)return;btn.classList.toggle('hidden',show===false);if(show===false&&currentView==='unifi2mqtt')setView('home')}
let unifiControllersDraft=[];
let unifiTestHistory=[];
function unifiBool(value,defaultValue=false){if(value===true||value===false)return value;const text=String(value??'').trim().toLowerCase();if(['true','1','yes','on'].includes(text))return true;if(['false','0','no','off'].includes(text))return false;return defaultValue}
function renderUnifiHomeCard(d){const btn=$('openUnifi2mqttSettingsButton');const label=$('unifiHomeCardState');if(!btn||!label)return;btn.classList.remove('unifi-unavailable','unifi-needs-setup','unifi-warning');const o=d?.options||{};const configured=!!(d?.installed&&d?.connection_ready&&String(o.mqtt_host||'').trim());const running=['started','running'].includes(String(d?.state||'').toLowerCase());if(!d?.installed){btn.classList.add('unifi-unavailable');btn.dataset.unifiAction='blocked';btn.setAttribute('aria-disabled','true');btn.title='UniFi2MQTT is not installed. Install it from Switch Vision Installer first.';label.textContent='Not installed';return}btn.dataset.unifiAction='open';btn.setAttribute('aria-disabled','false');if(!configured){btn.classList.add('unifi-needs-setup');btn.title='UniFi2MQTT is installed but no usable Local, Remote, or multi-controller API credential is configured.';label.textContent='Needs setup';return}if(!running){btn.classList.add('unifi-warning');btn.title='UniFi2MQTT is configured but not running. Open settings to review status.';label.textContent='Configured — not running';return}const active=String(d.active_transport||'').toLowerCase();if(d.failover_active&&active){btn.classList.add('unifi-warning');btn.title=`UniFi2MQTT is running on the ${active} fallback path; the priority path will be retried automatically.`;label.textContent=`Ready · ${active[0].toUpperCase()+active.slice(1)} fallback`;return}btn.title='UniFi2MQTT is installed, configured, and running.';label.textContent=active?`Ready · ${active[0].toUpperCase()+active.slice(1)}`:'Ready'}
async function refreshUnifiHomeCard(){try{const d=await fetchUnifi2mqttSettings();renderUnifiHomeCard(d)}catch(e){const btn=$('openUnifi2mqttSettingsButton');const label=$('unifiHomeCardState');if(btn&&label){btn.classList.remove('unifi-needs-setup');btn.classList.add('unifi-warning');btn.dataset.unifiAction='open';btn.setAttribute('aria-disabled','false');btn.title=`UniFi2MQTT status could not be checked: ${e}`;label.textContent='Status unavailable'}}}
async function fetchSavedSecret(ref){const r=await fetch(endpoint('api/secrets/reveal'),{method:'POST',headers:{'Content-Type':'application/json'},cache:'no-store',body:JSON.stringify(ref||{})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not reveal saved credential');return String(d.secret||'')}
function setSecretConfigured(input,configured){if(!input)return;input.dataset.secretConfigured=configured?'true':'false';const btn=input._svSecretEye;if(btn)btn.disabled=!configured&&!input.value}
function maskSecretInput(input){if(!input)return;input.type='password';const btn=input._svSecretEye;if(btn){btn.setAttribute('aria-pressed','false');btn.setAttribute('aria-label','Reveal saved credential');btn.title='Reveal or hide this saved credential'}}
function secretControl(input,refProvider,configured=false){if(!input)return input;if(input.parentElement?.classList.contains('secret-control')){setSecretConfigured(input,configured);return input.parentElement}const wrap=document.createElement('span');wrap.className='secret-control';const parent=input.parentNode;if(parent)parent.insertBefore(wrap,input);wrap.append(input);const eye=document.createElement('button');eye.type='button';eye.className='secret-eye';eye.textContent='👁';eye.setAttribute('aria-label','Reveal saved credential');eye.setAttribute('aria-pressed','false');eye.title='Reveal or hide this saved credential';wrap.append(eye);input._svSecretEye=eye;input._svSecretRefProvider=refProvider;setSecretConfigured(input,configured);input.addEventListener('input',()=>setSecretConfigured(input,input.dataset.secretConfigured==='true'));eye.addEventListener('click',async event=>{event.preventDefault();event.stopPropagation();if(input.type==='text'){input.type='password';eye.setAttribute('aria-pressed','false');eye.setAttribute('aria-label','Reveal saved credential');return}if(input.value){input.type='text';eye.setAttribute('aria-pressed','true');eye.setAttribute('aria-label','Hide credential');return}const ref=typeof input._svSecretRefProvider==='function'?input._svSecretRefProvider():null;if(!ref||input.dataset.secretConfigured!=='true')return;eye.disabled=true;try{const saved=await fetchSavedSecret(ref);input.value=saved;input.type='text';eye.setAttribute('aria-pressed','true');eye.setAttribute('aria-label','Hide credential')}catch(e){eye.title=`Could not reveal saved credential: ${e.message||e}`}finally{setSecretConfigured(input,input.dataset.secretConfigured==='true')}});return wrap}
function installStaticSecretControls(){secretControl($('unifi_local_api_key'),()=>({scope:'unifi2mqtt',kind:'local_api_key'}),false);secretControl($('unifi_remote_api_key'),()=>({scope:'unifi2mqtt',kind:'remote_api_key'}),false);secretControl($('unifi_mqtt_password'),()=>({scope:'unifi2mqtt',kind:'mqtt_password'}),false)}
async function fetchUnifi2mqttSettings(){const r=await fetch(endpoint('api/unifi2mqtt/settings'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not load UniFi2MQTT settings');return d}
function syncUnifiFallbackOptions(){const priority=$('unifi_priority_transport')?.value||'local';const fallback=$('unifi_fallback_transport');if(!fallback)return;for(const option of fallback.options)option.disabled=option.value===priority;if(fallback.value===priority)fallback.value=priority==='local'?'remote':'local'}
function renderUnifiControllerEditor(rows){const root=$('unifiControllersRoot');if(!root)return;root.innerHTML='';if(!rows.length){const empty=document.createElement('p');empty.className='muted';empty.textContent='No additional controllers configured. The Local/Remote priority profile above is active.';root.append(empty);return}rows.forEach((row,index)=>{const card=document.createElement('div');card.className='device-card unifi-controller-editor';const head=document.createElement('div');head.className='device-head';const title=document.createElement('strong');title.textContent=`Controller ${index+1}`;const remove=document.createElement('button');remove.type='button';remove.className='danger';remove.textContent='Remove';remove.title='Remove this controller/site from UniFi2MQTT configuration.';remove.onclick=()=>{unifiControllersDraft.splice(index,1);renderUnifiControllerEditor(unifiControllersDraft)};head.append(title,remove);card.append(head);const grid=document.createElement('div');grid.className='grid';const field=(label,input,help)=>{const wrap=document.createElement('label');wrap.className='field';const span=document.createElement('span');const bold=document.createElement('b');bold.textContent=label;span.append(bold);wrap.append(span,input);const target=input.matches?.('input,select,textarea')?input:input.querySelector?.('input,select,textarea');if(help){const small=document.createElement('small');small.textContent=help;wrap.append(small);if(target)target.title=help}return wrap};const id=document.createElement('input');id.type='text';id.maxLength=64;id.value=row.id||'';id.placeholder='home';id.oninput=()=>row.id=id.value;const transport=document.createElement('select');for(const [value,label] of [['local','Local'],['remote','Remote / Site Manager']]){const option=document.createElement('option');option.value=value;option.textContent=label;option.selected=(row.transport||'local')===value;transport.append(option)}transport.onchange=()=>{row.transport=transport.value;renderUnifiControllerEditor(unifiControllersDraft)};const site=document.createElement('input');site.type='text';site.maxLength=256;site.value=row.site_id||'auto';site.oninput=()=>row.site_id=site.value;const api=document.createElement('input');api.type='password';api.maxLength=4096;api.autocomplete='new-password';api.value='';api.placeholder=row.api_key_configured?'Saved — use eye to reveal':'Required';api.oninput=()=>row.api_key=api.value;const apiControl=secretControl(api,()=>({scope:'unifi2mqtt',kind:'controller_api_key',identifier:row.original_id||row.id}),!!row.api_key_configured);grid.append(field('Controller ID',id,'Stable operator ID used only to preserve this controller configuration and private state.'),field('Transport',transport,'Choose Local Integration API or Remote Site Manager connector access.'),field('Site ID',site,'Use auto unless this controller must select a specific Network Integration site.'));if((row.transport||'local')==='local'){const url=document.createElement('input');url.type='url';url.maxLength=512;url.value=row.controller_url||'https://192.168.1.1:11443';url.oninput=()=>row.controller_url=url.value;const verify=document.createElement('input');verify.type='checkbox';verify.checked=unifiBool(row.verify_ssl,true);verify.onchange=()=>row.verify_ssl=verify.checked;const insecure=document.createElement('input');insecure.type='checkbox';insecure.checked=unifiBool(row.allow_insecure_http,false);insecure.onchange=()=>row.allow_insecure_http=insecure.checked;grid.append(field('Controller URL',url,'Self-hosted UniFi controllers normally use HTTPS port 11443.'),field('API Key',apiControl,row.api_key_configured?'Stored key is masked; use the eye to reveal it. Blank preserves it.':'Enter the local Integration API key.'),field('Verify SSL',verify,'Verify the local controller certificate.'),field('Allow insecure HTTP',insecure,'Explicitly allow plaintext local HTTP only when the risk is accepted.'))}else{const host=document.createElement('input');host.type='text';host.maxLength=256;host.value=row.host_id||'auto';host.oninput=()=>row.host_id=host.value;grid.append(field('Host ID',host,'Site Manager console host ID; use auto when unambiguous.'),field('API Key',apiControl,row.api_key_configured?'Stored key is masked; use the eye to reveal it. Blank preserves it.':'Enter the UniFi Site Manager API key.'))}card.append(grid);root.append(card)})}
function addUnifiController(){unifiControllersDraft.push({id:'',transport:'local',controller_url:'https://192.168.1.1:11443',host_id:'auto',site_id:'auto',api_key:'',api_key_configured:false,verify_ssl:true,allow_insecure_http:false});renderUnifiControllerEditor(unifiControllersDraft)}
function renderUnifi2mqttSettings(d){const grid=$('unifiStatusGrid');grid.innerHTML='';const snapshot=d.snapshot||{};const state=String(d.state||'not installed');const o=d.options||{};const active=String(d.active_transport||'');const connectionLabel=d.multi_controller_enabled?`${d.controller_count||0} controller${(d.controller_count||0)===1?'':'s'}`:(d.connection_ready?'Configured':'Needs setup');const activeLabel=d.failover_active&&active?`${active} fallback`:(active||'Waiting');grid.append(diagTile('UniFi2MQTT',d.installed?'Installed':'Not installed',d.installed?'diag-good':'diag-warn'),diagTile('App state',state,state==='started'||state==='running'?'diag-good':'diag-warn'),diagTile('Connection',connectionLabel,d.connection_ready?'diag-good':'diag-warn'),diagTile('Active path',activeLabel,d.failover_active?'diag-warn':(active?'diag-good':'diag-warn')),diagTile('Local API',d.local_api_key_configured?'Configured':'Not configured',d.local_api_key_configured?'diag-good':'diag-warn'),diagTile('Remote API',d.remote_api_key_configured?'Configured':'Not configured',d.remote_api_key_configured?'diag-good':'diag-warn'),diagTile('Snapshot',snapshot.found?'Available':'Missing',snapshot.found?'diag-good':'diag-warn'),diagTile('Devices',String(snapshot.device_count||0),snapshot.device_count>0?'diag-good':'diag-warn'));$('unifiInstallWrap').classList.toggle('hidden',!!d.installed);$('unifiSettingsForm').classList.toggle('hidden',!d.installed);$('unifi_priority_transport').value=o.priority_transport||o.transport||'local';$('unifi_fallback_transport').value=o.fallback_transport||'remote';syncUnifiFallbackOptions();$('unifi_poll_interval').value=o.poll_interval||30;$('unifi_local_controller_url').value=o.local_controller_url||((o.transport||'local')==='local'?(o.controller_url||'https://192.168.1.1:11443'):'https://192.168.1.1:11443');$('unifi_local_site_id').value=o.local_site_id||((o.transport||'local')==='local'?(o.site_id||'auto'):'auto');$('unifi_local_verify_ssl').checked=unifiBool(o.local_verify_ssl,(o.transport||'local')==='local'?unifiBool(o.verify_ssl,true):true);$('unifi_local_allow_insecure_http').checked=unifiBool(o.local_allow_insecure_http,(o.transport||'local')==='local'?unifiBool(o.allow_insecure_http,false):false);$('unifi_remote_host_id').value=o.remote_host_id||((o.transport||'local')==='remote'?(o.host_id||'auto'):'auto');$('unifi_remote_site_id').value=o.remote_site_id||((o.transport||'local')==='remote'?(o.site_id||'auto'):'auto');$('unifi_local_api_key').value='';$('unifi_remote_api_key').value='';maskSecretInput($('unifi_local_api_key'));maskSecretInput($('unifi_remote_api_key'));setSecretConfigured($('unifi_local_api_key'),!!d.local_api_key_configured);setSecretConfigured($('unifi_remote_api_key'),!!d.remote_api_key_configured);$('unifiLocalApiKeyState').textContent=d.local_api_key_configured?'Configured — eye reveals saved key':'Not configured';$('unifiRemoteApiKeyState').textContent=d.remote_api_key_configured?'Configured — eye reveals saved key':'Not configured';unifiControllersDraft=(Array.isArray(o.controllers)?o.controllers:[]).map(row=>({...row,api_key:'',original_id:row.id||''}));renderUnifiControllerEditor(unifiControllersDraft);$('unifi_mqtt_host').value=o.mqtt_host||'core-mosquitto';$('unifi_mqtt_port').value=o.mqtt_port||1883;$('unifi_mqtt_username').value=o.mqtt_username||'';$('unifi_mqtt_password').value='';maskSecretInput($('unifi_mqtt_password'));setSecretConfigured($('unifi_mqtt_password'),!!d.mqtt_password_configured);$('unifi_mqtt_tls').checked=unifiBool(o.mqtt_tls,false);$('unifi_mqtt_verify_ssl').checked=unifiBool(o.mqtt_verify_ssl,true);$('unifi_mqtt_ca').value=o.mqtt_ca||'';$('unifi_mqtt_topic_prefix').value=o.mqtt_topic_prefix||'switch_vision/unifi';$('unifi_mqtt_discovery_prefix').value=o.mqtt_discovery_prefix||'homeassistant';$('unifiMqttPasswordState').textContent=d.mqtt_password_configured?'Configured — eye reveals saved password':'Not configured';$('openUnifiAppConfigButton').disabled=!d.config_url;window.unifi2mqttConfigUrl=d.config_url||null}
async function loadUnifi2mqttSettings(){setView('unifi2mqtt');$('unifiSettingsStatus').textContent='Loading UniFi2MQTT settings…';try{const d=await fetchUnifi2mqttSettings();renderUnifi2mqttSettings(d);$('unifiSettingsStatus').textContent=d.failover_active?`Priority path unavailable — currently using ${d.active_transport||'the configured'} fallback. The priority path will be retried automatically.`:'Saved credentials are masked by default. Use the eye to reveal one on demand; blank fields preserve stored values.'}catch(e){$('unifiSettingsStatus').textContent=`Could not load UniFi2MQTT settings: ${e}`}}
function unifiSettingsPayload(){return {priority_transport:$('unifi_priority_transport').value,fallback_transport:$('unifi_fallback_transport').value,local_controller_url:$('unifi_local_controller_url').value,local_site_id:$('unifi_local_site_id').value,local_api_key:$('unifi_local_api_key').value,local_verify_ssl:$('unifi_local_verify_ssl').checked,local_allow_insecure_http:$('unifi_local_allow_insecure_http').checked,remote_host_id:$('unifi_remote_host_id').value,remote_site_id:$('unifi_remote_site_id').value,remote_api_key:$('unifi_remote_api_key').value,controllers:unifiControllersDraft.map(row=>({id:row.id||'',transport:row.transport||'local',controller_url:row.controller_url||'',host_id:row.host_id||'auto',site_id:row.site_id||'auto',api_key:row.api_key||'',verify_ssl:unifiBool(row.verify_ssl,true),allow_insecure_http:unifiBool(row.allow_insecure_http,false)})),poll_interval:$('unifi_poll_interval').value,mqtt_host:$('unifi_mqtt_host').value,mqtt_port:$('unifi_mqtt_port').value,mqtt_username:$('unifi_mqtt_username').value,mqtt_password:$('unifi_mqtt_password').value,mqtt_tls:$('unifi_mqtt_tls').checked,mqtt_verify_ssl:$('unifi_mqtt_verify_ssl').checked,mqtt_ca:$('unifi_mqtt_ca').value,mqtt_topic_prefix:$('unifi_mqtt_topic_prefix').value,mqtt_discovery_prefix:$('unifi_mqtt_discovery_prefix').value}}
function unifiConnectionTestPayload(transport){if(transport==='local')return {transport:'local',controller_url:$('unifi_local_controller_url').value,site_id:$('unifi_local_site_id').value,api_key:$('unifi_local_api_key').value,verify_ssl:$('unifi_local_verify_ssl').checked,allow_insecure_http:$('unifi_local_allow_insecure_http').checked};return {transport:'remote',host_id:$('unifi_remote_host_id').value,site_id:$('unifi_remote_site_id').value,api_key:$('unifi_remote_api_key').value}}
function appendUnifiConnectionTestDebug(result){const transport=String(result?.transport||'unknown');const stamp=new Date().toLocaleTimeString();const outcome=result?.ok?'PASS':'FAIL';const lines=Array.isArray(result?.debug)?result.debug:[];unifiTestHistory.push(`[${stamp}] ${transport.toUpperCase()} ${outcome}`,...lines.map(line=>`  ${String(line)}`),'');if(unifiTestHistory.length>240)unifiTestHistory=unifiTestHistory.slice(-240);const log=$('unifiConnectionTestDebugLog');if(log){log.textContent=unifiTestHistory.join('\n');log.scrollTop=log.scrollHeight}const summary=$('unifiConnectionTestDebugSummary');if(summary){summary.textContent=`Last test: ${transport[0]?.toUpperCase()+transport.slice(1)} ${outcome}`;summary.className=`muted ${result?.ok?'unifi-test-pass':'unifi-test-fail'}`}}
function clearUnifiConnectionTestDebug(){unifiTestHistory=[];const log=$('unifiConnectionTestDebugLog');if(log)log.textContent='No connection tests have been run in this session.';const summary=$('unifiConnectionTestDebugSummary');if(summary){summary.textContent='Not tested';summary.className='muted'};$('unifiLocalTestStatus').textContent='Not tested';$('unifiLocalTestStatus').className='muted unifi-test-inline-status';$('unifiRemoteTestStatus').textContent='Not tested';$('unifiRemoteTestStatus').className='muted unifi-test-inline-status'}
async function testUnifiConnection(transport){const local=transport==='local';const btn=$(local?'testUnifiLocalButton':'testUnifiRemoteButton');const status=$(local?'unifiLocalTestStatus':'unifiRemoteTestStatus');btn.disabled=true;status.className='muted unifi-test-inline-status';status.textContent=`Testing ${local?'Local':'Remote'} connection…`;try{const r=await fetch(endpoint('api/unifi2mqtt/test-connection'),{method:'POST',headers:{'Content-Type':'application/json'},cache:'no-store',body:JSON.stringify(unifiConnectionTestPayload(transport))});const d=await r.json();if(!r.ok)throw new Error(d.error||'Connection test request failed');appendUnifiConnectionTestDebug(d);if(d.ok){status.className='muted unifi-test-inline-status unifi-test-pass';status.textContent=`PASS · authenticated · ${d.site_name||d.site_id||'site resolved'} · ${Number(d.device_count||0)} device(s)`}else{status.className='muted unifi-test-inline-status unifi-test-fail';status.textContent=`FAIL · ${String(d.stage||'connection').replaceAll('_',' ')} · ${d.reason||'Unknown error'}`}}catch(e){const result={ok:false,transport,stage:'request',reason:String(e.message||e),debug:[`${local?'Local':'Remote'} test: FAILED before completion: ${String(e.message||e)}`]};appendUnifiConnectionTestDebug(result);status.className='muted unifi-test-inline-status unifi-test-fail';status.textContent=`FAIL · ${result.reason}`}finally{btn.disabled=false}}
async function saveUnifi2mqttSettings(){const btn=$('saveUnifi2mqttButton');btn.disabled=true;$('unifiSettingsStatus').textContent='Saving UniFi2MQTT settings…';try{const r=await fetch(endpoint('api/unifi2mqtt/settings'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(unifiSettingsPayload())});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not save UniFi2MQTT settings');renderUnifi2mqttSettings(d);$('unifiSettingsStatus').textContent=d.restarted?'Saved. UniFi2MQTT restart requested.':(d.started?'Saved. UniFi2MQTT start requested.':'Saved.');appLinksCache=null}catch(e){$('unifiSettingsStatus').textContent=`Could not save: ${e}`}finally{btn.disabled=false}}
async function installUnifi2mqtt(){const btn=$('installUnifi2mqttButton');btn.disabled=true;$('unifiInstallStatus').textContent='Installing UniFi2MQTT…';try{const r=await fetch(endpoint('api/unifi2mqtt/install'),{method:'POST'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not install UniFi2MQTT');appLinksCache=null;renderUnifi2mqttSettings(d);$('unifiInstallStatus').textContent='Installed. Configure the controller and MQTT settings below.'}catch(e){$('unifiInstallStatus').textContent=`Could not install: ${e}`}finally{btn.disabled=false}}
function openUnifiAppConfig(){if(window.unifi2mqttConfigUrl)openHomeAssistantPath(window.unifi2mqttConfigUrl)}
function showLatest(latest){if(!latest){$('readyCard').classList.add('hidden');return}const ready=!!latest.ready_to_send;const processing=latest.processing||{};$('readyHeading').textContent=ready?'Contribution ready':'Contribution requires review';$('contributionId').textContent=latest.contribution_id;$('version').textContent=latest.version;$('archiveName').textContent=latest.archive;$('archiveSize').textContent=fmtBytes(latest.archive_size);const q=$('qualityBanner');q.className=ready?'success':'failure';q.textContent=`Bundle quality: ${latest.quality}${ready?'':' — do not share until reviewed'}`;const issueCount=Number(processing.issue_count||0);$('qualityDetails').textContent=issueCount?`${issueCount} file(s) could not be fully inspected or sanitized. Download the archive and read SANITIZATION_REPORT.txt for privacy-safe issue identifiers.`:(ready?'All files were inspected by the privacy processor.':'Review SANITIZATION_REPORT.txt before sharing.');$('devices').innerHTML='';for(const d of latest.devices||[])$('devices').appendChild(deviceCard(d));if(!(latest.devices||[]).length)$('devices').textContent='No devices were detected.';const emailReady=ready&&!!latest.email;$('prepareEmail').classList.toggle('hidden',!emailReady);if(emailReady)$('prepareEmail').href=endpoint(`download/${encodeURIComponent(latest.email)}`);$('downloadArchive').href=endpoint(`download/${encodeURIComponent(latest.archive)}`);$('mailto').classList.toggle('hidden',!ready);if(ready)$('mailto').href=mailto(latest)}

function diagTile(label,value,state=''){const tile=document.createElement('div');tile.className='diag-tile';const l=document.createElement('div');l.className='muted';l.textContent=label;const v=document.createElement('div');v.className=`diag-value ${state}`;v.textContent=value;tile.append(l,v);return tile}
function renderDeviceDiagnosticsSummary(d){const summary=$('devicesDiagnosticsSummary');if(!summary)return;summary.innerHTML='';const discovery=d.discovery||{};const registry=d.registry||{};const files=d.files||{};summary.append(diagTile('Switch Vision version',`v${d.version||'Unknown'}`),diagTile('Discovery app',d.service||'Unknown',d.service==='Running'?'diag-good':'diag-bad'),diagTile('Discovery status',discovery.running?'Running':(discovery.message||'Idle / Ready'),discovery.success===false?'diag-bad':'diag-good'),diagTile('Device registry',registry.loaded?`Loaded · ${registry.entries||0} entries`:'Unavailable',registry.loaded?'diag-good':'diag-bad'),diagTile('SNMP2MQTT YAML',files.generated_yaml?.found?'Found':'Missing',files.generated_yaml?.found?'diag-good':'diag-warn'),diagTile('Dashboard YAML',files.generated_card?.found?'Found':'Missing',files.generated_card?.found?'diag-good':'diag-warn'),diagTile('Contribution workflow',d.contribution_workflow?.ready?'Ready':'Unavailable',d.contribution_workflow?.ready?'diag-good':'diag-bad'));const messages=$('devicesDiagnosticsMessages');messages.innerHTML='';for(const [kind,items] of [['failure',d.errors||[]],['warning',d.warnings||[]]]){if(!items.length)continue;const box=document.createElement('div');box.className=kind;const ul=document.createElement('ul');ul.className='diag-list';for(const item of items){const li=document.createElement('li');li.textContent=`${kind==='failure'?'ERROR':'WARNING'}: ${item}`;ul.appendChild(li)}box.appendChild(ul);messages.appendChild(box)}}
let lastConfiguredDevices=null;
let lastDevicesDiagnostics=null;
let expandedUnifiedDevices=new Set();
function configuredDeviceTitle(item){return item.display_name||item.switch_name||item.switch_host||'Configured switch'}
function normalizedDeviceIdentity(value){return String(value||'').trim().toLowerCase().replace(/\s+/g,'_').replace(/[^a-z0-9._-]+/g,'_').replace(/_+/g,'_').replace(/^[_ .-]+|[_ .-]+$/g,'')}
function detectedDeviceKey(item){return [item?.data_source||'SNMP',item?.name||'',item?.model||'Unknown model'].join('|')}
function detectedForConfigured(item,detected,used){const identities=[item.switch_name,item.sensor_prefix,item.display_name].map(normalizedDeviceIdentity).filter(Boolean);let matches=detected.map((candidate,index)=>({candidate,index})).filter(({candidate,index})=>!used.has(index)&&candidate?.data_source!=='UniFi API'&&[candidate?.source_switch_name,candidate?.name].map(normalizedDeviceIdentity).some(value=>value&&identities.includes(value)));if(matches.length===1)return {item:matches[0].candidate,index:matches[0].index};const targets=[item.configured_management_target,item.effective_management_target,item.switch_host].map(value=>String(value||'').trim().toLowerCase()).filter(Boolean);matches=detected.map((candidate,index)=>({candidate,index})).filter(({candidate,index})=>!used.has(index)&&candidate?.data_source!=='UniFi API'&&targets.includes(String(candidate?.management_target||'').trim().toLowerCase()));if(matches.length===1)return {item:matches[0].candidate,index:matches[0].index};const configuredModel=String(item.switch_model||'').trim();if(configuredModel&&configuredModel!=='auto'){matches=detected.map((candidate,index)=>({candidate,index})).filter(({candidate,index})=>!used.has(index)&&candidate?.data_source!=='UniFi API'&&String(candidate?.model||'').trim()===configuredModel);if(matches.length===1)return {item:matches[0].candidate,index:matches[0].index}}return null}
function appendDetectedDeviceBody(body,item,d){const normalized={model:item.model,vendor_name:item.name,family:item.family,registry_status:item.registry_status,registry_match:item.registry_match,registry_last_validated_version:item.last_validated_version,physical_count:item.physical_interfaces,rj45_count:item.rj45_interfaces,registry_validation:item.validation};body.appendChild(deviceCard(normalized));const extra=document.createElement('div');extra.className='muted detected-device-extra';extra.textContent=`Source: ${item.data_source||'SNMP'} · ${item.data_source==='UniFi API'?`Firmware: ${item.firmware||'Unknown'}`:`SNMP walk: ${item.walk_found?'Available':'Unavailable'}`} · Uplinks detected: ${item.uplink_interfaces||0} · Mapping profile: ${item.mapping_profile||'Not assigned'} · Calibration profile: ${item.calibration_profile||'Not assigned'}`;body.appendChild(extra)}
function deviceControlsBlocked(){return !!lastDiscoveryState?.running&&lastDiscoveryState?.mode!=='apply_device_state'}
function syncConfiguredDeviceToggleAvailability(){const blocked=deviceControlsBlocked();document.querySelectorAll('.device-state-toggle').forEach(btn=>{const writable=btn.dataset.writable==='true';btn.disabled=blocked||!writable;btn.title=blocked?'Wait for the current Discovery operation before changing device state.':(writable?'Toggle whether this device is actively polled and shown on the Switch Vision dashboard.':'This device cannot be changed from the current Hub state.')});document.querySelectorAll('.device-order-button').forEach(btn=>{const writable=btn.dataset.writable==='true';const boundary=btn.dataset.boundary==='true';btn.disabled=blocked||!writable||boundary;btn.title=blocked?'Wait for the current Discovery operation before changing device order.':(!writable?'This device cannot be reordered from the current Hub state.':(boundary?'Already at this end of the device order.':'Move this device in the persistent dashboard order.'))});const reset=$('resetDeviceOrderButton');if(reset){const writable=!!lastConfiguredDevices?.device_control_writable;reset.disabled=blocked||!writable;reset.title=blocked?'Wait for the current Discovery operation before resetting device order.':'Restore devices to their immutable first-added order.'}}
function unifiedDeviceTitle(row){if(row.configured)return configuredDeviceTitle(row.configured);const item=row.detected||{};return item.name||item.model||'Detected device'}
function buildUnifiedDeviceRows(){const config=lastConfiguredDevices||{},saved=config.devices||[],detected=lastDevicesDiagnostics?.devices||[],used=new Set(),rows=[];for(const item of saved){const found=detectedForConfigured(item,detected,used),detectedItem=found?.item||null;if(found)used.add(found.index);rows.push({key:item.device_key||`snmp:${item.switch_name}`,source:'SNMP',configured:item,detected:detectedItem,enabled:item.enabled!=='disabled',writable:!!config.writable,controllable:true})}for(const [index,item] of detected.entries()){if(used.has(index))continue;if(item?.data_source==='UniFi API'&&item?.unifi_device_id){const key=`unifi:${item.unifi_device_id}`;rows.push({key,source:'UniFi API',configured:null,detected:item,enabled:(config.device_states||{})[key]!=='disabled',writable:!!config.device_control_writable,controllable:true});continue}rows.push({key:`detected|${detectedDeviceKey(item)}`,source:item?.data_source||'SNMP',configured:null,detected:item,enabled:true,writable:false,controllable:false})}const rank=new Map((config.device_order||[]).map((key,index)=>[key,index]));rows.sort((a,b)=>{const ar=rank.has(a.key)?rank.get(a.key):Number.MAX_SAFE_INTEGER,br=rank.has(b.key)?rank.get(b.key):Number.MAX_SAFE_INTEGER;if(ar!==br)return ar-br;return 0});return rows}
function renderUnifiedDevices(){
  const root=$('configuredDevices');if(!root)return;
  for(const entry of root.querySelectorAll('[data-device-key]')){const key=entry.dataset.deviceKey||'';if(key&&entry.dataset.expanded==='true')expandedUnifiedDevices.add(key);else if(key)expandedUnifiedDevices.delete(key)}
  root.innerHTML='';
  const rows=buildUnifiedDeviceRows(),controllable=rows.filter(row=>row.controllable);
  for(const [position,row] of rows.entries()){
    const item=row.configured,detectedItem=row.detected,key=row.key,expanded=expandedUnifiedDevices.has(key),enabled=row.enabled;
    const entry=document.createElement('div');entry.className=`device-card unified-device-details${item?' configured-device':''}${enabled?'':' disabled'}`;entry.dataset.deviceKey=key;entry.dataset.expanded=String(expanded);
    const rowTop=document.createElement('div');rowTop.className='unified-device-row';
    const summary=document.createElement('div');summary.className='unified-device-summary';summary.tabIndex=0;summary.setAttribute('aria-expanded',String(expanded));
    const main=document.createElement('div');main.className='unified-device-main';const title=document.createElement('strong');title.textContent=unifiedDeviceTitle(row);const line=document.createElement('div');line.className='muted';
    if(item){const bits=[item.switch_name,item.sensor_prefix,item.switch_model&&item.switch_model!=='auto'?item.switch_model:'Auto-detect'].filter(Boolean);line.textContent=bits.join(' · ');const management=document.createElement('div');management.className='muted configured-management';const configured=item.configured_management_target||'Not configured';const effective=item.effective_management_target||(item.effective_management_status==='invalid_saved_row'?'Unavailable — saved row needs review':'Not configured');management.textContent=`Configured management IP/host: ${configured} · Effective management IP/host: ${effective}`;main.append(title,line,management);if(detectedItem){const detection=document.createElement('div');detection.className='muted detected-device-generated';detection.textContent=`Detected: ${detectedItem.model||'Unknown model'} · ${statusLabel(detectedItem.registry_status||'detected')} · ${detectedItem.rj45_interfaces||0} RJ45 + ${detectedItem.uplink_interfaces||0} uplinks`;main.append(detection)}else{const detection=document.createElement('div');detection.className='muted detected-device-generated';detection.textContent='Detected hardware details: not available yet';main.append(detection)}}else{line.textContent=`${detectedItem?.model||'Unknown model'} · ${statusLabel(detectedItem?.registry_status||'detected')} · ${detectedItem?.rj45_interfaces||0} RJ45 + ${detectedItem?.uplink_interfaces||0} uplinks`;main.append(title,line)}
    const actions=document.createElement('div');actions.className='unified-device-actions';if(detectedItem){const source=document.createElement('span');source.className='device-source-chip';source.textContent=row.source;actions.append(source)}
    const orderControls=document.createElement('div');orderControls.className='device-order-controls';if(row.controllable){const ci=controllable.indexOf(row);if(ci>0){const up=document.createElement('button');up.type='button';up.className='device-order-button';up.textContent='↑';up.dataset.writable=String(row.writable);up.dataset.boundary='false';up.setAttribute('aria-label',`Move up ${unifiedDeviceTitle(row)}`);up.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();moveConfiguredDevice(row,controllable[ci-1],'up',up)});orderControls.append(up)}if(ci<controllable.length-1){const down=document.createElement('button');down.type='button';down.className='device-order-button';down.textContent='↓';down.dataset.writable=String(row.writable);down.dataset.boundary='false';down.setAttribute('aria-label',`Move down ${unifiedDeviceTitle(row)}`);down.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();moveConfiguredDevice(row,controllable[ci+1],'down',down)});orderControls.append(down)}}
    if(row.controllable){const toggle=document.createElement('button');toggle.type='button';toggle.className=`device-state-toggle ${enabled?'enabled':'disabled'}`;toggle.dataset.writable=String(row.writable);toggle.setAttribute('role','switch');toggle.setAttribute('aria-checked',String(enabled));toggle.setAttribute('aria-label',`${enabled?'Disable':'Enable'} ${unifiedDeviceTitle(row)}`);const track=document.createElement('span');track.className='toggle-track';track.setAttribute('aria-hidden','true');const knob=document.createElement('span');knob.className='toggle-knob';track.appendChild(knob);const label=document.createElement('span');label.textContent=enabled?'Enabled':'Disabled';toggle.append(track,label);toggle.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();setConfiguredDeviceState(row,enabled?'disabled':'enabled',toggle)});actions.append(toggle)}
    const chevron=document.createElement('span');chevron.className='unified-device-chevron';chevron.setAttribute('aria-hidden','true');chevron.textContent='▸';summary.append(main,chevron);rowTop.append(orderControls,summary,actions);
    const body=document.createElement('div');body.className='unified-device-body';body.id=`configured-device-details-${position}`;body.hidden=!expanded;if(detectedItem)appendDetectedDeviceBody(body,detectedItem,lastDevicesDiagnostics||{});else{const empty=document.createElement('p');empty.className='muted';empty.textContent='No current detected-device details are available for this saved switch. Run Discovery to refresh its hardware information.';body.append(empty)}summary.setAttribute('aria-controls',body.id);const setExpanded=open=>{entry.dataset.expanded=String(open);body.hidden=!open;summary.setAttribute('aria-expanded',String(open));if(open)expandedUnifiedDevices.add(key);else expandedUnifiedDevices.delete(key)};summary.addEventListener('click',()=>setExpanded(entry.dataset.expanded!=='true'));summary.addEventListener('keydown',event=>{if(event.target===summary&&(event.key==='Enter'||event.key===' ')){event.preventDefault();setExpanded(entry.dataset.expanded!=='true')}});entry.append(rowTop,body);root.append(entry)
  }
  if(!rows.length)root.innerHTML='<p class="muted">No saved or detected switches are available yet. Add a switch in Discovery Settings or run Discovery.</p>';syncConfiguredDeviceToggleAvailability()
}
function renderConfiguredDevices(d){lastConfiguredDevices=d;renderUnifiedDevices();const status=$('configuredDevicesStatus');if(!d?.switch_list_enabled&&(d?.devices||[]).length)status.textContent='The saved SNMP switch list is globally disabled in Discovery Settings.';else status.textContent='Device order, enabled state, polling state, and Native dashboard card order are linked.'}
async function moveConfiguredDevice(row,destination,direction,button){if(deviceControlsBlocked()){$('configuredDevicesStatus').textContent='Wait for the current Discovery operation before changing device order.';return}button.disabled=true;const title=unifiedDeviceTitle(row);$('configuredDevicesStatus').textContent=`Moving ${title} ${direction}…`;try{const r=await fetch(endpoint('api/configured-devices/order'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({device_key:row.key,destination_device_key:destination.key})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not save device order');renderConfiguredDevices(d);$('configuredDevicesStatus').textContent='Saved device order. Native dashboard order updated.'}catch(e){const failure=`Could not change device order: ${e.message||e}`;await refreshConfiguredDevices(false);$('configuredDevicesStatus').textContent=failure}finally{syncConfiguredDeviceToggleAvailability()}}
async function resetConfiguredDeviceOrder(){if(deviceControlsBlocked()){$('configuredDevicesStatus').textContent='Wait for the current Discovery operation before resetting device order.';return}if(!confirm('Reset device order to the original first-added order?'))return;const btn=$('resetDeviceOrderButton');btn.disabled=true;$('configuredDevicesStatus').textContent='Restoring original first-added device order…';try{const r=await fetch(endpoint('api/configured-devices/reset-order'),{method:'POST'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not reset device order');renderConfiguredDevices(d);$('configuredDevicesStatus').textContent='Device order restored to original first-added order. Native dashboard order updated.'}catch(e){const failure=`Could not reset device order: ${e.message||e}`;await refreshConfiguredDevices(false);$('configuredDevicesStatus').textContent=failure}finally{syncConfiguredDeviceToggleAvailability()}}
async function refreshConfiguredDevices(showStatus=false){if(showStatus)$('configuredDevicesStatus').textContent='Refreshing saved devices…';try{const r=await fetch(endpoint('api/configured-devices'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not load saved devices');renderConfiguredDevices(d)}catch(e){$('configuredDevicesStatus').textContent=`Could not load saved devices: ${e.message||e}`}}
async function setConfiguredDeviceState(row,nextState,button){if(deviceControlsBlocked()){$('configuredDevicesStatus').textContent='Wait for the current Discovery operation before changing device state.';return}button.disabled=true;const title=unifiedDeviceTitle(row);$('configuredDevicesStatus').textContent=`Saving ${title} as ${nextState}…`;try{const r=await fetch(endpoint('api/configured-devices/state'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({device_key:row.key,enabled:nextState})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not save device state');renderConfiguredDevices(d);$('configuredDevicesStatus').textContent=`${title} is now ${nextState}. Background polling sync is queued; you can keep changing devices.`}catch(e){const failure=`Could not change ${title}: ${e.message||e}`;await refreshConfiguredDevices(false);$('configuredDevicesStatus').textContent=failure}finally{syncConfiguredDeviceToggleAvailability()}}
function renderDevices(d){lastDevicesDiagnostics=d;renderDeviceDiagnosticsSummary(d);renderUnifiedDevices()}
async function fetchDiagnosticsData(){const r=await fetch(endpoint('api/diagnostics'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Diagnostics request failed');return d}
async function refreshDevicesData(showStatus=true){if(showStatus)$('devicesActionStatus').textContent='Refreshing devices…';try{const d=await fetchDiagnosticsData();window.latestDiagnostics=d;renderDevices(d);$('downloadDiagnosticsButton').href=endpoint('download/diagnostics.txt');if(showStatus)$('devicesActionStatus').textContent=`Updated ${d.generated_at||''}`}catch(e){if(showStatus)$('devicesActionStatus').textContent=`Could not load devices: ${e}`}}
async function loadDevices(){setView('devices');window.SwitchVisionHubSettings?.selectDevicesTab?.('configure');await Promise.all([refreshConfiguredDevices(true),refreshDevicesData()])}
async function copyTextWithFallback(text){if(navigator.clipboard&&typeof navigator.clipboard.writeText==='function'){try{await navigator.clipboard.writeText(text);return true}catch(_e){}}const area=document.createElement('textarea');area.value=text;area.setAttribute('readonly','');area.style.position='fixed';area.style.left='-9999px';area.style.top='0';area.style.opacity='0';document.body.appendChild(area);area.focus();area.select();area.setSelectionRange(0,area.value.length);let copied=false;try{copied=document.execCommand('copy')}catch(_e){copied=false}document.body.removeChild(area);return copied}
async function copyDiagnostics(){const status=$('devicesActionStatus');status.textContent='Copying diagnostics…';try{const r=await fetch(endpoint('download/diagnostics.txt'),{cache:'no-store'});if(!r.ok)throw new Error(`Diagnostics download failed (${r.status})`);const text=await r.text();const copied=await copyTextWithFallback(text);if(!copied)throw new Error('Clipboard access is unavailable in this browser context');status.textContent='Diagnostics copied to clipboard.'}catch(e){status.textContent=`Could not copy diagnostics: ${e}`}}

function sanitizeDebugText(text){
    let cleaned=String(text||'');

    cleaned=cleaned.replace(
        /((?:community|community_string|password|passwd|token|api[_-]?key|secret|authorization|credential|credentials)\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,;]+)/gi,
        '$1[REDACTED]'
    );

    cleaned=cleaned.replace(
        /(\s(?:-c|--community|-A|--auth-password|-X|--priv-password|--token)\s+)(?:"[^"]*"|'[^']*'|\S+)/gi,
        '$1[REDACTED]'
    );

    cleaned=cleaned.replace(
        /(Authorization:\s*(?:Bearer|Basic)\s+)[^\s]+/gi,
        '$1[REDACTED]'
    );

    cleaned=cleaned.replace(
        /(https?:\/\/)([^\/\s:@]+):([^@\s\/]+)@/gi,
        '$1[REDACTED]:[REDACTED]@'
    );

    return cleaned;
}

async function fetchCurrentDiscoveryDebug(){const r=await fetch(endpoint('api/discovery/debug'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not load Discovery debug session');return d}
async function refreshCurrentDiscoveryDebug(){if(!debugVisible)return;try{const d=await fetchCurrentDiscoveryDebug();const text=String(d.text||'');$('discoveryLog').textContent=text.trimEnd()||'No debug details are available yet.'}catch(e){$('copyDebugStatus').textContent=`Could not refresh debug information: ${e.message||e}`}}
async function copyDebugInfo(){
    const status=$('copyDebugStatus');
    const button=$('copyDebugButton');
    button.disabled=true;
    status.textContent='Loading complete current debug session…';
    try{
        const d=await fetchCurrentDiscoveryDebug();
        const raw=String(d.text||'');
        if(!raw.trim()){status.textContent='No debug information is available to copy.';return}
        const text=['Switch Vision Discovery debug output','',sanitizeDebugText(raw).trim()].join('\n');
        const copied=await copyTextWithFallback(text);
        if(!copied)throw new Error('Clipboard access is unavailable in this browser context');
        button.textContent='Copied ✓';
        status.textContent=`Complete current-session debug copied (${d.line_count||raw.split('\n').length} lines).`;
    }catch(e){
        status.textContent=`Could not copy debug information: ${e.message||e}`;
    }finally{
        setTimeout(()=>{button.disabled=false;button.textContent='Copy Debug Info'},1200);
    }
}
function discoveryStage(state){if(!state.running)return state.success===true?5:-1;if((state.phase||'')==='preparing')return -1;const stage=String(state.stage||'').toLowerCase();if(stage.includes('snmp2mqtt handoff')||stage.includes('support my switch')||stage.includes('finaliz'))return 5;if(stage.includes('generating snmp2mqtt yaml'))return 3;if(stage.includes('generating dashboard card yaml'))return 4;if(stage.includes('detecting exact models'))return 2;if(stage.includes('running snmp walks'))return 1;if(stage.includes('validating configured switches'))return 0;const text=((state.activity||'')+' '+(state.command||'')+' '+(state.message||'')+' '+(state.log_tail||[]).slice(-3).join(' ')).toLowerCase();if(text.includes('snmp2mqtt handoff')||text.includes('support my switch')||text.includes('finaliz'))return 5;if(text.includes('dashboard card')||text.includes('generated dashboard'))return 4;if(text.includes('generated yaml')||text.includes('snmp2mqtt')||text.includes('generator')||text.includes('write_generated_yaml'))return 3;if(text.includes('model/platform')||text.includes('interface mapping')||text.includes('parser summary')||text.includes('exact models'))return 2;if(text.includes('snmp walk')||text.includes('walking')||text.includes('oid trees'))return 1;if(text.includes('configured switches')||text.includes('validating'))return 0;return 0}
function updateSteps(state){const current=discoveryStage(state);for(const el of document.querySelectorAll('#discoverySteps .step')){const n=Number(el.dataset.step);el.classList.toggle('done',state.success===true||(current>=0&&n<current));el.classList.toggle('active',state.running&&(state.phase||'')!=='preparing'&&n===current)} }
let debugVisible=false;
function elapsedText(started,finished=null){if(!started)return '00:00';const start=Date.parse(started);const end=finished?Date.parse(finished):Date.now();if(!Number.isFinite(start)||!Number.isFinite(end))return '00:00';const total=Math.max(0,Math.floor((end-start)/1000));const h=Math.floor(total/3600);const m=Math.floor((total%3600)/60);const s=total%60;return h?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`}
function updateElapsedClock(){const state=lastDiscoveryState||{};if(!$('liveElapsed'))return;$('liveElapsed').textContent=state.running?elapsedText(state.started_at):((state.started_at&&state.finished_at)?elapsedText(state.started_at,state.finished_at):'00:00')}
function startElapsedTicker(){if(elapsedTicker)return;elapsedTicker=setInterval(()=>{if(!document.hidden&&lastDiscoveryState?.running)updateElapsedClock()},250)}
function showDiscovery(d){const state=d||{};lastDiscoveryState=state;const running=!!state.running;const regenYaml=state.mode==='regenerate_yaml';const regenCard=state.mode==='regenerate_card';const applyDeviceState=state.mode==='apply_device_state';const regen=regenYaml||regenCard;const phase=state.phase||(running?'running':(state.success===true?'complete':(state.success===false?'failed':'idle')));const preparing=running&&phase==='preparing';const stopping=running&&phase==='stopping';const active=running&&!preparing&&!stopping;const btn=$('runDiscoveryButton');const regenBtn=$('regenerateYamlButton');const cardBtn=$('regenerateCardYamlButton');const stopBtn=$('stopDiscoveryButton');btn.disabled=running;regenBtn.disabled=running;cardBtn.disabled=running;btn.textContent=preparing&&!regen?'Preparing…':(stopping?'Stopping…':(active&&!regen?'Discovery Running…':'Run Discovery'));regenBtn.textContent=regenYaml&&preparing?'Preparing…':(regenYaml&&active?'Regenerating…':'Regenerate SNMP2MQTT YAML');cardBtn.textContent=regenCard&&preparing?'Preparing…':(regenCard&&active?'Regenerating…':'Regenerate Dashboard Card YAML');stopBtn.disabled=!running||stopping||applyDeviceState;stopBtn.textContent=applyDeviceState&&running?'Applying changes…':(stopping?'Stopping…':'Stop Discovery');const modeLabel=applyDeviceState?'Device state application':(regenCard?'Dashboard Card YAML regeneration':(regenYaml?'SNMP2MQTT YAML regeneration':'Discovery'));let label='Idle / Ready';if(preparing)label=`Preparing ${modeLabel}`;else if(stopping)label=`Stopping ${modeLabel}`;else if(active)label=applyDeviceState?'Applying device changes':(regen?`${modeLabel} running`:'Discovery running');else if(phase==='stopped')label=`${modeLabel} stopped`;else if(state.success===true)label=`${modeLabel} complete`;else if(state.success===false)label=`${modeLabel} failed: ${state.message||'Unknown error'}`;$('discoveryStatus').textContent=label;$('homeStatus').textContent=applyDeviceState&&running?'Applying device changes':(preparing?'Preparing Discovery':(stopping?'Stopping Discovery':(active?'Discovery running':(phase==='stopped'?'Discovery stopped':(state.success===true?'Last discovery complete':(state.success===false?'Discovery needs attention':'Ready'))))));$('homeStatusDot').className=`status-dot${running?' running':(state.success===false?' failed':'')}`;$('liveStage').textContent=preparing?`Preparing ${modeLabel}`:(state.stage||label);$('liveSwitch').textContent=preparing?'Waiting':(state.switch||(!running&&state.success===true?'All configured switches':'Not running'));$('liveTarget').textContent=preparing?'Waiting':(state.target||'Not running');$('liveActivity').textContent=preparing?(regenCard?'Loading saved Discovery state and stored walks':(regenYaml?'Loading saved Discovery data and SNMP walks':'Validating configured switches')):(state.activity||label);$('liveCommand').textContent=preparing?'Not started':(state.command||'No command running');$('liveRunStatus').textContent=preparing?'Preparing':(stopping?'Stopping':(active?'Running':(phase==='stopped'?'Stopped':(state.success===true?'Complete':(state.success===false?'Failed':'Idle / Ready')))));const snmp=state.snmp2mqtt||{};$('liveSnmp2mqtt').textContent=snmp.message||snmp.status||'Waiting for Discovery';updateElapsedClock();const lines=state.log_tail||[];if(!debugVisible)$('discoveryLog').textContent=lines.length?lines.join('\n'):'No debug details are available yet.';updateSteps(state);syncConfiguredDeviceToggleAvailability()}
function discoveryHistoryModeLabel(mode){return mode==='apply_device_state'?'Device state application':(mode==='regenerate_card'?'Dashboard Card YAML regeneration':(mode==='regenerate_yaml'?'SNMP2MQTT YAML regeneration':'Discovery'))}
function discoveryHistoryStatusLabel(status){return status==='complete'?'Complete':(status==='failed'?'Failed':(status==='stopped'?'Stopped':'Unknown'))}
function discoveryHistoryDuration(seconds){const total=Number(seconds);if(!Number.isFinite(total)||total<0)return 'Unknown';const h=Math.floor(total/3600),m=Math.floor((total%3600)/60),s=Math.floor(total%60);return h?`${h}h ${m}m ${s}s`:(m?`${m}m ${s}s`:`${s}s`)}
function discoveryHistoryFriendlyTime(value){const raw=String(value||'').trim();if(!raw)return 'Unknown time';const normalized=/[+-]\d{4}$/.test(raw)?raw.replace(/([+-]\d{2})(\d{2})$/,'$1:$2'):raw;const date=new Date(normalized);if(Number.isNaN(date.getTime()))return raw;try{return new Intl.DateTimeFormat(undefined,{day:'numeric',month:'short',year:'numeric',hour:'numeric',minute:'2-digit'}).format(date)}catch(_error){return date.toLocaleString()}}
let expandedDiscoveryHistoryEntries=new Set();
function discoveryHistoryKey(item){return [item?.mode||'discovery',item?.started_at||'',item?.finished_at||'',item?.status||''].join('|')}
function renderDiscoveryHistory(history){const root=$('discoveryHistory');if(!root)return;for(const entry of root.querySelectorAll('details[data-history-key]')){const key=entry.dataset.historyKey||'';if(!key)continue;if(entry.open)expandedDiscoveryHistoryEntries.add(key);else expandedDiscoveryHistoryEntries.delete(key)}const items=Array.isArray(history?.items)?history.items:[];root.innerHTML='';if(!items.length){const empty=document.createElement('p');empty.className='muted';empty.textContent='No completed Discovery operations are recorded yet.';root.append(empty);return}for(const item of [...items].reverse()){const key=discoveryHistoryKey(item);const entry=document.createElement('details');entry.className='device-card discovery-history-entry';entry.dataset.historyKey=key;entry.open=expandedDiscoveryHistoryEntries.has(key);entry.addEventListener('toggle',()=>{if(entry.open)expandedDiscoveryHistoryEntries.add(key);else expandedDiscoveryHistoryEntries.delete(key)});const summary=document.createElement('summary');const title=document.createElement('strong');const rawTime=String(item.finished_at||item.started_at||'').trim();title.textContent=`${discoveryHistoryModeLabel(item.mode)} | ${discoveryHistoryStatusLabel(item.status)} | ${discoveryHistoryFriendlyTime(rawTime)}`;if(rawTime)title.title=`Raw timestamp: ${rawTime}`;summary.append(title);entry.append(summary);const meta=document.createElement('div');meta.className='muted';const bits=[`Duration: ${discoveryHistoryDuration(item.duration_seconds)}`,item.stage?`Stage: ${item.stage}`:'',item.switch?`Switch: ${item.switch}`:'',item.target?`Target: ${item.target}`:''].filter(Boolean);meta.textContent=bits.join(' | ');entry.append(meta);if(item.message){const message=document.createElement('p');message.textContent=item.message;entry.append(message)}const snmp=item.snmp2mqtt||{};if(snmp.message||snmp.status){const line=document.createElement('div');line.className='muted';line.textContent=`SNMP2MQTT: ${snmp.message||snmp.status}`;entry.append(line)}const lines=Array.isArray(item.debug_tail)?item.debug_tail:[];if(lines.length){const heading=document.createElement('strong');heading.textContent='Credential-sanitized debug excerpt';const pre=document.createElement('pre');pre.className='code-preview';pre.textContent=lines.join('\n');entry.append(heading,pre)}root.append(entry)}}
function generatedDashboardExportMode(){return $('generatedDashboardExportMode')?.value==='dashboard'?'dashboard':'custom-dashboard'}
function syncGeneratedDashboardExportMode(announce=false){const custom=generatedDashboardExportMode()==='custom-dashboard';const link=$('downloadGeneratedDashboardYamlButton');if(link)link.href=endpoint(custom?'download/switch-vision-custom-dashboard.yaml':'download/switch-vision-dashboard.yaml');const status=$('generatedCardYamlActionStatus');if(announce&&status&&!$('generatedCardYamlPreview')?.classList.contains('hidden'))status.textContent=`Preview format changed to ${custom?'Custom dashboard (Layout Card)':'Standard dashboard'}. Click Preview Dashboard YAML to refresh.`}
async function loadGeneratedCardYamlStatus(){const status=$('generatedCardYamlActionStatus');const preview=$('generatedCardYamlPreview');try{const r=await fetch(endpoint('api/generated-card-yaml/status'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not read generated Dashboard YAML status');const found=!!d.generated?.found;const valid=!!d.validation?.valid;const modified=d.generated?.modified||null;$('generatedCardYamlState').textContent=found?`${d.generated.path||'generated-dashboard-card.yaml'} · ${d.generated.size||0} bytes`:'Not generated';$('generatedCardYamlValidation').textContent=valid?`Valid · ${d.validation?.documents||1} YAML document${(d.validation?.documents||1)===1?'':'s'}`:`Invalid · ${d.validation?.error||'validation failed'}`;$('generatedCardYamlUpdated').textContent=modified||'Not available';syncGeneratedDashboardExportMode();if(!found||!valid){preview.textContent='';preview.classList.add('hidden');status.textContent=!found?'Run Discovery to generate Dashboard YAML.':`Generated Dashboard YAML is not available for export: ${d.validation?.error||'validation failed'}`}else{if(generatedCardYamlModified&&modified!==generatedCardYamlModified&&!preview.classList.contains('hidden')){preview.textContent=await fetchGeneratedDashboardExport(generatedDashboardExportMode());status.textContent='Dashboard YAML export preview refreshed.'}else if(status.textContent.startsWith('Could not load')||status.textContent.startsWith('Generated Dashboard YAML is not available'))status.textContent=''}generatedCardYamlModified=modified}catch(e){preview.textContent='';preview.classList.add('hidden');status.textContent=`Could not load generated Dashboard YAML status: ${e}`}}
async function fetchGeneratedDashboardExport(mode='custom-dashboard'){const path=mode==='cards'?'api/generated-card-yaml/cards-export':(mode==='dashboard'?'api/generated-card-yaml/dashboard-export':'api/generated-card-yaml/custom-dashboard-export');const r=await fetch(endpoint(path),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Dashboard YAML export failed');return d.text||''}
async function previewGeneratedDashboardYaml(){const status=$('generatedCardYamlActionStatus');try{const mode=generatedDashboardExportMode();const text=await fetchGeneratedDashboardExport(mode);$('generatedCardYamlPreview').textContent=text;$('generatedCardYamlPreview').classList.remove('hidden');status.textContent=`${mode==='custom-dashboard'?'Custom dashboard':'Standard dashboard'} YAML export preview loaded.`}catch(e){status.textContent=`Could not preview Dashboard YAML: ${e}`}}
async function copyGeneratedDashboardYaml(){const status=$('generatedCardYamlActionStatus');status.textContent='Copying Dashboard YAML…';try{const mode=generatedDashboardExportMode();const text=await fetchGeneratedDashboardExport(mode);const copied=await copyTextWithFallback(text);if(!copied)throw new Error('Clipboard access is unavailable in this browser context');$('generatedCardYamlPreview').textContent=text;$('generatedCardYamlPreview').classList.remove('hidden');status.textContent=`${mode==='custom-dashboard'?'Custom dashboard':'Standard dashboard'} YAML copied. Paste it into a new Home Assistant dashboard Raw configuration editor.`}catch(e){status.textContent=`Could not copy Dashboard YAML: ${e}`}}
async function copyGeneratedCardsOnly(){const status=$('generatedCardYamlActionStatus');status.textContent='Copying generated cards…';try{const text=await fetchGeneratedDashboardExport('cards');const copied=await copyTextWithFallback(text);if(!copied)throw new Error('Clipboard access is unavailable in this browser context');$('generatedCardYamlPreview').textContent=text;$('generatedCardYamlPreview').classList.remove('hidden');status.textContent="Cards copied. Paste these list entries beneath the target Home Assistant view's cards: key."}catch(e){status.textContent=`Could not copy generated cards: ${e}`}}
async function loadGeneratedYamlStatus(){try{const r=await fetch(endpoint('api/generated-yaml/status'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not read generated YAML status');const applicable=d.applicable!==false;const found=!!d.generated?.found;const description=$('generatedYamlDescription');const actions=$('generatedYamlActions');const regen=$('regenerateYamlButton');const regenHelp=$('regenerateYamlHelp');const preview=$('generatedYamlPreview');const actionStatus=$('generatedYamlActionStatus');if(!applicable){$('generatedYamlState').textContent='Not in use';$('generatedYamlValidation').textContent=`Not applicable · ${d.reason||'No enabled SNMP targets are configured.'}`;$('generatedYamlUpdated').textContent='Not applicable';if(description)description.textContent='SNMP2MQTT YAML is only required for switches using the SNMP data path. UniFi API devices use UniFi2MQTT and do not require this file.';if(actions)actions.hidden=true;if(regen)regen.hidden=true;if(regenHelp)regenHelp.hidden=true;preview.textContent='';preview.classList.add('hidden');actionStatus.textContent='No SNMP2MQTT YAML action is required for this installation.';$('liveSnmp2mqtt').textContent='Not in use · no enabled SNMP targets';return}if(description)description.textContent='Discovery writes the file used by the SNMP2MQTT generated-YAML import option. After a successful SNMP Discovery run, Switch Vision validates the YAML and automatically starts or restarts the SNMP2MQTT app.';if(actions)actions.hidden=false;if(regen)regen.hidden=false;if(regenHelp)regenHelp.hidden=false;actionStatus.textContent='';$('generatedYamlState').textContent=found?`${d.generated.path||'generated-snmp2mqtt.yaml'} · ${d.generated.size||0} bytes`:'Not generated';$('generatedYamlValidation').textContent=d.validation?.valid?'Valid':`Invalid · ${d.validation?.error||'validation failed'}`;$('generatedYamlUpdated').textContent=d.generated?.modified||'Not available';$('downloadGeneratedYamlButton').href=endpoint('download/generated-snmp2mqtt.yaml')}catch(e){$('generatedYamlActionStatus').textContent=`Could not load generated YAML status: ${e}`}}
async function previewGeneratedYaml(){const status=$('generatedYamlActionStatus');try{const r=await fetch(endpoint('api/generated-yaml/preview'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Preview failed');$('generatedYamlPreview').textContent=d.text||'';$('generatedYamlPreview').classList.remove('hidden');status.textContent='Generated YAML preview loaded.'}catch(e){status.textContent=`Could not preview generated YAML: ${e}`}}
async function toggleDebug(){debugVisible=!debugVisible;$('debugWrap').classList.toggle('hidden',!debugVisible);$('toggleDebugButton').textContent=debugVisible?'Hide Debug':'Show Debug';if(debugVisible)await refreshCurrentDiscoveryDebug()}
async function startDashboardCardYamlRegeneration(btn,status){if(!btn||!status)return;btn.disabled=true;status.textContent='Preparing stored-state Dashboard Card YAML regeneration…';try{const r=await fetch(endpoint('api/discovery/regenerate-card'),{method:'POST'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not start Dashboard Card YAML regeneration');status.textContent='Dashboard Card YAML regeneration started from the current saved device state. No Discovery run or new SNMP walks are required, and SNMP2MQTT will not be restarted.';await refresh()}catch(e){status.textContent=`Could not regenerate Dashboard Card YAML: ${e.message||e}`;btn.disabled=false}}
async function regenerateDashboardCardYaml(){await startDashboardCardYamlRegeneration($('regenerateCardYamlButton'),$('regenerateCardYamlStatus'))}
async function regenerateDashboardCardYamlFromDevices(){await startDashboardCardYamlRegeneration($('devicesRegenerateCardYamlButton'),$('devicesActionStatus'))}
async function regenerateSnmp2mqttYaml(){const btn=$('regenerateYamlButton');const status=$('regenerateYamlStatus');btn.disabled=true;status.textContent='Preparing stored-walk YAML regeneration…';try{const r=await fetch(endpoint('api/discovery/regenerate-yaml'),{method:'POST'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not start YAML regeneration');status.textContent='Regeneration started. Existing saved walks are being reprocessed; no SNMP walks will run.';await refresh()}catch(e){status.textContent=`Could not regenerate SNMP2MQTT YAML: ${e.message||e}`;btn.disabled=false}}
async function runDiscovery(){const btn=$('runDiscoveryButton');btn.disabled=true;$('discoveryStatus').textContent='Preparing Discovery';try{const r=await fetch(endpoint('api/discovery/start'),{method:'POST'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not start Discovery');await refresh()}catch(e){$('discoveryStatus').textContent=`Could not start Discovery: ${e}`;btn.disabled=false}}
async function stopDiscovery(){const btn=$('stopDiscoveryButton');btn.disabled=true;$('discoveryStatus').textContent='Stopping Discovery';try{const r=await fetch(endpoint('api/discovery/stop'),{method:'POST'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not stop Discovery');await refresh()}catch(e){$('discoveryStatus').textContent=`Could not stop Discovery: ${e}`;btn.disabled=false}}
async function resetSnmpDiscoveryData(){const btn=$('resetSnmpDiscoveryButton');const status=$('resetSnmpDiscoveryStatus');if(lastDiscoveryState?.running){status.textContent='Stop Discovery before resetting SNMP data.';return}if(!confirm('Reset SNMP Discovery data? This stops Switch Vision SNMP2MQTT, removes identifiable retained SNMP2MQTT Home Assistant discovery entities, deletes saved SNMP walk/capability/generated SNMP data, and clears the generated card for a clean rebuild. UniFi data and settings are preserved.'))return;btn.disabled=true;status.textContent='Resetting SNMP Discovery data…';try{const r=await fetch(endpoint('api/discovery/reset-snmp'),{method:'POST'});const d=await r.json();if(!r.ok)throw new Error(d.error||'SNMP reset failed');const warning=(d.warnings||[]).length?` Warnings: ${(d.warnings||[]).join(' | ')}`:'';status.textContent=`SNMP reset complete. MQTT entities retired: ${d.mqtt_topics_cleared||0}/${d.mqtt_topics_found||0}. Saved walk entries removed: ${d.walk_entries_removed||0}. Capability entries removed: ${d.capability_entries_removed||0}.${warning} Run Discovery to rebuild from the currently enabled sources.`;await Promise.all([loadGeneratedCardYamlStatus(),loadGeneratedYamlStatus(),refreshDevicesData(false)])}catch(e){status.textContent=`Could not reset SNMP Discovery data: ${e.message||e}`}finally{btn.disabled=false}}

async function importConfiguration(){const file=$('configurationFile').files[0];const status=$('configurationStatus');if(!file){status.textContent='Choose a configuration JSON file first.';return}if(file.size>128*1024*1024){status.textContent='Configuration backup is too large.';return}if(!confirm('Restore this Switch Vision configuration? Complete backups overwrite matching non-secret component settings and restore calibration profiles/assets. Saved credentials are never imported.'))return;const btn=$('importConfigurationButton');btn.disabled=true;status.textContent='Restoring Switch Vision configuration…';try{const text=await file.text();const data=JSON.parse(text);const r=await fetch(endpoint('api/configuration/import'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const d=await r.json();if(!r.ok)throw new Error(d.error||'Import failed');if(d.format==='legacy-discovery'){status.textContent=`Imported legacy Discovery configuration with ${d.switch_count||0} configured switch(es).`;return}const requirements=Array.isArray(d.credential_requirements)?d.credential_requirements:[];const pending=(Number(d.pending_discovery_switches||0)+Number(d.pending_unifi_controllers||0));const warnings=Array.isArray(d.warnings)&&d.warnings.length?` Warnings: ${d.warnings.join(' | ')}`:'';status.textContent=`Complete restore finished: ${(d.restored_components||[]).join(', ')||'configuration'} · ${d.calibration_profile_count||0} calibration profile(s) · ${d.asset_count||0} custom asset(s). ${requirements.length} credential${requirements.length===1?'':'s'} require re-entry${pending?`; ${pending} device/controller row${pending===1?'':'s'} restored pending credentials`:''}.${warnings}`;appLinksCache=null}catch(e){status.textContent=`Could not import configuration: ${e.message||e}`}finally{btn.disabled=false}}
async function importSwitchesConfiguration(){
const file=$('switchesConfigurationFile').files?.[0]||null,status=$('switchesConfigurationStatus'),button=$('importSwitchesButton');
if(!file){status.textContent='Choose a switch configuration JSON file first.';return}
if(file.size>4*1024*1024){status.textContent='Switch configuration file is too large.';return}
if(!confirm('Import these saved switch definitions and stack-member display mappings? SNMP communities are never imported and must be entered for any new switch before saving Device Configuration.'))return;
button.disabled=true;status.textContent='Importing switch configuration…';
try{
 const data=JSON.parse(await file.text());
 const r=await fetch(endpoint('api/switches/import'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
 const d=await r.json();if(!r.ok)throw new Error(d.error||'Switch configuration import failed');
 status.textContent=`Imported ${d.switch_count||0} switch definition(s) and ${d.stack_member_count||0} stack-member display mapping(s). Open Devices → Configure Devices, enter any missing SNMP communities, then save Device Configuration.`;
 await window.SwitchVisionHubSettings?.loadDeviceConfiguration?.();
}catch(e){status.textContent=`Could not import switch configuration: ${e.message||e}`}
finally{button.disabled=false}
}

function schedulePoll(running=lastRunning){if(polling){clearTimeout(polling);polling=null}if(document.hidden)return;polling=setTimeout(refresh,running?1000:5000)}
function syncHubRuntimeVersion(runtimeVersion){const running=String(runtimeVersion||'').trim(),loaded=HUB_DOCUMENT_VERSION;if(!running||!loaded||running==='unknown'||loaded==='unknown'||running===loaded){try{sessionStorage.removeItem(HUB_VERSION_RELOAD_KEY)}catch(_e){}return false}const token=`${loaded}->${running}`;let previous='';try{previous=sessionStorage.getItem(HUB_VERSION_RELOAD_KEY)||''}catch(_e){}if(previous===token)return false;try{sessionStorage.setItem(HUB_VERSION_RELOAD_KEY,token)}catch(_e){}window.location.reload();return true}
async function refresh(){if(refreshInFlight)return;refreshInFlight=true;try{const r=await fetch(endpoint('api/status'),{cache:'no-store'});const d=await r.json();if(syncHubRuntimeVersion(d.version))return;if(!window.SwitchVisionHubSettings?.hasUnsavedCore?.()){if(d.ui_preferences?.density)syncDensityUi(d.ui_preferences.density);if(d.ui_preferences?.content_width)syncContentWidthUi(d.ui_preferences.content_width)}setUnifiHomeCardVisibility(d.ui_preferences?.show_unifi_integration!==false);if(d.ui_preferences?.show_unifi_integration!==false)await refreshUnifiHomeCard();if(!defaultsLoaded)setForm(d.defaults);showDiscovery(d.discovery);renderDiscoveryHistory(d.discovery_history||{});if(debugVisible)await refreshCurrentDiscoveryDebug();const contributionRunning=!!d.job.running;const discoveryRunning=!!d.discovery?.running;lastRunning=contributionRunning||discoveryRunning;$('createButton').disabled=contributionRunning;if(contributionRunning&&currentView!=='discovery')setView('progress');$('progressMessage').textContent=d.job.message||'Working…';$('logTail').textContent=(d.job.log_tail||[]).join('\n');if(!contributionRunning&&d.job.success===false&&currentView==='progress'){$('progressMessage').textContent=`Failed: ${d.job.message}`}if(!contributionRunning){showLatest(d.latest);if(d.job.success===true&&d.latest&&currentView==='progress')setView('ready')}if(currentView==='devices')await refreshDevicesData(false);else if(currentView==='discovery')await Promise.all([loadGeneratedCardYamlStatus(),loadGeneratedYamlStatus()])}catch(e){if(currentView==='progress')$('progressMessage').textContent=`Could not contact Support My Switch: ${e}`;else $('homeStatus').textContent=`Connection problem: ${e}`}finally{refreshInFlight=false;schedulePoll(lastRunning)}}
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(polling){clearTimeout(polling);polling=null}}else{updateElapsedClock();refresh()}});window.addEventListener('focus',()=>{if(!document.hidden){updateElapsedClock();refresh()}});
async function create(){const btn=$('createButton');btn.disabled=true;setView('progress');$('progressMessage').textContent='Starting…';try{const r=await fetch(endpoint('api/create'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload())});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not start contribution');await refresh()}catch(e){$('progressMessage').textContent=`Could not start: ${e}`;btn.disabled=false}}
const DISCOVERY_TOOLTIP_HELP={runDiscoveryButton:'Contact each enabled switch, collect current evidence, identify hardware, and regenerate Switch Vision outputs.',regenerateYamlButton:'Rebuild SNMP2MQTT YAML from saved Discovery evidence without running new SNMP walks.',regenerateCardYamlButton:'Rebuild dashboard-card YAML from saved Discovery evidence without running new SNMP walks.',previewGeneratedDashboardYamlButton:'Preview the selected new-dashboard export format before pasting it into Home Assistant.',copyGeneratedDashboardYamlButton:'Copy the selected complete dashboard format for Home Assistant Raw configuration editor.',copyGeneratedCardsOnlyButton:"Copy only the generated card list for pasting beneath an existing view's cards: key.",downloadGeneratedDashboardYamlButton:'Download the selected complete Home Assistant dashboard export.',generatedDashboardExportMode:'Choose Custom dashboard to preserve the generated vertical Layout Card view, or Standard dashboard to remove that third-party view dependency.',stopDiscoveryButton:'Request a clean stop of the active Discovery or regeneration operation.',viewResultsButton:'Open the unified Devices list and current detected hardware details.',toggleDebugButton:'Show the complete credential-sanitized debug session for the current or most recent operation.',copyDebugButton:'Copy the complete current-session credential-sanitized debug output.',devicesRunDiscoveryButton:'Start a fresh Discovery run for the currently enabled saved switches.',resetDeviceOrderButton:'Restore the device list and Native dashboard to immutable first-added order.',devicesRegenerateCardYamlButton:'Regenerate the dashboard card from current saved device order/state.',copyDiagnosticsButton:'Copy the privacy-safe Switch Vision diagnostics report.',resetSnmpDiscoveryButton:'Retire known Switch Vision SNMP MQTT entities and clear saved SNMP Discovery state for a clean rebuild.',addUnifiControllerButton:'Add another Local or Remote UniFi controller/site to this UniFi2MQTT instance.',testUnifiLocalButton:'Test Local UniFi API reachability, authentication, site resolution, and adopted-device access without saving.',testUnifiRemoteButton:'Test Remote Site Manager reachability, authentication, host/site resolution, and adopted-device access without saving.',unifi_priority_transport:'The connection path tried first on every UniFi poll.',unifi_fallback_transport:'The alternate connection used only when the priority path is unavailable.',unifi_local_controller_url:'Local UniFi Network Integration API origin. Self-hosted controllers normally use HTTPS port 11443.',unifi_remote_host_id:'UniFi Site Manager console host selector; auto is recommended when unambiguous.'};
function installDiscoveryTooltips(root=document){const selector='button,input,select,a.button,summary';for(const el of root.querySelectorAll?root.querySelectorAll(selector):[]){if(el.title)continue;let help=DISCOVERY_TOOLTIP_HELP[el.id]||'';const label=el.closest?.('label');if(!help&&label){const small=label.querySelector('small');if(small)help=small.textContent.trim()}if(help)el.title=help}}
const discoveryTooltipObserver=new MutationObserver(records=>{for(const record of records)for(const node of record.addedNodes)if(node.nodeType===Node.ELEMENT_NODE){if(node.matches?.('button,input,select,a.button,summary'))installDiscoveryTooltips(node.parentElement||document);else installDiscoveryTooltips(node)}});discoveryTooltipObserver.observe(document.body,{childList:true,subtree:true});installDiscoveryTooltips(document);
$('themeSelect').addEventListener('change',e=>applyManagementTheme(e.target.value));initManagementTheme();$('hubMotdToggle').addEventListener('click',toggleHubMotdVisibility);initHubMotdVisibility();syncDensityUi([...document.body.classList].find(v=>v.startsWith('density-'))?.slice(8)||'comfortable');for(const id of ['mask_management_ips','mask_mac_addresses','mask_hostnames'])$(id).addEventListener('change',updateWarning);$('contributor_type').addEventListener('change',updateRecognition);$('createButton').addEventListener('click',create);$('createAnother').addEventListener('click',()=>setView('support'));$('backButton').addEventListener('click',goBack);$('openDiscoveryButton').addEventListener('click',()=>{setView('discovery');Promise.all([loadGeneratedCardYamlStatus(),loadGeneratedYamlStatus()])});$('openDevicesButton').addEventListener('click',loadDevices);$('openSupportButton').addEventListener('click',()=>setView('support'));$('runDiscoveryButton').addEventListener('click',runDiscovery);$('regenerateYamlButton').addEventListener('click',regenerateSnmp2mqttYaml);$('regenerateCardYamlButton').addEventListener('click',regenerateDashboardCardYaml);$('stopDiscoveryButton').addEventListener('click',stopDiscovery);$('resetSnmpDiscoveryButton').addEventListener('click',resetSnmpDiscoveryData);$('viewResultsButton').addEventListener('click',loadDevices);$('toggleDebugButton').addEventListener('click',toggleDebug);$('copyDebugButton').addEventListener('click',copyDebugInfo);$('generatedDashboardExportMode').addEventListener('change',()=>syncGeneratedDashboardExportMode(true));$('previewGeneratedDashboardYamlButton').addEventListener('click',previewGeneratedDashboardYaml);$('copyGeneratedDashboardYamlButton').addEventListener('click',copyGeneratedDashboardYaml);$('copyGeneratedCardsOnlyButton').addEventListener('click',copyGeneratedCardsOnly);$('previewGeneratedYamlButton').addEventListener('click',previewGeneratedYaml);$('devicesRunDiscoveryButton').addEventListener('click',()=>{setView('discovery');runDiscovery()});$('refreshDevicesButton').addEventListener('click',loadDevices);$('resetDeviceOrderButton').addEventListener('click',resetConfiguredDeviceOrder);$('devicesRegenerateCardYamlButton').addEventListener('click',regenerateDashboardCardYamlFromDevices);$('openCreditsButton').addEventListener('click',()=>{setView('credits');startCreditsV25Animation()});$('openIntegrationSettingsButton').addEventListener('click',()=>window.SwitchVisionHubSettings?.open('core'));$('openUnifi2mqttSettingsButton').addEventListener('click',()=>{const btn=$('openUnifi2mqttSettingsButton');if(btn?.dataset.unifiAction==='blocked')return;loadUnifi2mqttSettings()});$('saveUnifi2mqttButton').addEventListener('click',saveUnifi2mqttSettings);$('testUnifiLocalButton').addEventListener('click',()=>testUnifiConnection('local'));$('testUnifiRemoteButton').addEventListener('click',()=>testUnifiConnection('remote'));$('clearUnifiConnectionTestDebugButton').addEventListener('click',clearUnifiConnectionTestDebug);$('addUnifiControllerButton').addEventListener('click',addUnifiController);$('unifi_priority_transport').addEventListener('change',syncUnifiFallbackOptions);$('installUnifi2mqttButton').addEventListener('click',installUnifi2mqtt);$('openUnifiAppConfigButton').addEventListener('click',openUnifiAppConfig);$('importConfigurationButton').addEventListener('click',importConfiguration);$('importSwitchesButton').addEventListener('click',importSwitchesConfiguration);$('copyDiagnosticsButton').addEventListener('click',copyDiagnostics);$('hubSharedPrimary').addEventListener('click',runSharedHubPrimary);$('hubSharedReload').addEventListener('click',reloadSharedHubView);$('hubSharedBack').addEventListener('click',goBack);installStaticSecretControls();setView('home');startElapsedTicker();refresh();
</script>
<script src="credits_v25.js"></script>
<script>
(()=>{'use strict';const q=id=>document.getElementById(id),clone=v=>JSON.parse(JSON.stringify(v)),dirty=new Set(),state={core:null,snmp2mqtt:null,discovery:null,models:[],order:[],activeTab:'core'},expandedDiscoverySwitches=new Set();const L={show_all_switch_vision_sidebar_items:'Show all Switch Vision sidebar items',show_panel_in_sidebar:'Show native Switch Vision in sidebar',show_lovelace_dashboard_in_sidebar:'Show Switch Vision dashboard in sidebar',show_hub_in_sidebar:'Show Switch Vision Hub in sidebar',show_installer_in_sidebar:'Show Switch Vision Installer in sidebar',show_dashboard_header:'Show dashboard header',native_header_show_summary:'Show summary',native_header_show_refresh:'Show refresh',native_header_show_version:'Show version',native_header_shortcut_switch_vision_settings:'Switch Vision Settings shortcut',native_header_shortcut_hub:'Hub shortcut',native_header_shortcut_maintenance:'Maintenance shortcut',native_header_shortcut_discovery_settings:'Discovery Settings shortcut',native_header_shortcut_installer:'Installer shortcut',native_header_shortcut_installer_settings:'Installer Settings shortcut',native_header_shortcut_snmp2mqtt_settings:'SNMP2MQTT Settings shortcut',native_header_shortcut_unifi2mqtt_settings:'UniFi2MQTT Settings shortcut',show_calibration_buttons:'Show calibration buttons on cards',show_card_headers:'Show card headers'};const H={
'Show all Switch Vision sidebar items':'Master switch for the individual Switch Vision sidebar entries below. Turn this off to hide all optional Switch Vision sidebar shortcuts at once.',
'Show native Switch Vision in sidebar':'Shows the Native Switch Vision dashboard entry in the Home Assistant sidebar.',
'Show Switch Vision dashboard in sidebar':'Shows the generated Switch Vision Lovelace dashboard entry in the Home Assistant sidebar.',
'Show Switch Vision Hub in sidebar':'Shows Switch Vision Hub in the Home Assistant sidebar.',
'Show Switch Vision Installer in sidebar':'Shows Switch Vision Installer in the Home Assistant sidebar when the Installer is available.',
'Show dashboard header':'Shows or hides the Native Switch Vision header above the switch cards.',
'Show summary':'Shows the Native dashboard summary information in the header.',
'Show refresh':'Shows the manual refresh control in the Native dashboard header.',
'Show version':'Shows the current Switch Vision version in the Native dashboard header.',
'Switch Vision Settings shortcut':'Shows a shortcut from the Native dashboard header to Switch Vision settings.',
'Hub shortcut':'Shows a shortcut from the Native dashboard header to Switch Vision Hub.',
'Maintenance shortcut':'Shows a shortcut from the Native dashboard header to Switch Vision Maintenance.',
'Discovery Settings shortcut':'Shows a shortcut from the Native dashboard header directly to Discovery settings.',
'Installer shortcut':'Shows a shortcut from the Native dashboard header to Switch Vision Installer.',
'Installer Settings shortcut':'Shows a shortcut from the Native dashboard header directly to Installer settings.',
'SNMP2MQTT Settings shortcut':'Shows a shortcut from the Native dashboard header directly to SNMP2MQTT settings.',
'UniFi2MQTT Settings shortcut':'Shows a shortcut from the Native dashboard header directly to UniFi2MQTT settings.',
'Show calibration buttons on cards':'Shows the Calibration button on switch cards. This changes presentation only; saved calibration profiles are not removed when hidden.',
'Show card headers':'Shows the title/header area above each Switch Vision card.',
'Faceplate width':'Sets the maximum rendered faceplate/card width. Height and calibrated geometry scale proportionally.',
'Custom faceplate width (px)':'Sets the exact maximum rendered width used when Faceplate width is Custom. The value is remembered when you switch to another preset.',
'Sensitivity preset':'Chooses the traffic-utilisation thresholds used to classify port activity. Low is calmer, Normal is balanced, High reacts to lighter traffic, and Custom uses the two threshold fields.',
'Slow activity maximum (%)':'In Custom sensitivity mode, traffic below this percentage of negotiated link speed stays in the Slow activity band. Lower values make Medium activity easier to reach.',
'Medium activity maximum (%)':'In Custom sensitivity mode, traffic at or above this percentage of negotiated link speed enters the Fast activity band. Keep it above the Slow threshold.',
'Slow blink period (ms)':'Controls the visual cadence for Slow activity. Lower values make light-traffic flicker more frequent; higher values make it calmer.',
'Medium blink period (ms)':'Controls the visual cadence for Medium activity. Lower values make the activity flicker more frequently.',
'Fast blink period (ms)':'Controls the visual cadence for Fast activity. Lower values produce the most rapid activity flicker.',
'Activity hold (seconds)':'Controls how long the most recent detected traffic remains visually valid between telemetry samples. Higher values make activity persist longer after the last detected sample.',
'Hysteresis (%)':'Adds a buffer around the Slow/Medium/Fast traffic thresholds so small utilisation changes near a boundary do not make the LED repeatedly jump between activity bands. Higher values make band changes steadier.',
'UI density':'Changes Hub control spacing and information density. Left is more spacious; right fits more information onscreen.',
'Text size':'Sets the base text size used by this management interface.',
'Content width':'Changes how much horizontal page width the management interface uses. Left is narrower; right is wider.',
'Show UniFi integration':'Shows or hides UniFi-specific Hub controls and navigation. It does not uninstall or disable UniFi2MQTT.',
'MQTT host':'MQTT broker hostname used by Switch Vision. Leave the normal Supervisor-provided broker value unless you intentionally use a custom broker.',
'MQTT port':'TCP port used to connect to the configured MQTT broker.',
'MQTT username':'Optional MQTT username for a custom broker. Supervisor-provided MQTT credentials are handled automatically when applicable.',
'MQTT password':'Optional MQTT password. Saved values stay masked; leaving this field blank preserves the existing saved password.',
'Clear saved MQTT password':'Explicitly removes the saved MQTT password. Use this only when the broker no longer requires that credential.',
'Targets path':'Path to the SNMP2MQTT targets file used when generated-YAML mode is not supplying the active target configuration.',
'Generated YAML path':'Path where Discovery publishes the generated SNMP2MQTT configuration consumed by the Switch Vision SNMP2MQTT app.',
'Imported targets path':'Path used for imported/manual SNMP2MQTT target data when that workflow is active.',
'Use Switch Vision generated YAML':'Uses Discovery-generated SNMP2MQTT configuration as the active target source. This is the normal Switch Vision workflow.',
'Back up existing config before import':'Keeps a backup of the existing SNMP2MQTT configuration before an import replaces it.',
'MQTT Discovery enabled':'Home Assistant MQTT Discovery is required by Switch Vision so generated SNMP sensors/entities appear automatically.',
'Discovery prefix':'Home Assistant MQTT Discovery topic prefix. Switch Vision requires the standard homeassistant value.',
'Run SNMP walks':'Contacts enabled SNMP switches during Discovery to collect fresh walk evidence. Turn this off only when intentionally reprocessing saved evidence.',
'Use saved switch list':'Uses the persistent switches configured below as Discovery targets.',
'Parse all stored walks':'Processes all compatible stored walk evidence instead of only the current targeted Discovery input.',
'Generate SNMP2MQTT YAML':'Builds the SNMP2MQTT configuration from validated Discovery results.',
'Clean generated output before walk':'Removes regenerable Discovery output before collecting new walk evidence so the run starts from a clean generated state.',
'Create Support My Switch bundle after Discovery':'Creates a privacy-processed contribution archive after a successful Discovery run. Nothing is transmitted automatically.',
'Switch Name (Used internally only)':'Stable internal target ID used to link walks, generated profiles, stack mappings and reports. Keep it stable after a switch has been configured.',
'Display name':'Friendly name shown to the user for this switch or stack member.',
'Switch host':'Hostname or IP address that Discovery uses to contact this switch.',
'Sensor prefix':'Home Assistant/MQTT sensor identity prefix associated with this switch. Keep it stable to avoid creating a second set of entities.',
'SNMP community':'SNMP community used to read this switch. Saved values are masked in the Hub and are not included in non-secret backups.',
'State':'Enabled devices are actively used by Switch Vision; Disabled keeps the saved device but stops active polling/presentation where supported.',
'Walk mode':'Targeted collects the bounded Switch Vision evidence set; Full collects a complete SNMP walk for deeper hardware-support evidence.',
'Switch model':'Auto lets Discovery identify the exact model from evidence. Choose a model manually only when you intentionally need an override.',
'Card header title':'Optional explicit title for the generated switch card. Leave blank to use the normal friendly display name.',
'Switch name':'Internal switch identity that this stack-member display mapping belongs to.',
'Member number':'Physical/logical stack member number used to bind this display mapping to the correct member.',
'Input walk path':'Primary walk file path used by Discovery compatibility/import workflows.',
'SNMP walks directory':'Directory where per-switch saved SNMP walk evidence is stored.',
'Discovery report path':'Path where Discovery writes the current human-readable discovery report.',
'Targets CSV path':'Optional CSV/import fallback path for target definitions.',
'Last-run summary path':'Path where Discovery records the latest run summary.',
'Generated SNMP2MQTT path':'Output path for Discovery-generated SNMP2MQTT YAML.',
'Generated dashboard path':'Output path for the generated Switch Vision dashboard/card YAML.',
'SNMP log path':'Path where SNMP walk command output/diagnostics are written.',
'SNMP timeout':'Per-attempt SNMP response timeout in seconds. Increase only for slow or high-latency devices; larger values make failed walks take longer.',
'SNMP retries':'Number of additional SNMP attempts after a timeout/failure. More retries improve tolerance of packet loss but lengthen failed Discovery runs.',
'Minimum valid walk lines':'Minimum number of walk lines required before Discovery accepts a collected walk as usable evidence. This helps reject empty or obviously incomplete captures.',
'Automatic retention':'Automatically prunes older Discovery configuration backups after successful protected mutations.',
'Retained backups':'Maximum number of automatic Discovery configuration backups to keep when retention is enabled.',
'Mask management IPs':'Replaces management IP addresses in Support My Switch contribution output while leaving the live Switch Vision configuration unchanged.',
'Mask MAC addresses':'Replaces MAC addresses in Support My Switch contribution output while leaving live device identity unchanged.',
'Mask hostnames':'Replaces hostnames in Support My Switch contribution output while leaving the live configuration unchanged.',
'Mask VLAN names':'Replaces VLAN names in Support My Switch contribution output when those names appear in collected evidence.',
'Mask interface descriptions':'Replaces interface descriptions in Support My Switch contribution output when those descriptions appear in collected evidence.',
'Contributor recognition':'Controls whether a Support My Switch archive asks to acknowledge you anonymously, by name, GitHub identity or forum identity. Nothing is published automatically.',
'Contributor value':'Private recognition value used only when preparing contribution metadata. It is write-only in normal Hub settings and is never published automatically.'
};const OL={hub:'Hub',maintenance:'Maintenance',switch_vision_settings:'Switch Vision Settings',discovery_settings:'Discovery Settings',installer:'Installer',installer_settings:'Installer Settings',snmp2mqtt_settings:'SNMP2MQTT Settings',unifi2mqtt_settings:'UniFi2MQTT Settings'};function status(t,c=''){const n=q('hubSettingsStatus');if(n){n.className=`muted hub-settings-status ${c}`.trim();n.textContent=t}}function selectTab(which='core',focus=false){const ids=['core','discovery','snmp2mqtt'];const selected=ids.includes(which)?which:'core';state.activeTab=selected;for(const id of ids){const active=id===selected,pane=q(`hubComponent-${id}`),tab=q(`hubTab-${id}`);if(pane)pane.hidden=!active;if(tab){tab.classList.toggle('is-active',active);tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1}}if(focus)q(`hubTab-${selected}`)?.focus()}function tabKeydown(e){const ids=['core','discovery','snmp2mqtt'],current=state.activeTab,i=Math.max(0,ids.indexOf(current));let next=null;if(e.key==='ArrowRight')next=ids[(i+1)%ids.length];else if(e.key==='ArrowLeft')next=ids[(i-1+ids.length)%ids.length];else if(e.key==='Home')next=ids[0];else if(e.key==='End')next=ids[ids.length-1];if(next){e.preventDefault();selectTab(next,true)}}function syncDiscoverySurfaceButtons(){const changed=dirty.has('discovery');const d=q('devicesConfigSave'),b=q('maintenanceBackupSettingsSave');if(d)d.disabled=!changed;if(b)b.disabled=!changed}function mark(o){dirty.add(o);q('hubSettingsSave').disabled=false;syncDiscoverySurfaceButtons();status('Unsaved changes')}function clear(o){dirty.delete(o);q('hubSettingsSave').disabled=!dirty.size;syncDiscoverySurfaceButtons()}async function req(p,o={}){const r=await fetch(endpoint(p),{cache:'no-store',...o});let d={};try{d=await r.json()}catch(_e){}if(!r.ok)throw new Error(d.error||`Request failed (${r.status})`);return d}function sec(t,p=''){const x=document.createElement('section');x.className='hub-settings-section';x.innerHTML=`<h3>${t}</h3>${p?`<p class="muted">${p}</p>`:''}`;return x}function hubHelp(t){const w=document.createElement('span');w.className='hub-help';const b=document.createElement('button');b.type='button';b.className='hub-help-button';b.innerHTML='<svg class="hub-help-icon" viewBox="0 0 18 18" aria-hidden="true" focusable="false"><rect x="2.25" y="2.25" width="13.5" height="13.5" rx="2.4"></rect><circle cx="9" cy="5.45" r=".85" fill="currentColor" stroke="none"></circle><path d="M9 8v4.35"></path></svg>';b.setAttribute('aria-label','Help: '+t);b.setAttribute('aria-expanded','false');const p=document.createElement('span');p.className='hub-help-popover';p.setAttribute('role','tooltip');p.textContent=t;p.hidden=true;let pinned=false;const show=()=>{p.hidden=false;b.setAttribute('aria-expanded','true')},hide=()=>{if(!pinned){p.hidden=true;b.setAttribute('aria-expanded','false')}};b.onmouseenter=show;b.onmouseleave=hide;b.onfocus=show;b.onblur=hide;b.onclick=e=>{e.preventDefault();pinned=!pinned;pinned?show():hide()};b.onkeydown=e=>{if(e.key==='Escape'){pinned=false;p.hidden=true;b.setAttribute('aria-expanded','false')}};w.append(b,p);return w}function attachActionHelp(id,t){const e=q(id);if(e&&!e.nextElementSibling?.classList?.contains('hub-help'))e.after(hubHelp(t))}function fld(t,c,h=''){const help=h||H[t]||'';const x=document.createElement('label');x.className='field hub-setting-field';const s=document.createElement('span');s.className='hub-field-label';s.textContent=t;if(help)s.append(hubHelp(help));const target=c.matches?.('input,select,textarea')?c:c.querySelector?.('input,select,textarea');if(target){target.setAttribute('aria-label',t);if(help)target.title=help}x.append(s,c);return x}function tog(t,v,fn,dis=false,h=''){const help=h||H[t]||'';const x=document.createElement('label');x.className='option hub-setting-toggle';const i=document.createElement('input');i.type='checkbox';i.checked=!!v;i.disabled=dis;i.onchange=()=>fn(i.checked);i.setAttribute('aria-label',t);if(help)i.title=help;const s=document.createElement('span');s.className='hub-option-label hub-toggle-label';s.textContent=t;x.append(i,s);if(help)x.append(hubHelp(help));return x}function sel(v,opts,fn){const s=document.createElement('select');for(const [a,b] of opts){const o=document.createElement('option');o.value=a;o.textContent=b;o.selected=String(v)===String(a);s.append(o)}s.onchange=()=>fn(s.value);return s}function inp(v,type,fn,a={}){const i=document.createElement('input');i.type=type;i.value=v??'';for(const[k,x]of Object.entries(a))if(x!==undefined&&x!==null)i.setAttribute(k,String(x));i.oninput=()=>fn(i.value);return i}function secretInp(v,fn,refProvider,configured,a={}){const i=inp(v,'password',fn,a);return secretControl(i,refProvider,configured)}function fontChoices(){return Array.from({length:11},(_,i)=>{const px=i+10;return[String(px),`${px} px`]})}const UI_DENSITY_SCALE=[['spacious','Spacious'],['comfortable','Comfortable'],['compact','Compact'],['dense','Dense'],['ultra_dense','Ultra Dense']];const UI_WIDTH_SCALE=[['standard','Standard'],['standard_plus','Standard+'],['wide','Wide'],['wide_plus','Wide+'],['extra_wide','Extra Wide'],['extra_wide_plus','Extra Wide+'],['ultra_wide','Ultra Wide'],['ultra_wide_plus','Ultra Wide+'],['max_wide','Max Wide'],['full','Full']];function scaleIndex(value,scale){const i=scale.findIndex(([v])=>v===String(value));return i>=0?i:0}function rangeScale(value,scale,leftLabel,rightLabel,onChange){const wrap=document.createElement('div');wrap.className='hub-range-control';const ends=document.createElement('div');ends.className='hub-range-ends';const left=document.createElement('span'),right=document.createElement('span');left.textContent=leftLabel;right.textContent=rightLabel;ends.append(left,right);const input=document.createElement('input');input.type='range';input.min='1';input.max=String(scale.length);input.step='1';input.value=String(scaleIndex(value,scale)+1);const ticks=document.createElement('div');ticks.className='hub-range-ticks';scale.forEach(([,label],i)=>{const tick=document.createElement('span');tick.textContent=String(i+1);tick.title=label;ticks.append(tick)});const out=document.createElement('output');const update=emit=>{const i=Math.max(0,Math.min(scale.length-1,Number(input.value)-1));const [mapped,label]=scale[i];out.textContent=`${i+1} / ${scale.length} · ${label}`;if(emit)onChange(mapped,label,i+1)};input.addEventListener('input',()=>update(true));update(false);wrap.append(ends,input,ticks,out);return wrap}function applyDiscoveryAppearancePreview(density,width){syncDensityUi(density);syncContentWidthUi(width)}function installerAppearancePreview(){const p=document.createElement('div');p.className='installer-appearance-preview';p.innerHTML='<div class="installer-preview-frame"><div class="installer-preview-head"><span></span><span class="installer-preview-label"></span></div><div class="installer-preview-grid"><i></i><i></i><i></i></div><div class="installer-preview-card"></div></div>';return p}function applyInstallerAppearancePreview(root,density,width){if(!root)return;const di=Math.max(0,scaleIndex(density,UI_DENSITY_SCALE)),wi=Math.max(0,scaleIndex(width,UI_WIDTH_SCALE));root.style.setProperty('--preview-width',`${64+wi*4}%`);root.style.setProperty('--preview-gap',`${14-di*2}px`);root.style.setProperty('--preview-pad',`${16-di*2}px`);const label=root.querySelector('.installer-preview-label');if(label)label.textContent=`${UI_DENSITY_SCALE[di][1]} · ${UI_WIDTH_SCALE[wi][1]}`}function renderCore(){const r=q('hubCoreSettings');r.innerHTML='';if(!state.core?.settings){r.textContent='Core settings are unavailable.';return}const s=state.core.settings,side=sec('Sidebar & navigation'),sideTog=document.createElement('div');sideTog.className='hub-toggle-grid';for(const[k,v]of Object.entries(s.sidebar||{}))sideTog.append(tog(L[k]||k,v,x=>{s.sidebar[k]=x;mark('core')}));side.append(sideTog);r.append(side);const h=sec('Native dashboard header','Choose what appears in the Native Switch Vision header and how dashboard cards are presented. Shortcut order affects enabled shortcuts only.'),displayGroup=document.createElement('div'),shortcutGroup=document.createElement('div'),presentationGroup=document.createElement('div');displayGroup.className='hub-header-group';shortcutGroup.className='hub-header-group hub-header-shortcuts';presentationGroup.className='hub-header-group hub-header-presentation';displayGroup.innerHTML='<h4>Header display</h4>';shortcutGroup.innerHTML='<h4>Enabled shortcuts</h4>';presentationGroup.innerHTML='<h4>Dashboard presentation</h4>';const displayKeys=['show_dashboard_header','native_header_show_refresh','native_header_show_summary','native_header_show_version'];for(const k of displayKeys){if(Object.prototype.hasOwnProperty.call(s.native_header||{},k))displayGroup.append(tog(L[k]||k,s.native_header[k],x=>{s.native_header[k]=x;mark('core')}))}for(const[k,v]of Object.entries(s.native_header||{})){if(k.startsWith('native_header_shortcut_')&&k!=='native_header_shortcut_order')shortcutGroup.append(tog(L[k]||k,v,x=>{s.native_header[k]=x;mark('core');renderCore()}))}const presentationTog=document.createElement('div');presentationTog.className='hub-toggle-grid';for(const[k,v]of Object.entries(s.dashboard||{})){if(k==='faceplate_width_mode'||k==='faceplate_custom_width')continue;presentationTog.append(tog(L[k]||k,v,x=>{s.dashboard[k]=x;mark('core')}))}if(s.discovery&&Object.prototype.hasOwnProperty.call(s.discovery,'show_unifi_integration'))presentationTog.append(tog('Show UniFi integration',s.discovery.show_unifi_integration,x=>{s.discovery.show_unifi_integration=x;mark('core')}));presentationGroup.append(presentationTog);const widthGrid=document.createElement('div');widthGrid.className='grid hub-header-presentation-width';const widthMode=sel(s.dashboard.faceplate_width_mode||'auto',[['auto','Auto'],['800','800 px'],['1024','1024 px'],['custom','Custom']],x=>{s.dashboard.faceplate_width_mode=x;mark('core');renderCore()});widthGrid.append(fld('Faceplate width',widthMode,'Sets the maximum rendered faceplate/card width. Height and calibrated geometry scale proportionally.'));if((s.dashboard.faceplate_width_mode||'auto')==='custom')widthGrid.append(fld('Custom faceplate width (px)',inp(s.dashboard.faceplate_custom_width||800,'number',x=>{s.dashboard.faceplate_custom_width=Number(x);mark('core')},{min:320,max:4096,step:1}),'Custom width is remembered when you switch back to a preset.'));presentationGroup.append(widthGrid);const box=document.createElement('div');box.className='hub-order-list hub-header-group';box.innerHTML='<h4>Shortcut order</h4><p class="muted hub-order-help">Only enabled shortcuts are shown in the Native dashboard header.</p>';state.order=[...(s.native_header.native_header_shortcut_order||[])];const draw=()=>{box.querySelectorAll('.hub-order-row').forEach(n=>n.remove());state.order.forEach((id,n)=>{const row=document.createElement('div');row.className='hub-order-row';const enabledKey=`native_header_shortcut_${id}`,enabled=s.native_header?.[enabledKey]!==false;row.classList.toggle('is-disabled',!enabled);const nm=document.createElement('span');nm.textContent=OL[id]||id;nm.title=enabled?'Enabled shortcut':'Shortcut is disabled';const u=document.createElement('button'),d=document.createElement('button');u.type=d.type='button';u.textContent='↑';d.textContent='↓';u.disabled=n===0;d.disabled=n===state.order.length-1;u.setAttribute('aria-label',`Move ${OL[id]||id} up`);d.setAttribute('aria-label',`Move ${OL[id]||id} down`);u.onclick=()=>{[state.order[n-1],state.order[n]]=[state.order[n],state.order[n-1]];s.native_header.native_header_shortcut_order=[...state.order];mark('core');draw()};d.onclick=()=>{[state.order[n+1],state.order[n]]=[state.order[n],state.order[n+1]];s.native_header.native_header_shortcut_order=[...state.order];mark('core');draw()};row.append(nm,u,d);box.append(row)})};draw();const headerLayout=document.createElement('div');headerLayout.className='hub-header-layout';headerLayout.append(displayGroup,shortcutGroup,presentationGroup,box);h.append(headerLayout);r.append(h);const a=sec('Activity LEDs'),g=document.createElement('div');g.className='grid hub-grid-dense';g.append(fld('Sensitivity preset',sel(s.activity_leds.activity_led_sensitivity_preset,[['low','Low'],['normal','Normal'],['high','High'],['custom','Custom']],x=>{s.activity_leds.activity_led_sensitivity_preset=x;mark('core')})));for(const[k,t,min,max,step]of [['activity_slow_max_utilization_pct','Slow activity maximum (%)',.001,100,.001],['activity_medium_max_utilization_pct','Medium activity maximum (%)',.001,100,.001],['activity_slow_period_ms','Slow blink period (ms)',120,2000,1],['activity_medium_period_ms','Medium blink period (ms)',120,2000,1],['activity_fast_period_ms','Fast blink period (ms)',120,2000,1],['activity_hold_seconds','Activity hold (seconds)',1,120,.1],['activity_hysteresis_pct','Hysteresis (%)',0,50,.1]])g.append(fld(t,inp(s.activity_leds[k],'number',x=>{s.activity_leds[k]=Number(x);mark('core')},{min,max,step})));a.append(g);r.append(a);const ap=document.createElement('div');ap.className='hub-settings-columns';for(const[grp,title]of[['discovery','Discovery appearance'],['installer','Installer appearance']]){const b=sec(title),v=s[grp],densityKey=`${grp}_ui_density`,widthKey=`${grp}_content_width`;let preview=null;const live=()=>{if(grp==='discovery')applyDiscoveryAppearancePreview(v[densityKey],v[widthKey]);else applyInstallerAppearancePreview(preview,v[densityKey],v[widthKey])};b.append(fld('UI density',rangeScale(v[densityKey],UI_DENSITY_SCALE,'Spacious','Ultra Dense',x=>{v[densityKey]=x;mark('core');live()}),'Live preview. Left is more spacious; right fits more information onscreen.'),fld('Text size',sel(v[`${grp}_text_size`],fontChoices(),x=>{v[`${grp}_text_size`]=Number(x);mark('core')})),fld('Content width',rangeScale(v[widthKey],UI_WIDTH_SCALE,'Narrower','Wider',x=>{v[widthKey]=x;mark('core');live()}),'Live preview. Left is narrower; right is wider.'));if(grp==='installer'){preview=installerAppearancePreview();b.append(preview);applyInstallerAppearancePreview(preview,v[densityKey],v[widthKey])}ap.append(b)}r.append(ap)}function renderSnmp(){const r=q('hubSnmpSettings');r.innerHTML='';const d=state.snmp2mqtt;if(!d?.installed){r.innerHTML='<div class="warning">Switch Vision SNMP2MQTT is not installed.</div>';return}const s=d.settings,m=sec('MQTT connection'),g=document.createElement('div');g.className='grid';g.append(fld('MQTT host',inp(s.mqtt.host,'text',x=>{s.mqtt.host=x;mark('snmp2mqtt')})),fld('MQTT port',inp(s.mqtt.port,'number',x=>{s.mqtt.port=Number(x);mark('snmp2mqtt')},{min:1,max:65535,step:1})),fld('MQTT username',inp(s.mqtt.username,'text',x=>{s.mqtt.username=x;mark('snmp2mqtt')})),fld('MQTT password',secretInp('',x=>{s.mqtt.password=x;mark('snmp2mqtt')},()=>({scope:'snmp2mqtt',kind:'mqtt_password'}),!!d.password_configured,{autocomplete:'new-password',placeholder:d.password_configured?'Saved — use eye to reveal':'Not configured'}),'Saved passwords stay redacted in normal settings responses. Use the eye to reveal this one on demand; blank preserves it.'));m.append(g,tog('Clear saved MQTT password',false,x=>{s.clear_password=x;mark('snmp2mqtt')},false,'Only enable this if the broker no longer requires the saved password.'));r.append(m);const p=sec('Target configuration'),pg=document.createElement('div');pg.className='grid';for(const[k,t]of[['targets_path','Targets path'],['switch_vision_generated_yaml_path','Generated YAML path'],['imported_targets_path','Imported targets path']])pg.append(fld(t,inp(s[k],'text',x=>{s[k]=x;mark('snmp2mqtt')})));p.append(pg,tog('Use Switch Vision generated YAML',s.use_switch_vision_generated_yaml,x=>{s.use_switch_vision_generated_yaml=x;mark('snmp2mqtt')}),tog('Back up existing config before import',s.backup_existing_config,x=>{s.backup_existing_config=x;mark('snmp2mqtt')}));r.append(p);const ha=sec('Home Assistant discovery');ha.append(tog('MQTT Discovery enabled',true,()=>{},true,'Required by Switch Vision and enforced by SNMP2MQTT.'),fld('Discovery prefix',inp('homeassistant','text',()=>{},{readonly:'readonly'}),'Required value: homeassistant.'));r.append(ha)}function bsel(v,fn){return sel(v===true||String(v).toLowerCase()==='true'?'true':'false',[['true','Enabled'],['false','Disabled']],fn)}function renderDiscovery(){
const r=q('hubDiscoverySettings');r.innerHTML='';if(!state.discovery?.settings){r.textContent='Discovery settings are unavailable.';return}
const s=state.discovery.settings,w=sec('Discovery workflow'),wg=document.createElement('div');wg.className='grid hub-discovery-workflow-grid';
for(const[k,t]of[['run_snmp_walks','Run SNMP walks'],['enable_switch_list','Use saved switch list'],['parse_all_walks','Parse all stored walks'],['generate_snmp2mqtt','Generate SNMP2MQTT YAML'],['clean_output_before_walk','Clean generated output before walk'],['generate_support_my_switch_bundle','Create Support My Switch bundle after Discovery']])wg.append(fld(t,bsel(s[k],x=>{s[k]=x;mark('discovery')})));
w.append(wg);r.append(w);
const p=sec('Paths & SNMP timing'),pg=document.createElement('div');pg.className='grid';
for(const[k,t]of[['input_path','Input walk path'],['snmpwalks_dir','SNMP walks directory'],['report_path','Discovery report path'],['targets_csv','Targets CSV path'],['last_run_summary_path','Last-run summary path'],['generated_yaml_path','Generated SNMP2MQTT path'],['generated_card_path','Generated dashboard path'],['snmp_log_path','SNMP log path']])pg.append(fld(t,inp(s[k]??'','text',x=>{s[k]=x;mark('discovery')})));
for(const[k,t,min,max]of[['snmp_timeout','SNMP timeout',1,30],['snmp_retries','SNMP retries',0,10],['minimum_valid_walk_lines','Minimum valid walk lines',1,1000000]])pg.append(fld(t,inp(s[k]??'','number',x=>{s[k]=String(x);mark('discovery')},{min,max,step:1})));
p.append(pg);r.append(p);
const sp=sec('Support My Switch privacy & recognition'),sg=document.createElement('div');sg.className='grid';
for(const[k,t]of[['support_mask_management_ips','Mask management IPs'],['support_mask_mac_addresses','Mask MAC addresses'],['support_mask_hostnames','Mask hostnames'],['support_mask_vlan_names','Mask VLAN names'],['support_mask_interface_descriptions','Mask interface descriptions']])sg.append(fld(t,bsel(s[k],x=>{s[k]=x;mark('discovery')})));
sg.append(fld('Contributor recognition',sel(s.support_contributor_type||'anonymous',[['anonymous','Anonymous'],['first_name','First name'],['full_name','Full name'],['github','GitHub'],['forum','Forum']],x=>{s.support_contributor_type=x;mark('discovery')})),fld('Contributor value',inp('','text',x=>{s.support_contributor_value=x;mark('discovery')},{maxlength:120,placeholder:s.support_contributor_value_configured?'Saved — leave blank to keep':'Optional recognition'}),'Private and write-only in the Hub; nothing is published automatically.'));
sp.append(sg);r.append(sp)
}
function renderDeviceConfiguration(){
const r=q('hubDeviceConfiguration');if(!r)return;r.innerHTML='';if(!state.discovery?.settings){r.textContent='Device configuration is unavailable.';return}
const s=state.discovery.settings,sw=sec('Switches','SNMP communities are masked by default. Use the eye to reveal a saved community; blank preserves it. Device ordering remains managed from Device Overview.'),switches=s.switches||[];
switches.forEach((row,n)=>{const key=String(row.original_switch_name||row.switch_name||`index:${n}`);const c=document.createElement('div');c.className='device-card hub-setting-row hub-switch-setting-row';const hd=document.createElement('div');hd.className='hub-switch-setting-summary';const toggle=document.createElement('button');toggle.type='button';toggle.className='hub-switch-setting-toggle';toggle.setAttribute('aria-expanded',String(expandedDiscoverySwitches.has(key)));const label=document.createElement('span');label.className='hub-switch-setting-label';const name=document.createElement('strong');name.textContent=`Switch ${n+1}`;const meta=document.createElement('span');meta.className='muted hub-switch-setting-meta';meta.textContent=[row.display_name||row.switch_name||'Unnamed switch',row.switch_model&&row.switch_model!=='auto'?row.switch_model:'Auto-detect',row.switch_host||'No host',row.restore_pending?'Credential required':''].filter(Boolean).join(' · ');label.append(name,meta);const chevron=document.createElement('span');chevron.className='hub-switch-setting-chevron';chevron.textContent='▸';chevron.setAttribute('aria-hidden','true');toggle.append(label,chevron);const rm=document.createElement('button');rm.type='button';rm.className='danger';rm.textContent='Remove';rm.onclick=()=>{expandedDiscoverySwitches.delete(key);switches.splice(n,1);mark('discovery');renderDeviceConfiguration()};hd.append(toggle,rm);c.append(hd);const g=document.createElement('div');g.className='grid hub-switch-setting-body';g.hidden=!expandedDiscoverySwitches.has(key);toggle.addEventListener('click',()=>{const open=g.hidden;if(open)expandedDiscoverySwitches.add(key);else expandedDiscoverySwitches.delete(key);g.hidden=!open;toggle.setAttribute('aria-expanded',String(open));c.classList.toggle('is-open',open)});c.classList.toggle('is-open',!g.hidden);const f=(t,k,type='text',hint='')=>{if(type==='password')return fld(t,secretInp(row[k]??'',x=>{row[k]=x;mark('discovery')},()=>({scope:'discovery',kind:'snmp_community',identifier:row.original_switch_name||row.switch_name}),!!row.snmp_community_configured,{autocomplete:'new-password',placeholder:row.snmp_community_configured?'Saved — use eye to reveal':(row.restore_pending?'Credential required after restore':'Required for new switch')}),hint);return fld(t,inp(row[k]??'',type,x=>{row[k]=x;mark('discovery')}),hint)};
g.append(f('Switch Name (Used internally only)','switch_name'),f('Display name','display_name'),f('Switch host','switch_host'),f('Sensor prefix','sensor_prefix'),f('SNMP community','snmp_community','password','Saved communities stay redacted in normal settings responses; use the eye to reveal this one on demand.'),fld('State',sel(row.enabled||'enabled',[['enabled','Enabled'],['disabled','Disabled']],x=>{row.enabled=x;mark('discovery')})),fld('Walk mode',sel(row.walk_mode||'targeted',[['targeted','Targeted'],['full','Full']],x=>{row.walk_mode=x;mark('discovery')})),fld('Switch model',sel(row.switch_model||'auto',[['auto','Auto'],...state.models.filter(m=>m!=='auto').map(m=>[m,m])],x=>{row.switch_model=x;mark('discovery')})),f('Card header title','card_header_title'));c.append(g);sw.append(c)});
const add=document.createElement('button');add.type='button';add.textContent='Add switch';add.onclick=()=>{const row={switch_name:'',display_name:'',switch_host:'',sensor_prefix:'',snmp_community:'',snmp_community_configured:false,original_switch_name:'',enabled:'enabled',walk_mode:'targeted',switch_model:'auto',card_header_title:''};s.switches.push(row);expandedDiscoverySwitches.add(`index:${s.switches.length-1}`);mark('discovery');renderDeviceConfiguration()};sw.append(add);r.append(sw);
const st=sec('Stack member display mapping');(s.stack_member_prefixes||[]).forEach((row,n)=>{const c=document.createElement('div');c.className='device-card hub-setting-row';const hd=document.createElement('div');hd.className='device-head';hd.innerHTML=`<strong>Stack member ${n+1}</strong>`;const rm=document.createElement('button');rm.type='button';rm.className='danger';rm.textContent='Remove';rm.onclick=()=>{s.stack_member_prefixes.splice(n,1);mark('discovery');renderDeviceConfiguration()};hd.append(rm);c.append(hd);const g=document.createElement('div');g.className='grid';for(const[k,t]of[['switch_name','Switch name'],['member','Member number'],['display_name','Display name'],['sensor_prefix','Sensor prefix'],['card_header_title','Card header title']])g.append(fld(t,inp(row[k]??'','text',x=>{row[k]=x;mark('discovery')})));c.append(g);st.append(c)});
const as=document.createElement('button');as.type='button';as.textContent='Add stack member';as.onclick=()=>{s.stack_member_prefixes.push({switch_name:'',member:'1',display_name:'',sensor_prefix:'',card_header_title:''});mark('discovery');renderDeviceConfiguration()};st.append(as);r.append(st)
}
function renderDiscoveryBackupSettings(){
const r=q('maintenanceDiscoveryBackupSettings');if(!r)return;r.innerHTML='';if(!state.discovery?.settings){r.textContent='Discovery backup settings are unavailable.';return}
const s=state.discovery.settings,g=document.createElement('div');g.className='grid';
g.append(fld('Automatic retention',bsel(s.backup_retention_enabled,x=>{s.backup_retention_enabled=x;mark('discovery');const st=q('maintenanceBackupSettingsStatus');if(st)st.textContent='Unsaved backup settings.'})),fld('Retained backups',inp(s.backup_retention_count,'number',x=>{s.backup_retention_count=Number(x);mark('discovery');const st=q('maintenanceBackupSettingsStatus');if(st)st.textContent='Unsaved backup settings.'},{min:1,max:10,step:1})));
r.append(g)
}
async function loadDiscoverySurface(kind='devices'){
const statusNode=q(kind==='backups'?'maintenanceBackupSettingsStatus':'devicesConfigStatus');if(statusNode)statusNode.textContent='Loading Discovery settings…';
try{const d=await req('api/settings/discovery');state.discovery=clone(d);state.models=[...(d.models||[])];clear('discovery');renderDiscovery();renderDeviceConfiguration();renderDiscoveryBackupSettings();if(statusNode)statusNode.textContent=kind==='backups'?'Backup settings loaded.':'Device configuration loaded.'}catch(e){if(statusNode)statusNode.textContent=`Could not load Discovery settings: ${e.message||e}`}
}
async function saveDiscoverySurface(kind='devices'){
const statusNode=q(kind==='backups'?'maintenanceBackupSettingsStatus':'devicesConfigStatus');if(!state.discovery?.settings){if(statusNode)statusNode.textContent='Discovery settings are unavailable.';return}
const button=q(kind==='backups'?'maintenanceBackupSettingsSave':'devicesConfigSave');if(button)button.disabled=true;if(statusNode)statusNode.textContent='Saving Discovery settings…';
try{const d=await req('api/settings/discovery',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:cleanDiscovery()})});state.discovery=clone(d);state.models=[...(d.models||state.models)];clear('discovery');renderDiscovery();renderDeviceConfiguration();renderDiscoveryBackupSettings();if(statusNode)statusNode.textContent=kind==='backups'?'Backup settings saved.':'Device configuration saved.'}catch(e){if(statusNode)statusNode.textContent=`Save failed: ${e.message||e}`;syncDiscoverySurfaceButtons()}
}
async function loadDeviceConfiguration(){if(!state.discovery?.settings)return loadDiscoverySurface('devices');renderDeviceConfiguration();const st=q('devicesConfigStatus');if(st&&!dirty.has('discovery'))st.textContent='Device configuration loaded.'}
async function loadMaintenanceBackupSettings(){if(!state.discovery?.settings)return loadDiscoverySurface('backups');renderDiscoveryBackupSettings();const st=q('maintenanceBackupSettingsStatus');if(st&&!dirty.has('discovery'))st.textContent='Backup settings loaded.'}
function selectDevicesTab(which='configure',focus=false){const ids=['configure','overview'],selected=ids.includes(which)?which:'configure';for(const id of ids){const active=id===selected,pane=q(`devicesPanel-${id}`),tab=q(`devicesTab-${id}`);if(pane)pane.hidden=!active;if(tab){tab.classList.toggle('is-active',active);tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1}}if(focus)q(`devicesTab-${selected}`)?.focus();if(selected==='configure')loadDeviceConfiguration()}
function devicesTabKeydown(e){const ids=['configure','overview'],current=q('devicesTab-configure')?.classList.contains('is-active')?'configure':'overview',i=ids.indexOf(current);let next=null;if(e.key==='ArrowRight')next=ids[(i+1)%ids.length];else if(e.key==='ArrowLeft')next=ids[(i-1+ids.length)%ids.length];else if(e.key==='Home')next=ids[0];else if(e.key==='End')next=ids[ids.length-1];if(next){e.preventDefault();selectDevicesTab(next,true)}}
function cleanDiscovery(){const s=clone(state.discovery.settings);delete s.support_contributor_value_configured;s.switches=(s.switches||[]).map(row=>{const x={...row};delete x.snmp_community_configured;delete x.restore_pending;return x});return s}async function load(){status('Loading settings…');const a=await Promise.allSettled([req('api/settings/core'),req('api/settings/snmp2mqtt'),req('api/settings/discovery')]);state.core=a[0].status==='fulfilled'?clone(a[0].value):null;state.snmp2mqtt=a[1].status==='fulfilled'?clone(a[1].value):{installed:false};if(a[2].status==='fulfilled'){state.discovery=clone(a[2].value);state.models=[...(a[2].value.models||[])]}else state.discovery=null;renderCore();renderSnmp();renderDiscovery();renderDeviceConfiguration();renderDiscoveryBackupSettings();if(state.core?.settings?.discovery)applyDiscoveryAppearancePreview(state.core.settings.discovery.discovery_ui_density,state.core.settings.discovery.discovery_content_width);dirty.clear();q('hubSettingsSave').disabled=true;syncDiscoverySurfaceButtons();const e=a.filter(x=>x.status==='rejected').map(x=>x.reason?.message||String(x.reason));status(e.length?`Loaded with ${e.length} unavailable section(s): ${e.join(' · ')}`:'All settings loaded from their authoritative components.',e.length?'failure':'success')}async function save(){if(!dirty.size)return;const b=q('hubSettingsSave'),done=[];b.disabled=true;try{for(const o of ['core','snmp2mqtt','discovery']){if(!dirty.has(o))continue;status(`Saving ${o==='core'?'Core':o==='snmp2mqtt'?'SNMP2MQTT':'Discovery'}…`);const body=o==='core'?{settings:state.core.settings}:o==='snmp2mqtt'?{settings:state.snmp2mqtt.settings}:{settings:cleanDiscovery()};const d=await req(`api/settings/${o}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(o==='core')state.core=clone(d);else if(o==='snmp2mqtt')state.snmp2mqtt=clone(d);else{state.discovery=clone(d);state.models=[...(d.models||state.models)]}done.push(o);clear(o)}renderCore();renderSnmp();renderDiscovery();renderDeviceConfiguration();renderDiscoveryBackupSettings();status('Saved successfully.','success')}catch(e){status(`${done.length?`Saved ${done.join(', ')}. `:''}Save stopped: ${e.message||e}`,'failure');b.disabled=!dirty.size}}async function resetCore(){if(!confirm('Reset all Switch Vision Core settings to their factory defaults? SNMP2MQTT and Discovery settings are not changed.'))return;try{status('Resetting Core settings…');state.core=clone(await req('api/settings/core',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reset_to_defaults:true})}));clear('core');renderCore();status('Core settings reset to defaults.','success')}catch(e){status(`Core reset failed: ${e.message||e}`,'failure')}}function styles(){if(q('hubSettingsStyles'))return;const s=document.createElement('style');s.id='hubSettingsStyles';s.textContent='.hub-settings-page,.hub-profiles-page{margin:0;padding:0}.hub-settings-section{border:1px solid var(--line-soft);border-radius:10px;padding:12px;margin:10px 0;background:var(--surface-inset);box-shadow:inset 0 1px 0 var(--heading-soft)}.hub-settings-section:first-child{margin-top:0}.hub-settings-section h3{margin:.1rem 0 .3rem;padding-left:11px;position:relative;color:var(--heading)}.hub-settings-section h3::before{content:"";position:absolute;left:0;top:.12em;width:3px;height:1.05em;border-radius:999px;background:var(--heading-line);box-shadow:0 0 12px var(--heading-glow)}.hub-settings-columns{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}.hub-range-control{display:grid;gap:4px;width:100%}.hub-range-control input[type=range]{width:100%;margin:0;accent-color:var(--accent)}.hub-range-ends,.hub-range-ticks{display:flex;justify-content:space-between;gap:4px;color:var(--muted);font-size:var(--sv-font-small)}.hub-range-ticks span{min-width:1.2em;text-align:center}.hub-range-control output{font-weight:700;color:var(--heading);font-size:var(--sv-font-small)}.installer-appearance-preview{border:1px solid var(--line-soft);border-radius:9px;padding:10px;margin-top:8px;background:var(--surface-inset);overflow:hidden}.installer-preview-frame{width:var(--preview-width,70%);max-width:100%;margin:auto;border:1px solid var(--line);border-radius:8px;padding:var(--preview-pad,12px);display:grid;gap:var(--preview-gap,8px);background:var(--surface)}.installer-preview-head{display:flex;justify-content:space-between;gap:8px}.installer-preview-head>span:first-child{width:38%;height:8px;border-radius:99px;background:var(--accent-soft)}.installer-preview-label{font-size:var(--sv-font-small);color:var(--muted)}.installer-preview-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--preview-gap,8px)}.installer-preview-grid i,.installer-preview-card{display:block;height:26px;border:1px solid var(--line-soft);border-radius:6px;background:var(--surface-button)}.installer-preview-card{height:42px}.hub-setting-field{margin:6px 0;gap:4px;align-self:start;align-content:start}.hub-setting-field>span{font-weight:600;line-height:1.2}.hub-setting-field>input,.hub-setting-field>select{width:100%;height:38px;min-height:38px;padding:6px 10px}.hub-setting-field>small{line-height:1.25;margin-top:1px}.hub-settings-section .grid{align-items:start;gap:8px 14px}.hub-discovery-workflow-grid .hub-field-label{min-height:2.4em;align-items:flex-start}.hub-discovery-workflow-grid .hub-setting-field>select{align-self:start}.hub-order-list{border:1px solid var(--line-soft);border-radius:9px;padding:10px;margin-top:12px}.hub-order-row{display:grid;grid-template-columns:1fr auto auto;gap:7px;align-items:center;padding:5px 0}.hub-order-row button{padding:5px 9px}.hub-settings-actions{position:sticky;bottom:6px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:var(--surface-inset);border:1px solid var(--line-soft);padding:8px 10px;margin:10px 0 0;z-index:3;box-shadow:0 8px 22px -18px var(--heading-glow);border-radius:10px}.hub-settings-status{margin:0 0 0 auto;line-height:1.2}.hub-settings-status.success{color:var(--ok)}.hub-settings-status.failure{color:var(--bad)}.hub-settings-tabs{display:flex;gap:8px;align-items:center;overflow-x:auto;padding:2px 2px 8px;margin:0 0 10px;border-bottom:1px solid var(--line-soft)}.hub-settings-tab{flex:0 0 auto;font-weight:750;color:var(--muted);background:var(--surface-button)!important;border-color:var(--line-soft)!important}.hub-settings-tab.is-active{color:var(--heading-strong)!important;border-color:var(--accent-strong)!important;background:var(--accent-soft)!important;box-shadow:inset 0 -2px 0 var(--accent)}.hub-settings-tab:focus-visible{outline:none;box-shadow:0 0 0 3px var(--accent-soft),inset 0 -2px 0 var(--accent)}.hub-component{border:1px solid var(--line-soft);border-radius:12px;padding:10px;margin:10px 0;background:linear-gradient(180deg,var(--heading-soft),var(--surface-inset) 64px);box-shadow:inset 0 1px 0 var(--heading-soft)}.hub-settings-pane[hidden]{display:none!important}.hub-switch-setting-body[hidden]{display:none!important}.hub-setting-row{margin:12px 0}.hub-field-label,.hub-toggle-label{display:inline-flex;align-items:center;gap:6px}.hub-help{position:relative;display:inline-flex;align-items:center}.hub-help-button{width:20px!important;height:20px!important;min-height:20px!important;padding:1px!important;border:0!important;border-radius:5px!important;background:transparent!important;color:var(--muted)!important;box-shadow:none!important;display:inline-grid!important;place-items:center!important;line-height:1!important}.hub-help-button:hover,.hub-help-button:focus-visible{color:var(--accent)!important;background:var(--heading-soft)!important;box-shadow:0 0 0 2px var(--accent-soft)!important;outline:none!important}.hub-help-icon{width:16px;height:16px;display:block;overflow:visible}.hub-help-icon rect,.hub-help-icon path{fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}.hub-help-popover{position:absolute;z-index:20;left:24px;top:50%;transform:translateY(-50%);width:max-content;max-width:min(320px,72vw);padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:var(--card-strong);color:var(--text);box-shadow:0 8px 24px var(--shadow);white-space:normal}.hub-help-popover[hidden]{display:none}@media(max-width:700px){.hub-settings-status{width:100%;margin:0}.hub-settings-actions{padding-bottom:4px}}#settingsCard{--hub-control-height:var(--control-height);--hub-control-radius:var(--control-radius);--hub-field-gap:4px;--hub-grid-row-gap:6px;--hub-grid-column-gap:12px;--hub-toggle-min-height:24px;--hub-sub-radius:10px}#settingsCard .grid,.hub-control-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:var(--hub-grid-row-gap) var(--hub-grid-column-gap);align-items:start}.hub-toggle-grid{display:grid;grid-template-columns:repeat(2,minmax(240px,300px));column-gap:10px;justify-content:start;align-items:start}.hub-setting-toggle{min-height:var(--hub-toggle-min-height);padding:2px 0;display:grid;grid-template-columns:18px minmax(0,auto) 20px;column-gap:7px;align-items:center;justify-content:start;font-weight:400;line-height:1.2}.hub-setting-toggle input{margin:0;width:16px;height:16px;align-self:center;justify-self:start}.hub-setting-toggle .hub-option-label{font-weight:400;display:block;min-width:0;line-height:1.2}.hub-setting-toggle>.hub-help{align-self:center;justify-self:start}.hub-setting-field{display:grid;margin:4px 0;gap:var(--hub-field-gap);align-self:start;align-content:start}.hub-setting-field>span{font-weight:600;line-height:1.2}.hub-setting-field>input,.hub-setting-field>select{width:100%;height:var(--hub-control-height);min-height:var(--hub-control-height);padding:var(--control-pad-y) var(--control-pad-x);border-radius:var(--hub-control-radius)}.hub-setting-field>small{line-height:1.25;margin-top:1px}.hub-header-layout{display:grid;grid-template-columns:minmax(260px,.8fr) minmax(420px,1.2fr);gap:12px;align-items:start}.hub-header-group{border:1px solid var(--line-soft);border-radius:9px;padding:9px 10px;background:var(--surface);min-width:0}.hub-header-group h4{margin:0 0 7px;color:var(--heading);font-size:var(--sv-font-body)}.hub-header-shortcuts{display:grid;grid-template-columns:repeat(2,minmax(180px,1fr));column-gap:10px;align-content:start}.hub-header-shortcuts h4{grid-column:1/-1}.hub-header-presentation .hub-toggle-grid{grid-template-columns:1fr}.hub-header-presentation-width{grid-template-columns:1fr!important;margin-top:6px}.hub-order-list{width:100%;max-width:none;align-self:start;margin-top:0;padding:9px 10px}.hub-order-help{margin:0 0 5px;line-height:1.25}.hub-order-row{min-height:30px;padding:1px 0;gap:5px}.hub-order-row.is-disabled>span{opacity:.55}.hub-order-row button{width:32px;height:30px;min-height:30px;padding:0;border-radius:7px}.hub-grid-dense{grid-template-columns:repeat(4,minmax(0,1fr))!important}.hub-setting-row{border-radius:var(--hub-sub-radius);padding:12px;margin:10px 0}.hub-setting-row .grid{margin-top:8px}.hub-switch-setting-row{padding:0;overflow:hidden}.hub-switch-setting-summary{display:flex;align-items:center;gap:10px;padding:10px 12px}.hub-switch-setting-toggle{display:flex!important;align-items:center!important;gap:10px!important;min-width:0!important;flex:1!important;justify-content:space-between!important;text-align:left!important;background:transparent!important;border:0!important;box-shadow:none!important;padding:2px 4px!important}.hub-switch-setting-toggle:hover{background:var(--heading-soft)!important}.hub-switch-setting-label{display:flex;flex-direction:column;gap:2px;min-width:0;flex:1}.hub-switch-setting-chevron{flex:0 0 auto;color:var(--muted);transition:transform .12s ease}.hub-switch-setting-row.is-open .hub-switch-setting-chevron{transform:rotate(90deg)}.hub-switch-setting-label>strong{color:var(--accent-strong);text-shadow:0 0 10px var(--heading-glow);letter-spacing:.01em}.hub-switch-setting-meta{font-size:var(--sv-font-small)}.hub-switch-setting-body{padding:10px 12px 12px;border-top:1px solid var(--line-soft);margin-top:0!important}#settingsCard button{min-height:var(--hub-control-height);border-radius:var(--hub-control-radius);padding:6px 11px}#settingsCard .hub-order-row button{min-height:30px;padding:0}.hub-component .actions{gap:6px;margin-top:7px}@media(max-width:1150px){.hub-header-layout{grid-template-columns:1fr}.hub-header-shortcuts{grid-template-columns:repeat(2,minmax(180px,1fr))}.hub-order-list{grid-column:auto}.hub-grid-dense{grid-template-columns:repeat(2,minmax(0,1fr))!important}}@media(max-width:800px){#settingsCard .grid,.hub-control-grid,.hub-toggle-grid,.hub-grid-dense{grid-template-columns:1fr!important}.hub-header-layout{grid-template-columns:1fr}.hub-header-shortcuts{grid-template-columns:1fr}.hub-order-list{grid-column:auto}}body.density-spacious #settingsCard{--hub-control-height:42px;--hub-grid-row-gap:12px}body.density-spacious .hub-settings-section{padding:16px}body.density-spacious .hub-component{padding:14px}body.density-spacious .hub-switch-setting-summary{gap:12px;padding:14px 16px}body.density-spacious .hub-switch-setting-body{padding:14px 16px 16px}body.density-spacious .hub-setting-row{margin:12px 0}body.density-comfortable #settingsCard{--hub-control-height:38px;--hub-grid-row-gap:10px}body.density-comfortable .hub-settings-section{padding:12px}body.density-comfortable .hub-component{padding:10px}body.density-comfortable .hub-switch-setting-summary{gap:10px;padding:10px 12px}body.density-comfortable .hub-switch-setting-body{padding:10px 12px 12px}body.density-comfortable .hub-setting-row{margin:10px 0}body.density-compact #settingsCard{--hub-control-height:36px;--hub-grid-row-gap:8px}body.density-compact .hub-settings-section{padding:10px}body.density-compact .hub-component{padding:8px}body.density-compact .hub-switch-setting-summary{gap:8px;padding:8px 10px}body.density-compact .hub-switch-setting-body{padding:8px 10px 10px}body.density-compact .hub-setting-row{margin:8px 0}body.density-dense #settingsCard{--hub-control-height:34px;--hub-grid-row-gap:7px}body.density-dense .hub-settings-section{padding:8px}body.density-dense .hub-component{padding:7px}body.density-dense .hub-switch-setting-summary{gap:7px;padding:6px 8px}body.density-dense .hub-switch-setting-body{padding:6px 8px 8px}body.density-dense .hub-setting-row{margin:6px 0}body.density-ultra_dense #settingsCard{--hub-control-height:32px;--hub-grid-row-gap:5px}body.density-ultra_dense .hub-settings-section{padding:6px}body.density-ultra_dense .hub-component{padding:6px}body.density-ultra_dense .hub-switch-setting-summary{gap:5px;padding:4px 6px}body.density-ultra_dense .hub-switch-setting-body{padding:4px 6px 6px}body.density-ultra_dense .hub-setting-row{margin:4px 0}';document.head.append(s)}async function open(which='core'){styles();setView('settings');await load();selectTab(which)}function init(){styles();document.querySelectorAll('[data-hub-settings-tab]').forEach(tab=>{tab.addEventListener('click',()=>selectTab(tab.dataset.hubSettingsTab));tab.addEventListener('keydown',tabKeydown)});document.querySelectorAll('[data-devices-tab]').forEach(tab=>{tab.addEventListener('click',()=>selectDevicesTab(tab.dataset.devicesTab));tab.addEventListener('keydown',devicesTabKeydown)});selectTab(state.activeTab);selectDevicesTab('configure');attachActionHelp('hubSettingsSave','Save all changed Switch Vision Hub settings to their authoritative components.');attachActionHelp('hubSettingsReload','Reload authoritative component settings and discard unsaved Hub values.');attachActionHelp('hubCoreReset','Reset Switch Vision Core settings to factory defaults.');attachActionHelp('hubCoreFallback','Open native Home Assistant Switch Vision integration settings.');attachActionHelp('hubSnmpFallback','Open native SNMP2MQTT app configuration.');attachActionHelp('hubDiscoveryFallback','Open native Discovery app configuration.');q('hubSettingsSave')?.addEventListener('click',save);q('hubSettingsReload')?.addEventListener('click',load);q('hubSettingsBack')?.addEventListener('click',goBack);q('hubCoreReset')?.addEventListener('click',resetCore);q('hubCoreFallback')?.addEventListener('click',()=>openHomeAssistantPath('/config/integrations/integration/switch_vision'));q('hubSnmpFallback')?.addEventListener('click',()=>openResolvedApp('snmp2mqtt'));q('hubDiscoveryFallback')?.addEventListener('click',()=>openResolvedApp('discovery'));q('devicesConfigSave')?.addEventListener('click',()=>saveDiscoverySurface('devices'));q('devicesConfigReload')?.addEventListener('click',()=>loadDiscoverySurface('devices'));q('maintenanceBackupSettingsSave')?.addEventListener('click',()=>saveDiscoverySurface('backups'));q('maintenanceBackupSettingsReload')?.addEventListener('click',()=>loadDiscoverySurface('backups'))}window.SwitchVisionHubSettings={open,load,save,selectDevicesTab,loadDeviceConfiguration,loadMaintenanceBackupSettings,saveDeviceConfiguration:()=>saveDiscoverySurface('devices'),saveMaintenanceBackupSettings:()=>saveDiscoverySurface('backups'),hasUnsavedCore:()=>dirty.has('core')};document.readyState==='loading'?document.addEventListener('DOMContentLoaded',init,{once:true}):init()})();
</script>
<script src="maintenance.js"></script>
<script src="calibration_profiles.js"></script>
<script src="calibration_profiles_manager.js"></script>
</body></html>"""


class SupportHandler(BaseHTTPRequestHandler):
    server_version = "SwitchVisionSupport/1.0"

    def _allow_ingress_request(self) -> bool:
        if self.client_address[0] == SUPERVISOR_INGRESS_IP:
            return True
        self.send_error(HTTPStatus.FORBIDDEN)
        return False

    @property
    def app(self) -> "SupportServer":
        return self.server  # type: ignore[return-value]

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[Support My Switch Web] {self.address_string()} - {fmt % args}", flush=True)

    def _json(self, data: Any, status: HTTPStatus = HTTPStatus.OK) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _html(self) -> None:
        body = _page_with_ui_preferences(self.app.version).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _download(self, name: str) -> None:
        safe_name = Path(unquote(name)).name
        if safe_name != unquote(name) or not safe_name.startswith("Switch_Vision_Contribution_"):
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        path = self.app.contributions_dir / safe_name
        if not path.is_file() or path.suffix.lower() not in {".zip", ".eml", ".html"}:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(path.stat().st_size))
        self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        with path.open("rb") as source:
            while chunk := source.read(1024 * 128):
                self.wfile.write(chunk)

    def _configuration_download(self) -> None:
        try:
            payload = _discovery_export(self.app.options_file, self.app.version)
        except RuntimeError as exc:
            self._json({"error": str(exc)}, HTTPStatus.SERVICE_UNAVAILABLE)
            return
        body = (json.dumps(payload, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Content-Disposition", 'attachment; filename="switch-vision-discovery-configuration.json"')
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _switches_configuration_download(self) -> None:
        try:
            payload = _switches_export(self.app.version)
        except (ValueError, RuntimeError, OSError) as exc:
            self._json({"error": str(exc)}, HTTPStatus.SERVICE_UNAVAILABLE)
            return
        body = (json.dumps(payload, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header(
            "Content-Disposition",
            'attachment; filename="switch-vision-switch-configuration.json"',
        )
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _complete_configuration_download(self) -> None:
        try:
            payload = _switch_vision_backup_export(self.app.version)
        except (ValueError, RuntimeError, OSError) as exc:
            self._json({"error": str(exc)}, HTTPStatus.SERVICE_UNAVAILABLE)
            return
        body = (json.dumps(payload, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        if len(body) > MAX_COMPLETE_BACKUP_BYTES:
            self._json(
                {"error": "Complete Switch Vision backup exceeds the 128 MiB safety limit."},
                HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
            )
            return
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Content-Disposition", 'attachment; filename="switch-vision-complete-backup.json"')
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _diagnostics_download(self) -> None:
        data = _diagnostics_snapshot(self.app.version)
        body = _diagnostics_text(data).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Content-Disposition", 'attachment; filename="switch-vision-diagnostics.txt"')
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        if not self._allow_ingress_request():
            return
        path = urlparse(self.path).path.rstrip("/") or "/"
        if path == "/":
            self._html()
        elif path == "/api/status":
            self._json({
                "version": self.app.version,
                "job": _state_snapshot(),
                "latest": _latest_contribution(self.app.contributions_dir),
                "defaults": _defaults(self.app.options_file),
                "discovery": _discovery_state_snapshot(),
                "discovery_history": discovery_history_snapshot(),
                "ui_preferences": _discovery_ui_preferences(),
            })
        elif path == "/api/discovery/debug":
            self._json(_current_discovery_debug_snapshot())
        elif path == "/api/health":
            self._json({"status": "ok", "version": self.app.version})
        elif path == "/api/app-links":
            self._json(_installed_switch_vision_app_links())
        elif path == "/api/settings/core":
            try:
                self._json(_core_settings_status())
            except RuntimeError as exc:
                self._json({"error": str(exc)}, HTTPStatus.SERVICE_UNAVAILABLE)
        elif path == "/api/settings/snmp2mqtt":
            try:
                self._json(_snmp2mqtt_settings_status())
            except RuntimeError as exc:
                self._json({"error": str(exc)}, HTTPStatus.SERVICE_UNAVAILABLE)
        elif path == "/api/settings/discovery":
            try:
                self._json(_discovery_settings_status())
            except RuntimeError as exc:
                self._json({"error": str(exc)}, HTTPStatus.SERVICE_UNAVAILABLE)
        elif path == "/api/maintenance/installer-backups":
            try:
                self._json(_installer_maintenance_request("status"))
            except ValueError as exc:
                self._json({"error": str(exc)}, HTTPStatus.INTERNAL_SERVER_ERROR)
            except RuntimeError as exc:
                self._json({"error": str(exc)}, HTTPStatus.SERVICE_UNAVAILABLE)
        elif path == "/api/maintenance/discovery-backups":
            try:
                self._json(discovery_backup_status(_self_addon_options()))
            except (ValueError, RuntimeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
        elif path == "/api/maintenance/mqtt/scan":
            try:
                self._json(scan_mqtt_entities())
            except (ValueError, RuntimeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
        elif path in {"/calibration_profiles.js", "/calibration_profiles_manager.js", "/maintenance.js", "/credits_v25.js", "/credits_v25.css"}:
            script_path = Path("/" + Path(path).name)

            if not script_path.is_file():
                self.send_error(
                    HTTPStatus.NOT_FOUND
                )
            else:
                body = script_path.read_bytes()

                self.send_response(
                    HTTPStatus.OK
                )

                self.send_header(
                    "Content-Type",
                    "text/css; charset=utf-8" if script_path.suffix == ".css" else "application/javascript; charset=utf-8",
                )

                self.send_header(
                    "Content-Length",
                    str(len(body)),
                )

                self.send_header(
                    "Cache-Control",
                    "no-store",
                )

                self.end_headers()
                self.wfile.write(body)

        elif path == "/api/calibration-profiles":
            try:
                result = _home_assistant_ws(
                    {
                        "type":
                        "switch_vision/list_calibrations"
                    }
                )

                self._json(
                    _calibration_profile_management_view(result)
                    if isinstance(result, dict)
                    else {}
                )

            except ValueError as exc:
                self._json(
                    {"error": str(exc)},
                    HTTPStatus.INTERNAL_SERVER_ERROR,
                )
            except RuntimeError as exc:
                self._json(
                    {"error": str(exc)},
                    HTTPStatus.SERVICE_UNAVAILABLE,
                )
        elif path == "/api/unifi2mqtt/settings":
            try:
                self._json(_unifi2mqtt_settings_status())
            except RuntimeError as exc:
                self._json({"error": str(exc)}, HTTPStatus.SERVICE_UNAVAILABLE)
        elif path == "/api/configured-devices":
            self._json(_configured_devices_snapshot(self.app.options_file))
        elif path == "/api/diagnostics":
            self._json(_diagnostics_snapshot(self.app.version))
        elif path == "/api/generated-card-yaml/status":
            self._json(_generated_card_yaml_status())
        elif path == "/api/generated-card-yaml/preview":
            result = _validate_generated_card_yaml(DEFAULT_GENERATED_CARD)
            if not result.get("valid"):
                self._json({"error": result.get("error")}, HTTPStatus.BAD_REQUEST)
            else:
                self._json({"text": result.get("text"), "sha256": result.get("sha256")})
        elif path == "/api/generated-card-yaml/dashboard-export":
            result = _generated_dashboard_export(DEFAULT_GENERATED_CARD)
            if not result.get("valid"):
                self._json({"error": result.get("error")}, HTTPStatus.BAD_REQUEST)
            else:
                self._json({"text": result.get("text"), "sha256": result.get("sha256"), "mode": "dashboard"})
        elif path == "/api/generated-card-yaml/custom-dashboard-export":
            result = _generated_dashboard_export(DEFAULT_GENERATED_CARD, custom_dashboard=True)
            if not result.get("valid"):
                self._json({"error": result.get("error")}, HTTPStatus.BAD_REQUEST)
            else:
                self._json({"text": result.get("text"), "sha256": result.get("sha256"), "mode": "custom-dashboard"})
        elif path == "/api/generated-card-yaml/cards-export":
            result = _generated_dashboard_export(DEFAULT_GENERATED_CARD, cards_only=True)
            if not result.get("valid"):
                self._json({"error": result.get("error")}, HTTPStatus.BAD_REQUEST)
            else:
                self._json({"text": result.get("text"), "sha256": result.get("sha256"), "mode": "cards"})
        elif path == "/api/generated-yaml/status":
            self._json(_generated_yaml_status())
        elif path == "/api/generated-yaml/preview":
            result = _validate_snmp2mqtt_yaml(DEFAULT_GENERATED_SNMP2MQTT)
            if not result.get("valid"):
                self._json({"error": result.get("error")}, HTTPStatus.BAD_REQUEST)
            else:
                self._json({"text": result.get("text"), "sha256": result.get("sha256")})
        elif path == "/download/switch-vision-dashboard.yaml":
            result = _generated_dashboard_export(DEFAULT_GENERATED_CARD)
            if not result.get("valid"):
                self.send_error(HTTPStatus.BAD_REQUEST, str(result.get("error") or "Dashboard export failed"))
            else:
                body = str(result.get("text") or "").encode("utf-8")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/yaml; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Content-Disposition", 'attachment; filename="switch-vision-dashboard.yaml"')
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
        elif path == "/download/switch-vision-custom-dashboard.yaml":
            result = _generated_dashboard_export(DEFAULT_GENERATED_CARD, custom_dashboard=True)
            if not result.get("valid"):
                self.send_error(HTTPStatus.BAD_REQUEST, str(result.get("error") or "Custom dashboard export failed"))
            else:
                body = str(result.get("text") or "").encode("utf-8")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/yaml; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Content-Disposition", 'attachment; filename="switch-vision-custom-dashboard.yaml"')
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
        elif path == "/download/generated-dashboard-card.yaml":
            if not DEFAULT_GENERATED_CARD.is_file():
                self.send_error(HTTPStatus.NOT_FOUND)
            else:
                body = DEFAULT_GENERATED_CARD.read_bytes()
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/yaml; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Content-Disposition", 'attachment; filename="generated-dashboard-card.yaml"')
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
        elif path == "/download/generated-snmp2mqtt.yaml":
            if not DEFAULT_GENERATED_SNMP2MQTT.is_file():
                self.send_error(HTTPStatus.NOT_FOUND)
            else:
                body = DEFAULT_GENERATED_SNMP2MQTT.read_bytes()
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/yaml; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Content-Disposition", 'attachment; filename="generated-snmp2mqtt.yaml"')
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
        elif path == "/download/switch-vision-backup.json":
            self._complete_configuration_download()
        elif path == "/download/switch-vision-switch-configuration.json":
            self._switches_configuration_download()
        elif path == "/download/discovery-configuration.json":
            self._configuration_download()
        elif path == "/download/diagnostics.txt":
            self._diagnostics_download()
        elif path.startswith("/download/"):
            self._download(path.split("/download/", 1)[1])
        else:
            self.send_error(HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:  # noqa: N802
        if not self._allow_ingress_request():
            return
        path = urlparse(self.path).path.rstrip("/")

        if path in {
            "/api/calibration-profiles/get",
            "/api/calibration-profiles/save",
            "/api/calibration-profiles/delete",
        }:
            try:
                length = int(
                    self.headers.get(
                        "Content-Length",
                        "0",
                    )
                )

                maximum = (
                    3 * 1024 * 1024
                    if path ==
                    "/api/calibration-profiles/save"
                    else 8192
                )

                if (
                    length <= 0
                    or
                    length > maximum
                ):
                    raise ValueError(
                        "Invalid Calibration Profile "
                        "request size."
                    )

                data = json.loads(
                    self.rfile.read(
                        length
                    ).decode("utf-8")
                )

                if not isinstance(
                    data,
                    dict,
                ):
                    raise ValueError(
                        "Calibration Profile request "
                        "must contain a JSON object."
                    )

                profile = (
                    _calibration_profile_name(
                        data.get("profile")
                    )
                )

                if (
                    path ==
                    "/api/calibration-profiles/get"
                ):
                    result = (
                        _home_assistant_ws(
                            {
                                "type":
                                "switch_vision/get_calibration",
                                "profile":
                                profile,
                            }
                        )
                    )

                    self._json(
                        result
                        if isinstance(
                            result,
                            dict,
                        )
                        else {}
                    )

                    return

                if (
                    path ==
                    "/api/calibration-profiles/delete"
                ):
                    result = _home_assistant_ws(
                        {
                            "type":
                            "switch_vision/delete_calibration",
                            "profile":
                            profile,
                        }
                    )

                    self._json(
                        result
                        if isinstance(
                            result,
                            dict,
                        )
                        else {
                            "ok": True,
                            "profile":
                            profile,
                        }
                    )

                    return

                calibration = data.get(
                    "calibration"
                )

                if not isinstance(
                    calibration,
                    dict,
                ):
                    raise ValueError(
                        "Calibration data must "
                        "contain one JSON object."
                    )

                _home_assistant_service(
                    "switch_vision",
                    "save_calibration",
                    {
                        "profile":
                        profile,
                        "calibration":
                        calibration,
                        "mirror_to_base":
                        False,
                    },
                )

                self._json(
                    {
                        "ok": True,
                        "profile":
                        profile,
                    }
                )

                return

            except (
                ValueError,
                RuntimeError,
                UnicodeDecodeError,
                json.JSONDecodeError,
            ) as exc:
                self._json(
                    {"error": str(exc)},
                    HTTPStatus.BAD_REQUEST,
                )

                return

        if path == "/api/secrets/reveal":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 8192:
                    raise ValueError("Invalid secret reveal request size.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                self._json(_reveal_hub_secret(data))
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return

        if path in {"/api/settings/core", "/api/settings/snmp2mqtt", "/api/settings/discovery"}:
            try:
                length = int(self.headers.get("Content-Length", "0"))
                maximum = 1024 * 1024 if path == "/api/settings/discovery" else 256 * 1024
                if length <= 0 or length > maximum:
                    raise ValueError("Invalid Hub settings request size.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                if path == "/api/settings/core":
                    self._json(_save_core_settings(data))
                elif path == "/api/settings/snmp2mqtt":
                    with _exclusive_operation("SNMP2MQTT settings update"):
                        self._json(_save_snmp2mqtt_settings(data))
                else:
                    with _exclusive_operation("Discovery settings update"):
                        self._json(_save_discovery_settings(data))
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/ui-density":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 4096:
                    raise ValueError("Invalid UI density request size.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                self._json({"preferences": _set_discovery_ui_density(data.get("density"))})
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/unifi2mqtt/install":
            try:
                with _exclusive_operation("UniFi2MQTT installation"):
                    self._json(_install_unifi2mqtt())
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except RuntimeError as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/unifi2mqtt/test-connection":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 16384:
                    raise ValueError("Invalid UniFi connection test request size.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                self._json(_test_unifi2mqtt_connection(data))
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": _unifi_test_safe_reason(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/unifi2mqtt/settings":
            try:
                with _exclusive_operation("UniFi2MQTT settings update"):
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 32768:
                        raise ValueError("Invalid UniFi2MQTT settings request size.")
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                    self._json(_save_unifi2mqtt_settings(data))
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/configured-devices/state":
            try:
                with _device_configuration_update("Device configuration update"):
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 8192:
                        raise ValueError("Invalid device state request size.")
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                    result = _set_configured_device_state(self.app.options_file, data)
                    key = str(data.get("device_key") or "") if isinstance(data, dict) else ""
                    try:
                        dashboard = _apply_saved_device_order_to_dashboard()
                        result["dashboard_refresh_started"] = bool(dashboard.get("updated"))
                        result["dashboard_refresh_pending"] = not bool(dashboard.get("updated"))
                        result["dashboard_projection"] = dashboard
                    except (OSError, RuntimeError, ValueError) as exc:
                        result["dashboard_refresh_started"] = False
                        result["dashboard_refresh_pending"] = True
                        result["dashboard_refresh_warning"] = str(exc)[:240]
                    result["polling_refresh_started"] = False
                    if key.startswith("snmp:"):
                        queued = _start_device_state_application()
                        result["polling_refresh_started"] = bool(queued.get("started"))
                        result["polling_refresh_pending"] = True
                        result["polling_refresh_coalesced"] = bool(queued.get("coalesced"))
                        result["polling_refresh_generation"] = queued.get("generation")
                    elif key.startswith("unifi:"):
                        # UniFi2MQTT reads the shared control file on its normal poll loop;
                        # no Discovery/card-regeneration operation is required here.
                        result["polling_refresh_pending"] = True
                    # Keep response ordering aligned with the serialized mutation
                    # order so concurrent UI clicks cannot render an older snapshot
                    # after a newer one has already been returned.
                    self._json(result)
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/configured-devices/order":
            try:
                with _device_configuration_update("Device order update"):
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 8192:
                        raise ValueError("Invalid device order request size.")
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                    result = _move_configured_device(self.app.options_file, data)
                    try:
                        dashboard = _apply_saved_device_order_to_dashboard()
                        result["dashboard_refresh_started"] = bool(dashboard.get("updated"))
                        result["dashboard_refresh_pending"] = not bool(dashboard.get("updated"))
                        result["dashboard_projection"] = dashboard
                    except (OSError, RuntimeError, ValueError) as exc:
                        result["dashboard_refresh_started"] = False
                        result["dashboard_refresh_pending"] = True
                        result["dashboard_refresh_warning"] = str(exc)[:240]
                    self._json(result)
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/configured-devices/reset-order":
            try:
                with _device_configuration_update("Device order reset"):
                    result = _reset_configured_device_order(self.app.options_file)
                    try:
                        dashboard = _apply_saved_device_order_to_dashboard()
                        result["dashboard_refresh_started"] = bool(dashboard.get("updated"))
                        result["dashboard_refresh_pending"] = not bool(dashboard.get("updated"))
                        result["dashboard_projection"] = dashboard
                    except (OSError, RuntimeError, ValueError) as exc:
                        result["dashboard_refresh_started"] = False
                        result["dashboard_refresh_pending"] = True
                        result["dashboard_refresh_warning"] = str(exc)[:240]
                    self._json(result)
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except (ValueError, RuntimeError, OSError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/switches/import":
            try:
                with _exclusive_operation("Switch configuration import"):
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 4 * 1024 * 1024:
                        raise ValueError("Invalid switch configuration size.")
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                    self._json(_import_switches_only(data))
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except (ValueError, RuntimeError, OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/configuration/import":
            try:
                with _exclusive_operation("Configuration import"):
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > MAX_COMPLETE_BACKUP_BYTES:
                        raise ValueError("Invalid configuration backup size.")
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                    if isinstance(data, dict) and data.get("format") == COMPLETE_BACKUP_FORMAT:
                        self._json(_restore_complete_backup(data))
                    else:
                        imported = _validate_discovery_import(data)
                        _import_discovery_options(imported)
                        self._json({
                            "imported": True,
                            "format": "legacy-discovery",
                            "switch_count": _configured_switch_count(imported.get("switches")),
                            "restart_required": False,
                        })
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except (ValueError, RuntimeError, OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/maintenance/installer-backups":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 8192:
                    raise ValueError("Invalid Installer backup request size.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                self._json(_installer_maintenance_browser_request(data))
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/maintenance/discovery-backups/remove":
            try:
                with _exclusive_operation("Discovery backup removal"):
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 8192:
                        raise ValueError("Invalid Discovery backup removal request size.")
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                    if not isinstance(data, dict):
                        raise ValueError("Discovery backup removal request must contain a JSON object.")
                    options = _self_addon_options()
                    discovery_backup_status(options)
                    remove_discovery_backup(data.get("name"))
                    self._json(discovery_backup_status(options))
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/maintenance/mqtt/repair":
            try:
                with _exclusive_operation("MQTT entity repair"):
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 8192:
                        raise ValueError("Invalid MQTT repair request size.")
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                    self._json(repair_mqtt_entities(data))
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/maintenance/reset-everything":
            try:
                with _exclusive_operation("Reset Everything"):
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 4096:
                        raise ValueError("Invalid Reset Everything request size.")
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                    if not isinstance(data, dict):
                        raise ValueError("Reset Everything request must contain a JSON object.")
                    if str(data.get("confirmation") or "") != RESET_EVERYTHING_CONFIRMATION:
                        raise ValueError(
                            f'Type "{RESET_EVERYTHING_CONFIRMATION}" exactly to confirm Reset Everything.'
                        )
                    self._json(_reset_everything())
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except (ValueError, RuntimeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/discovery/reset-snmp":
            try:
                with _exclusive_operation("SNMP Discovery reset"):
                    self._json(_reset_snmp_discovery_data())
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            except RuntimeError as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if path == "/api/discovery/regenerate-yaml":
            operation_name = "SNMP2MQTT YAML regeneration"
            try:
                _claim_operation(operation_name)
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
                return
            _DISCOVERY_STOP_REQUESTED.clear()
            _set_discovery_state(
                running=True,
                started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                finished_at=None,
                success=None,
                message="Preparing SNMP2MQTT YAML regeneration",
                log_tail=[],
                stage="Preparing SNMP2MQTT YAML regeneration",
                switch="",
                target="",
                command="",
                activity="Loading saved Discovery data and SNMP walks",
                phase="preparing",
                mode="regenerate_yaml",
                snmp2mqtt={"status": "Waiting", "action": "none", "slug": None, "state": None, "message": "Waiting for YAML regeneration to complete"},
            )
            thread = threading.Thread(
                target=_run_discovery,
                args=(self.app.discovery_script, "regenerate_yaml"),
                daemon=True,
            )
            try:
                thread.start()
            except Exception:
                _release_operation(operation_name)
                raise
            self._json({"started": True, "mode": "regenerate_yaml"}, HTTPStatus.ACCEPTED)
            return
        if path == "/api/discovery/regenerate-card":
            try:
                result = _start_dashboard_card_regeneration(self.app.discovery_script)
                self._json(result, HTTPStatus.ACCEPTED)
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            return
        if path == "/api/discovery/start":
            try:
                _claim_operation("Discovery")
            except OperationConflict as exc:
                self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
                return
            _DISCOVERY_STOP_REQUESTED.clear()
            _set_discovery_state(
                running=True,
                started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                finished_at=None,
                success=None,
                message="Preparing Discovery",
                log_tail=[],
                stage="Preparing Discovery",
                mode="discovery",
                switch="",
                target="",
                command="",
                activity="Validating configured switches",
                phase="preparing",
                snmp2mqtt={"status": "Waiting", "action": "none", "slug": None, "state": None, "message": "Waiting for Discovery to complete"},
            )
            thread = threading.Thread(target=_run_discovery, args=(self.app.discovery_script,), daemon=True)
            try:
                thread.start()
            except Exception:
                _release_operation("Discovery")
                raise
            self._json({"started": True}, HTTPStatus.ACCEPTED)
            return
        if path == "/api/discovery/stop":
            if not _request_discovery_stop():
                self._json({"error": "Discovery is not running."}, HTTPStatus.CONFLICT)
                return
            self._json({"stopping": True}, HTTPStatus.ACCEPTED)
            return
        if path != "/api/create":
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        try:
            _claim_operation("Support My Switch")
        except OperationConflict as exc:
            self._json({"error": str(exc)}, HTTPStatus.CONFLICT)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 65536:
                raise ValueError("Invalid request size.")
            data = json.loads(self.rfile.read(length).decode("utf-8"))
            settings = _validate_request(data)
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            _release_operation("Support My Switch")
            self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        _set_state(
            running=True,
            started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            finished_at=None,
            success=None,
            message="Starting contribution…",
            log_tail=[],
        )
        thread = threading.Thread(
            target=_run_bundle,
            args=(settings, self.app.support_script, self.app.contributions_dir, self.app.version),
            daemon=True,
        )
        try:
            thread.start()
        except Exception:
            _release_operation("Support My Switch")
            raise
        self._json({"started": True}, HTTPStatus.ACCEPTED)


class SupportServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], handler: type[BaseHTTPRequestHandler], *, contributions_dir: Path, options_file: Path, support_script: Path, discovery_script: Path, version: str) -> None:
        super().__init__(address, handler)
        self.contributions_dir = contributions_dir
        self.options_file = options_file
        self.support_script = support_script
        self.discovery_script = discovery_script
        self.version = version


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8099)
    parser.add_argument("--contributions-dir", type=Path, default=DEFAULT_CONTRIBUTIONS_DIR)
    parser.add_argument("--options-file", type=Path, default=DEFAULT_OPTIONS_FILE)
    parser.add_argument("--support-script", type=Path, default=DEFAULT_SUPPORT_SCRIPT)
    parser.add_argument("--discovery-script", type=Path, default=DEFAULT_DISCOVERY_SCRIPT)
    parser.add_argument("--version", default=os.environ.get("SWITCH_VISION_DISCOVERY_VERSION", "unknown"))
    args = parser.parse_args()
    _ensure_runtime_paths()
    args.contributions_dir.mkdir(parents=True, exist_ok=True)
    server = SupportServer(
        (args.host, args.port),
        SupportHandler,
        contributions_dir=args.contributions_dir,
        options_file=args.options_file,
        support_script=args.support_script,
        discovery_script=args.discovery_script,
        version=args.version,
    )
    print(f"[Support My Switch Web] Listening on {args.host}:{args.port}", flush=True)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
