#!/usr/bin/env python3
from pathlib import Path

SOURCE = Path(__file__).with_name("support_web.py").read_text(encoding="utf-8")

for marker in (
    'class="hub-settings-tabs" role="tablist"',
    'data-hub-settings-tab="core">UI Settings</button>',
    'data-hub-settings-tab="discovery">Discovery Settings</button>',
    'data-hub-settings-tab="snmp2mqtt">SNMP2MQTT Settings</button>',
    'role="tabpanel" aria-labelledby="hubTab-core"',
    'role="tabpanel" aria-labelledby="hubTab-discovery" hidden',
    'role="tabpanel" aria-labelledby="hubTab-snmp2mqtt" hidden',
    "function selectTab(which='core',focus=false)",
    "const ids=['core','discovery','snmp2mqtt']",
    "tab.addEventListener('click',()=>selectTab(tab.dataset.hubSettingsTab))",
    "tab.addEventListener('keydown',tabKeydown)",
    "async function open(which='core'){styles();setView('settings');await load();selectTab(which)}",
    '.hub-settings-pane[hidden]{display:none!important}',
):
    assert marker in SOURCE, marker

# Dashboard presentation lives inside the Native dashboard header section as a
# balanced 2x2 responsive layout instead of a separate settings card.
for marker in (
    "presentationGroup.className='hub-header-group hub-header-presentation'",
    "presentationGroup.innerHTML='<h4>Dashboard presentation</h4>'",
    "headerLayout.append(displayGroup,shortcutGroup,presentationGroup,box)",
    ".hub-header-layout{display:grid;grid-template-columns:minmax(260px,.8fr) minmax(420px,1.2fr)",
    ".hub-header-presentation .hub-toggle-grid{grid-template-columns:1fr}",
    ".hub-header-presentation-width{grid-template-columns:1fr!important",
):
    assert marker in SOURCE, marker
assert "const dash=sec('Dashboard presentation'" not in SOURCE

# Show UniFi integration belongs to Native dashboard header -> Dashboard
# presentation. The saved Core discovery preference is reused in-place; it must
# not be rendered in the Discovery appearance card again.
assert "if(s.discovery&&Object.prototype.hasOwnProperty.call(s.discovery,'show_unifi_integration'))presentationTog.append(tog('Show UniFi integration',s.discovery.show_unifi_integration" in SOURCE
assert "if(grp==='discovery')b.append(tog('Show UniFi integration'" not in SOURCE

# The old accordion contract must be gone; tabs are the sole top-level settings navigation.
for old in (
    '<details id="hubComponent-core"',
    '<details id="hubComponent-discovery"',
    '<details id="hubComponent-snmp2mqtt"',
    'x.open=true',
):
    assert old not in SOURCE, old


# Discovery Settings switch rows are compact custom disclosures. Device ordering
# is owned exclusively by the Devices view, so Settings must not render or mutate
# switch order. The first saved switch remains expanded by default and later rows
# start collapsed.
for marker in (
    "expandedDiscoverySwitches=new Set();let discoverySwitchExpansionInitialized=false",
    "if(!discoverySwitchExpansionInitialized){if(switches.length){expandedDiscoverySwitches.add",
    "const sw=sec('Switches','SNMP communities are masked by default. Use the eye to reveal a saved community; blank preserves it. Device ordering is managed from Devices.');",
    "const c=document.createElement('div');c.className='device-card hub-setting-row hub-switch-setting-row'",
    "const hd=document.createElement('div');hd.className='hub-switch-setting-summary'",
    "const toggle=document.createElement('button');toggle.type='button';toggle.className='hub-switch-setting-toggle'",
    "toggle.setAttribute('aria-expanded',String(expandedDiscoverySwitches.has(key)))",
    "hd.append(toggle,rm)",
    "g.hidden=!expandedDiscoverySwitches.has(key)",
    "toggle.addEventListener('click',()=>{const open=g.hidden;",
    ".hub-switch-setting-summary{display:flex",
    ".hub-switch-setting-toggle{display:flex!important",
    ".hub-switch-setting-label>strong{color:var(--accent-strong)",
    "hub-discovery-workflow-grid",
    ".hub-discovery-workflow-grid .hub-field-label{min-height:2.4em",
):
    assert marker in SOURCE, marker

settings_start = SOURCE.index("function renderDiscovery(){")
settings_end = SOURCE.index("function cleanDiscovery(){", settings_start)
settings_block = SOURCE[settings_start:settings_end]
for obsolete in (
    "hub-switch-setting-order",
    "const move=delta=>",
    "up.addEventListener('click',()=>move(-1))",
    "down.addEventListener('click',()=>move(1))",
    "Use the arrows to reorder switches",
):
    assert obsolete not in settings_block, obsolete

# Do not reintroduce real buttons inside <summary>; that was unreliable under
# Home Assistant ingress and caused the Settings reorder arrows to no-op.
settings_start = SOURCE.index("function renderDiscovery(){")
settings_end = SOURCE.index("function cleanDiscovery(){", settings_start)
settings_block = SOURCE[settings_start:settings_end]
assert "document.createElement('summary')" not in settings_block
assert "document.createElement('details')" not in settings_block
assert "c.open=true" not in SOURCE

# Save/reload remains shared across all panes and dirty state is not cleared by tab changes.
select_start = SOURCE.index("function selectTab(which='core',focus=false)")
select_end = SOURCE.index("function tabKeydown", select_start)
select_block = SOURCE[select_start:select_end]
assert 'dirty.clear()' not in select_block
assert 'hubSettingsSave' in SOURCE and 'hubSettingsReload' in SOURCE

# Shared sticky action bar is available on each working Hub view and delegates
# to the page's existing real action rather than duplicating business logic.
for marker in (
    'id="hubSharedActions" class="hub-settings-actions hub-shared-actions hidden"',
    'id="hubSharedPrimary" class="primary"',
    'id="hubSharedReload"',
    'id="hubSharedBack"',
    "const HUB_SHARED_PAGE_ACTIONS={discovery:{label:'Run Discovery'",
    "devices:{label:'Refresh Devices'",
    "support:{label:'Create Contribution'",
    "configuration:{label:'Export Configuration'",
    "maintenance:{label:'Scan MQTT Entities'",
    "profiles:{label:'Refresh Profiles'",
    "unifi2mqtt:{label:'Save UniFi2MQTT Settings'",
    "function runSharedHubPrimary()",
    "function reloadSharedHubView()",
    "updateSharedHubActions(view);window.scrollTo",
    "$('hubSharedPrimary').addEventListener('click',runSharedHubPrimary)",
    "$('hubSharedReload').addEventListener('click',reloadSharedHubView)",
    "$('hubSharedBack').addEventListener('click',goBack)",
):
    assert marker in SOURCE, marker

# Hub navigation bullets use consistent title-style capitalization for actions.
for marker in (
    'Show Detected Devices &amp; Status',
    'Reorder Switches',
    'Manage Faceplate Calibrations',
    'Import / Export Profiles',
    'Manage Backups',
    'Repair Stale MQTT Entities',
    'Add / Remove Switches',
):
    assert marker in SOURCE, marker

print("Switch Vision Settings top tabs regression: PASS")
